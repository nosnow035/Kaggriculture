"""Batched self-play: many games in one process, one GPU forward per step.

Profiling a single game showed the network forward is ~97% of a step (110 ms against
1.2 ms of feature building), so playing games one at a time wastes almost all of the
time on tiny unbatched matmuls. Here K games advance in lock-step: every game builds
its own inputs (cheap, pure Python), all of them go through one batched torch forward
on the GPU, and each game then runs the usual executor on its own slice of the output.

The policy logic is not duplicated — BCPolicy.build_ctx() and BCPolicy.decide() are the
same halves the single-game agent uses, so a batched rollout and a Kaggle submission make
identical decisions from identical weights.

Usage:
  python -m kag.rl_batch <checkpoint.pt> [games] [--check]     # throughput / parity test
"""
import contextlib
import io
import sys
import time

import numpy as np
import torch

from kag.agents.bc import BCPolicy
from kag.model import BCNet, pair_feats, shed_pair_feats


class BatchPolicy:
    """One torch model, evaluated on a list of per-game contexts in a single forward."""

    def __init__(self, ckpt, device="cuda"):
        ck = torch.load(ckpt, map_location="cpu", weights_only=False)
        self.cfg = ck["cfg"]
        self.decode = ck.get("decode", {})
        self.model = BCNet(**self.cfg)
        self.model.load_state_dict(ck["state"])
        self.model.eval().to(device)
        self.device = device

    @torch.no_grad()
    def forward(self, ctxs):
        """[ctx, ...] -> [(mlog, ulog, pk, value), ...] as numpy, one tuple per context.

        The critic value rides along because GAE needs V(s) at exactly the states the
        policy acted in, and recomputing them later would mean a second forward pass."""
        dev = self.device
        B = len(ctxs)
        counts = [len(c["pos"]) for c in ctxs]
        t = lambda a, dt=None: torch.from_numpy(np.ascontiguousarray(a)).to(dev)  # noqa: E731
        tiles = t(np.stack([c["tiles"] for c in ctxs]))
        glob = t(np.stack([c["glob"] for c in ctxs]))
        claimed = t(np.stack([c["claimed"] for c in ctxs]))
        claimed_shed = torch.tensor([float(c["claimed_shed"]) for c in ctxs], dtype=torch.float32, device=dev)
        u_step = t(np.repeat(np.arange(B), counts).astype(np.int64))
        u_feat = t(np.concatenate([c["u_feat"] for c in ctxs]))
        u_gate = t(np.concatenate([c["u_gate"] for c in ctxs]))
        u_self = t(np.concatenate([c["self_tile"] for c in ctxs]).astype(np.int64))

        tile_emb, glob_emb = self.model.encode(tiles, glob)
        u_xy = torch.round(u_feat[:, :2] * 9.0)
        pair = pair_feats(u_xy, claimed[u_step], u_self)
        shed_pair = shed_pair_feats(u_xy, claimed_shed[u_step], u_self == -2)
        ulog, pk = self.model.unit_logits(tile_emb, glob_emb, u_step, u_feat, u_gate, pair, shed_pair)
        mlog = self.model.market_logits(tile_emb, glob_emb)
        value = self.model.value(tile_emb, glob_emb)

        mlog = mlog.float().cpu().numpy()
        ulog = ulog.float().cpu().numpy()
        pk = pk.float().cpu().numpy()
        value = value.float().cpu().numpy()
        out, o = [], 0
        for i, n in enumerate(counts):
            out.append((mlog[i], ulog[o:o + n], pk[o:o + n], float(value[i])))
            o += n
        return out


class _Game:
    __slots__ = ("env", "seat", "pol", "opp", "opp_pol", "state", "done", "pending", "opp_pending", "values")


def play_batch(batch_policy, jobs, kwargs=None, on_finish=None, opp_kwargs=None):
    """Play jobs concurrently. Each job: {seed, seat, opp (agent spec or "self"), sample_seed?}.

    kwargs are passed to BCPolicy (sample, record, guards, ...); the policy runs with
    backend="none" because this class owns the network. opp="self" puts the same weights
    on the other seat and folds both seats into the same batched forward, which is both a
    stronger sparring partner than a fixed tape and free in GPU terms. Only the job's own
    seat is recorded. Returns one result per job."""
    kwargs = dict(kwargs or {})
    with contextlib.redirect_stdout(io.StringIO()):
        from kaggle_environments import make
    from kag.agents.registry import build_agent

    games = []
    for j in jobs:
        g = _Game()
        g.env = make("kaggriculture", configuration={"seed": int(j["seed"])})
        g.seat = int(j.get("seat", 0))
        g.pol = BCPolicy(None, backend="none", seed=j.get("sample_seed"), **kwargs)
        if j["opp"] == "self":
            g.opp = None
            g.opp_pol = BCPolicy(None, backend="none", seed=(j.get("sample_seed") or 0) + 1,
                                 **(opp_kwargs if opp_kwargs is not None else kwargs))
            g.opp_pol.rec = None  # never record the sparring seat
        else:
            g.opp = build_agent(j["opp"])
            g.opp_pol = None
            if isinstance(g.opp, str):
                raise ValueError("file-path agents cannot be stepped manually; use tape/bc/starter specs")
        g.state = g.env.reset(2)
        g.done = False
        g.pending = None
        g.opp_pending = None
        g.values = []  # V(s) for every recorded step, in record order
        games.append(g)

    while True:
        live = [g for g in games if not g.done]
        if not live:
            break
        ctxs, owners = [], []
        for g in live:
            ctx = g.pol.build_ctx(g.state[g.seat].observation)
            if "opening_action" in ctx:
                g.pending = ctx["opening_action"]
            else:
                ctxs.append(ctx)
                owners.append((g, False))
            if g.opp_pol is not None:
                octx = g.opp_pol.build_ctx(g.state[1 - g.seat].observation)
                if "opening_action" in octx:
                    g.opp_pending = octx["opening_action"]
                else:
                    ctxs.append(octx)
                    owners.append((g, True))
        if ctxs:
            for (g, is_opp), ctx, out in zip(owners, ctxs, batch_policy.forward(ctxs)):
                mlog, ulog, pk, value = out
                if is_opp:
                    g.opp_pending = g.opp_pol.decide(ctx, mlog, ulog, pk)
                    continue
                before = len(g.pol.rec) if g.pol.rec is not None else 0
                g.pending = g.pol.decide(ctx, mlog, ulog, pk)
                if g.pol.rec is not None and len(g.pol.rec) > before:
                    g.values.append(value)
        for g in live:
            actions = [None, None]
            actions[g.seat] = g.pending
            actions[1 - g.seat] = (g.opp_pending if g.opp_pol is not None
                                   else g.opp(g.state[1 - g.seat].observation))
            g.state = g.env.step(actions)
            if g.env.done:
                g.done = True
                if on_finish is not None:
                    on_finish(g)

    results = []
    for g, j in zip(games, jobs):
        last = g.state
        results.append({
            "job": j,
            "money": [float(last[0].reward or 0.0), float(last[1].reward or 0.0)],
            "status": [last[0].status, last[1].status],
            "rec": g.pol.rec,
            "values": np.asarray(g.values, dtype=np.float32),
        })
    return results


def _self_test(ckpt, n_games=8, check=False):
    from kag.rl_rollout import collate  # noqa: F401  (record format lives with the rollout worker)
    tape = {"kind": "tape", "path": "data/d0916/tapes"}
    import glob
    import os
    t = sorted(glob.glob(os.path.join(tape["path"], "*_s0.json")))[0]
    opp = {"kind": "tape", "path": t}
    bp = BatchPolicy(ckpt)
    jobs = [{"seed": 700000 + i, "seat": 0, "opp": opp, "sample_seed": i} for i in range(n_games)]
    kw = {"calibrated": False, "feed_topup": False}
    t0 = time.time()
    res = play_batch(bp, jobs, kw)
    dt = time.time() - t0
    money = [r["money"][0] for r in res]
    print(f"batched: {n_games} games in {dt:.0f}s ({dt / n_games:.2f}s per game), "
          f"money mean {np.mean(money):.0f}, statuses {set(s for r in res for s in r['status'])}")

    if check:  # same game through the single-game path; greedy decisions must match
        with contextlib.redirect_stdout(io.StringIO()):
            from kaggle_environments import make
        from kag.agents.registry import build_agent
        pol = BCPolicy(ckpt, **kw)
        env = make("kaggriculture", configuration={"seed": jobs[0]["seed"]})
        t0 = time.time()
        env.run([lambda obs, config=None: pol.act(obs), build_agent(opp)])
        single = float(env.steps[-1][0].reward or 0.0)
        print(f"single : 1 game in {time.time() - t0:.0f}s, money {single:.0f} "
              f"(batched game 0: {money[0]:.0f}, {'match' if single == money[0] else 'DIFFER'})")


if __name__ == "__main__":
    ck = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 and not sys.argv[2].startswith("-") else 8
    _self_test(ck, n, check="--check" in sys.argv)
