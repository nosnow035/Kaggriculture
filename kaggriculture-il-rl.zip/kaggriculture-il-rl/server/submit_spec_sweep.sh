#!/bin/bash
# Specialisation sweep on top of the finished general model (run on the LOGIN node).
#
# The general checkpoint (runs/gen_d256/best.pt, 89 teams / 3,309 trajectories) already
# exists, so each job only fine-tunes on Majkel1337's 886 games: about 2 min per epoch,
# so 12-25 min per job. Five jobs fit inside the `low` limit of 8 concurrent.
#
# Reference: the submitted model used --epochs 6 --lr 1.5e-4 and scored 46/128 (35.9%)
# against the user's agents, with money even (100.3k vs 100.3k, 95.7k vs 98.7k).

set -euo pipefail

GEN=runs/gen_d256/best.pt
test -f "$GEN" || { echo "missing $GEN — the general model must be trained first"; exit 1; }
test -d data/bc_majkel || { echo "missing data/bc_majkel — re-send the data bundle"; exit 1; }

spec() {  # spec <name> <data_dir> <train.py args...>
  local name=$1 data=$2
  shift 2
  sbatch -J "$name" -p a100 --gres=gpu:a100:1 --qos=low \
    train_bc.sbatch "$data" "runs/$name" --d 256 --layers 6 --bs 256 --init "$GEN" "$@"
}

# Longer adaptation at the same learning rate.
spec sp_e12     data/bc_majkel --epochs 12 --lr 1.5e-4

# Stronger / weaker adaptation at the same length.
spec sp_lr3     data/bc_majkel --epochs 6  --lr 3e-4
spec sp_lr07    data/bc_majkel --epochs 6  --lr 0.7e-4

# Longer and stronger together.
spec sp_e12_lr3 data/bc_majkel --epochs 12 --lr 3e-4

# Only Majkel's 500 richest games (its own weaker games may be what hurt the 886-game run).
spec sp_top500  data/bc_majkel --epochs 6  --lr 1.5e-4 --max-traj 500

squeue -u "$USER"
