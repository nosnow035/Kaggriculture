#!/bin/bash
# Two-stage imitation learning, submitted together (run on the LOGIN node after `uv sync --locked`).
#
#   Stage 1  general model : 3,309 trajectories from 89 teams (money >= 110k, 7 days)
#   Stage 2  specialist    : continue from stage 1 on Majkel1337's 886 games (--init)
#
# Stage 2 is submitted with --dependency=afterok, so Slurm starts it only when stage 1
# finishes successfully; nothing has to be watched in between. Both jobs are GPU-only
# training (no self-play, no evaluation), which is what the a100 partition is for.

set -euo pipefail

GEN=gen_d256
SPEC=spec_majkel_d256

gen_id=$(sbatch --parsable -J "$GEN" -p a100 --gres=gpu:a100:1 --qos=low \
  train_bc.sbatch data/bc_top110 "runs/$GEN" --d 256 --layers 6 --epochs 12 --bs 256 --lr 6e-4)
echo "stage 1 (general)    job $gen_id"

spec_id=$(sbatch --parsable --dependency=afterok:"$gen_id" -J "$SPEC" -p a100 --gres=gpu:a100:1 --qos=low \
  train_bc.sbatch data/bc_majkel "runs/$SPEC" --d 256 --layers 6 --epochs 6 --bs 256 --lr 1.5e-4 \
  --init "runs/$GEN/best.pt")
echo "stage 2 (specialist) job $spec_id  (starts after $gen_id succeeds)"

squeue -u "$USER"
