#!/bin/bash
# Specialise the general model on M & M & P & Q (336 games, win 0.720, mean money 116.5k —
# 7k above Majkel1337). Run on the LOGIN node after unpacking bc_mmpq.tar.gz.

set -euo pipefail

GEN=runs/gen_d256/best.pt
test -f "$GEN" || { echo "missing $GEN"; exit 1; }
test -d data/bc_mmpq || { echo "missing data/bc_mmpq — unpack bc_mmpq.tar.gz first"; exit 1; }

for cfg in "sp_mmpq 6 1.5e-4" "sp_mmpq_e12 12 1.5e-4" "sp_mmpq_lr3 6 3e-4"; do
  set -- $cfg
  sbatch -J "$1" -p a100 --gres=gpu:a100:1 --qos=low \
    train_bc.sbatch data/bc_mmpq "runs/$1" --d 256 --layers 6 --bs 256 \
    --init "$GEN" --epochs "$2" --lr "$3"
done

squeue -u "$USER"
