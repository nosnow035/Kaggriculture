# IS計算サーバー（A100）での学習手順

この一式は **模倣学習（BC）の学習だけ** をサーバーで行うためのものです。
学習データ作成・自己対戦・対戦評価はCPU主体の処理なので、サーバー側の規則
（「GPU使用が主体でないジョブは停止される場合があります」「CPU単体の計算資源は提供していません」
「大量の前処理が必要な場合は別の環境で実施してください」）に従い、手元のPCで実行します。

## 0. 安全に使うための決めごと

| 項目 | 決めごと | 理由 |
| --- | --- | --- |
| QoS | 必ず `--qos=low` | 研究活動以外のため（ガイド2.3） |
| ジョブの中身 | GPU学習のみ。自己対戦・対戦評価は投入しない | CPU主体のジョブは停止対象 |
| ログインノード | `uv` の操作と `sbatch` だけ。学習は絶対に直接実行しない | 全員が使う共有ノードのため |
| 同時実行 | 2本まで（`low` の上限は8本） | 共用GPUを占有しない |
| 中断対応 | `--resume` で再開（`train_bc.sbatch` が自動付与） | 中断されても最初からやり直さない |
| 容量 | この一式は約800MB（目安1TB、上限4TB） | 使い終わったらデータを削除 |
| 対話セッション | `--qos=inter` は動作確認のみ、30分以内 | 本番学習はバッチで |

## 1. 転送（手元のPCで実行）

```
scp kaggriculture_server.tar.gz s<学籍番号>@<サーバーのアドレス>:~/
```

サーバーにログインして展開します。

```
ssh s<学籍番号>@<サーバーのアドレス>
mkdir -p ~/kaggriculture && tar -xzf ~/kaggriculture_server.tar.gz -C ~/kaggriculture
cd ~/kaggriculture
```

| 場所 | 内容 |
| --- | --- |
| `kag/`, `scripts/` | 学習コード（入口は `scripts/train.py`） |
| `data/bc_top110/` | 上位試合 3,309軌跡・89チーム（所持金11万以上、7日分） |
| `data/bc_majkel/` | Majkel1337 の886試合（専門化用） |
| `pyproject.toml` | uv用の依存定義（torch cu132 + numpy + pandas） |
| `*.sbatch`, `submit_*.sh` | ジョブスクリプト |

## 2. 環境構築（ログインノードで実行）

`uv` はログインノードでのみ使用します（ガイド4.1）。初回のみ必要です。

```
cd ~/kaggriculture
uv lock
uv sync --locked
```

## 3. 動作確認（小さいGPUで1分）

```
sbatch -J smoke -p a100_1g --gres=gpu:1g.10gb:1 --qos=low gpu_smoke.sbatch
```

```
cat smoke-<ジョブID>.out
```

`GPU is available` が出れば成功です。

## 4. 学習の投入（2本だけ）

```
bash submit_general.sh
```

- **1本目（汎用）**: 89チームの上位試合3,309軌跡で学習。A100で2〜3時間の見込み
- **2本目（専門化）**: 1本目の結果を引き継ぎ、Majkel1337 の886試合で微調整。30分ほど

2本目は `--dependency=afterok` 付きで投入されるので、1本目が正常終了するまで待機し、自動で始まります。途中で何かを見張る必要はありません。

## 5. 状況の確認

```
squeue -u "$USER"
```

```
tail -f gen_d256-<ジョブID>.out
```

`ST` が `PD` は順番待ち、`R` は実行中です。2本目は1本目が終わるまで `(Dependency)` と表示されます。

やめたいときは次のとおりです。

```
scancel <ジョブID>
```

## 6. 結果の回収（手元のPCで実行）

学習済みモデルだけを持ち帰ります。

```
ssh s<学籍番号>@<サーバーのアドレス> "cd ~/kaggriculture && tar -czf runs_best.tar.gz runs/*/best.pt runs/*/val_best.json"
```

```
scp s<学籍番号>@<サーバーのアドレス>:~/kaggriculture/runs_best.tar.gz D:\kaggriculture\
```

```
mkdir -Force D:\kaggriculture\runs_server | Out-Null; tar -xzf D:\kaggriculture\runs_best.tar.gz -C D:\kaggriculture\runs_server --strip-components=1
```

較正・書き出し・対戦評価は手元で1コマンドです。

```
python scripts/eval_server_runs.py runs_server --seeds 32 --seed-start 800000
```

## 7. 後片付け（学習が終わったら）

手元に元データがあるので、サーバー側は残さなくて構いません。

```
cd ~/kaggriculture && rm -rf data
```

```
uv cache clean
```

```
xfs_quota -c 'quota -h' /home
```

## 8. 比較の基準（手元での実測）

| モデル | 学習データ | 一致率 | あなたのエージェントとの対戦（64試合） |
| --- | --- | --- | --- |
| m_d128 | Majkel 458試合 | 0.914 | 10勝/128試合、83〜92k 対 115〜117k |
| **m_d256** | Majkel 458試合 | 0.915 | **25勝/128試合、92.6k 対 約105k** |
| m_d384 | Majkel 458試合 | 0.915 | 3勝/64試合 |

一致率は実戦の強さをほとんど予測しません（0.9142と0.9154で実戦成績は2.5倍違いました）。
**判断は必ず対戦評価で行ってください。**
