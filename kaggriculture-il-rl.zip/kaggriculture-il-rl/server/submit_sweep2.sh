#!/bin/bash
# Second sweep: explore around d=256, which was the only size that helped in actual play
# (25/128 wins vs the user's agents, against 10/128 for d=128 — while val unit_acc moved
# only 0.9142 -> 0.9154, so pick the winner by play, not by accuracy).
# Run on the LOGIN node after `uv sync --locked`.

set -euo pipefail

sub() {  # sub <name> <data_dir> <train.py args...>
  local name=$1 data=$2
  shift 2
  sbatch -J "$name" -p a100 --gres=gpu:a100:1 --qos=low \
    train_bc.sbatch "$data" "runs/$name" "$@"
}

# Width around the winner.
sub m2_d192_l6  data/bc_majkel --d 192 --layers 6 --epochs 16 --bs 256 --lr 6e-4
sub m2_d320_l6  data/bc_majkel --d 320 --layers 6 --epochs 16 --bs 256 --lr 6e-4

# Depth at the winning width.
sub m2_d256_l4  data/bc_majkel --d 256 --layers 4 --epochs 16 --bs 256 --lr 6e-4
sub m2_d256_l8  data/bc_majkel --d 256 --layers 8 --epochs 16 --bs 256 --lr 6e-4

# Same recipe, different initialisation: shows how much of the gap is run-to-run noise.
sub m2_d256_l6b data/bc_majkel --d 256 --layers 6 --epochs 16 --bs 256 --lr 6e-4

# Learning rate and schedule length at the winning size.
sub m2_d256_lr8 data/bc_majkel --d 256 --layers 6 --epochs 16 --bs 256 --lr 8e-4
sub m2_d256_e24 data/bc_majkel --d 256 --layers 6 --epochs 24 --bs 256 --lr 6e-4

squeue -u "$USER"
