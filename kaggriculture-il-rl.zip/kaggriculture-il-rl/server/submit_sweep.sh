#!/bin/bash
# Submit the BC model-size sweep (run on the LOGIN node, after `uv sync --locked`).
# `low` allows 8 concurrent jobs per person, so these six run side by side.
# Local reference (RTX 3060, d=128 layers=3): Majkel 0.915 / SpaTaro 0.830 val unit_acc.

set -euo pipefail

sub() {  # sub <name> <data_dir> <train.py args...>
  local name=$1 data=$2
  shift 2
  sbatch -J "$name" -p a100 --gres=gpu:a100:1 --qos=low \
    train_bc.sbatch "$data" "runs/$name" "$@"
}

# Control: same size as the local run, to confirm the server reproduces it.
sub m_d128     data/bc_majkel  --d 128 --layers 3 --epochs 12 --bs 192 --lr 8e-4

# Bigger models on the same data.
sub m_d256     data/bc_majkel  --d 256 --layers 6 --epochs 16 --bs 256 --lr 6e-4
sub m_d384     data/bc_majkel  --d 384 --layers 8 --epochs 16 --bs 256 --lr 4e-4
sub m_d512     data/bc_majkel  --d 512 --layers 8 --heads 8 --epochs 16 --bs 256 --lr 3e-4

# Longer schedule at a middling size.
sub m_d256_e30 data/bc_majkel  --d 256 --layers 6 --epochs 30 --bs 256 --lr 6e-4

# Same recipe on the SpaTaro data, to see whether size helps both demonstrators.
sub s_d256     data/bc_spataro --d 256 --layers 6 --epochs 16 --bs 256 --lr 6e-4

squeue -u "$USER"
