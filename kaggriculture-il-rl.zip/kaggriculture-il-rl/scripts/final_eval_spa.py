"""Final comparison on fresh seeds (300000-300011, both seats, 7 tapes = 168 games per candidate):
previous best, SpaTaro BC (greedy / sampled), RL checkpoints. Results: REPORT.md section 8-5.

Usage: python scripts/final_eval_spa.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

SPA = "data/d0913/tapes/108702317_s1.json"
HK = "data/d0910/tapes/107311366_s0.json"
TAPES = ("d0910:Himanshu Kumar,d0910:kanno,d0910:Unknown Mother-Goose,d0910:ymg_aq,d0910:Otter Vibe,"
         "d0910:binghua,d0913:Majkel1337")


def bc(weights, **kw):
    return json.dumps({"kind": "bc", "weights": weights, "kwargs": kw})


SAMPLE = {"sample": True, "tau_u": 0.5, "tau_m": 1.0, "seed": 1, "feed_topup": False, "opening": SPA, "opening_steps": 72}
CANDS = [
    bc("runs/bc_v1/final.npz", theta_scale=0.65, feed_topup=False, opening=HK, opening_steps=72),
    bc("runs/bc_spa/final.npz", theta_scale=0.65, feed_topup=False, opening=SPA, opening_steps=72),
    bc("runs/bc_spa/final.npz", **SAMPLE),
    bc("runs/rl_spa/it020.npz", **SAMPLE),
    bc("runs/rl_spa/it030.npz", **SAMPLE),
    bc("runs/rl_spa/it040.npz", **SAMPLE),
]

if __name__ == "__main__":
    os.chdir(ROOT)
    import screen
    argv = ["screen.py", "--tapes", TAPES, "--seeds", "12", "--seed-start", "300000",
            "--save", "runs/rl_spa/final_eval.json"]
    for c in CANDS:
        argv += ["--cand", c]
    sys.argv = argv
    screen.main()
