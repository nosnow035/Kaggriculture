"""Where does our ladder agent lose? Summarise downloaded Kaggle replays of our own submission.

For each episode: opponent, result, money margin, the day the result was decided, and a
board census (animals, crops, land, hands) at a few checkpoints for both players. Then
compare what the winners had that we did not.

  python scripts/ladder_audit.py data/v47_ladder [--team kitano0104]
"""
import argparse
import collections
import glob
import json
import os

CHECK_DAYS = (5, 10, 15, 20, 29)
ANIMALS = ("GOOSE", "COW", "SHEEP")
CROPS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON")


def census(farm):
    c = collections.Counter()
    for row in farm["tiles"]:
        for t in row:
            if isinstance(t, dict):
                c[t.get("animal") or t.get("crop") or t.get("kind")] += 1
    return {
        **{a: c[a] for a in ANIMALS},
        **{k: c[k] for k in CROPS},
        "land": len(farm.get("unlocked_quadrants") or []),
        "hands": len(farm.get("hands") or []),
    }


def summarise(path, team):
    with open(path, encoding="utf-8") as f:
        r = json.load(f)
    names = r["info"]["TeamNames"]
    if team not in names:
        return None
    me = names.index(team)
    op = 1 - me
    steps = r["steps"]
    money = [[s[0]["observation"]["farms"][k]["money"] for s in steps] for k in (0, 1)]
    final = [float(r["rewards"][k] or 0) for k in (0, 1)]
    # the last day on which the eventual loser was still ahead (or level)
    lead_day = None
    winner = me if final[me] > final[op] else op
    loser = 1 - winner
    for i in range(0, len(steps), 24):
        if money[loser][i] >= money[winner][i]:
            lead_day = i // 24
    cen = {}
    for d in CHECK_DAYS:
        i = min(d * 24, len(steps) - 1)
        farms = steps[i][0]["observation"]["farms"]
        cen[d] = (census(farms[me]), census(farms[op]))
    last_obs = steps[-1][me]["observation"]
    return {
        "episode": r["info"]["EpisodeId"],
        "opp": names[op],
        "me": final[me],
        "op": final[op],
        "win": final[me] > final[op],
        "tie": final[me] == final[op],
        "lead_day": lead_day,
        "money_by_day": [(money[me][i], money[op][i]) for i in range(0, len(steps), 24)],
        "census": cen,
        "shops": sorted(steps[-1][0]["observation"]["town"]["unlocked_shops"]),
        "overage": last_obs.get("remainingOverageTime"),
        "status": r["statuses"][me],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--team", default="kitano0104")
    a = ap.parse_args()

    rows = []
    for p in sorted(glob.glob(os.path.join(a.folder, "episode-*-replay.json"))):
        try:
            s = summarise(p, a.team)
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            print(f"skip {os.path.basename(p)}: {e!r}")
            continue
        if s:
            rows.append(s)
    if not rows:
        raise SystemExit("no replays for that team")

    wins = [r for r in rows if r["win"]]
    losses = [r for r in rows if not r["win"] and not r["tie"]]
    print(f"{len(rows)} games: {len(wins)} W / {len(losses)} L / {len(rows) - len(wins) - len(losses)} T   "
          f"statuses {collections.Counter(r['status'] for r in rows)}")
    ov = [r["overage"] for r in rows if r["overage"] is not None]
    if ov:
        print(f"remaining overage time at the end: min {min(ov):.1f}s, mean {sum(ov) / len(ov):.1f}s")

    print("\nby opponent (W-L, mean money me vs them):")
    by = collections.defaultdict(list)
    for r in rows:
        by[r["opp"]].append(r)
    for name, rs in sorted(by.items(), key=lambda kv: -len(kv[1])):
        w = sum(r["win"] for r in rs)
        l = sum(1 for r in rs if not r["win"] and not r["tie"])
        print(f"  {name[:28]:28s} {w:2d}-{l:<2d}  {sum(r['me'] for r in rs) / len(rs):8.0f} vs "
              f"{sum(r['op'] for r in rs) / len(rs):8.0f}")

    print("\nlosses, closest first (margin, day the result was settled):")
    for r in sorted(losses, key=lambda r: r["op"] - r["me"]):
        print(f"  {r['episode']}  vs {r['opp'][:24]:24s} {r['me']:8.0f} vs {r['op']:8.0f}  "
              f"margin {r['me'] - r['op']:+7.0f}  loser last level on day {r['lead_day']}")

    def mean_census(rs, side, day):
        out = collections.Counter()
        for r in rs:
            out.update(r["census"][day][side])
        return {k: v / max(1, len(rs)) for k, v in out.items()}

    keys = list(ANIMALS) + list(CROPS) + ["land", "hands"]
    for day in CHECK_DAYS:
        print(f"\nday {day} board census (mean tiles):")
        print(f"  {'':22s} " + " ".join(f"{k[:6]:>6s}" for k in keys))
        for label, rs, side in (("wins: us", wins, 0), ("wins: them", wins, 1),
                                ("losses: us", losses, 0), ("losses: them", losses, 1)):
            if rs:
                m = mean_census(rs, side, day)
                print(f"  {label:22s} " + " ".join(f"{m.get(k, 0):6.1f}" for k in keys))

    print("\nmoney by day, mean over losses (us vs them) -- where the gap opens:")
    if losses:
        days = len(losses[0]["money_by_day"])
        for d in range(0, days, 3):
            mu = sum(r["money_by_day"][d][0] for r in losses) / len(losses)
            mt = sum(r["money_by_day"][d][1] for r in losses) / len(losses)
            print(f"  day {d:2d}  {mu:8.0f} vs {mt:8.0f}  gap {mu - mt:+7.0f}")

    with open(os.path.join(a.folder, "audit.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f)
    print(f"\nwrote {os.path.join(a.folder, 'audit.json')}")


if __name__ == "__main__":
    main()
