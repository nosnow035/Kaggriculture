"""Build BC arrays for the selected seats of a daily episodes zip.

Usage: python scripts/build_dataset.py <episodes.zip> <index.csv> <out_dir> [min_reward] [team]
Writes <out_dir>/<episode>_s<seat>.npz and <out_dir>/meta.csv. With [team], only that team's seats.
"""
import csv
import json
import multiprocessing as mp
import os
import sys
import zipfile

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.dataset import build_seat  # noqa: E402


def work(args):
    zpath, member, seats, out_dir = args
    with zipfile.ZipFile(zpath) as z:
        with z.open(member) as f:
            rep = json.load(f)
    out = []
    for seat, reward, opp in seats:
        st = {}
        arrays = build_seat(rep, seat, st)
        ep = os.path.splitext(os.path.basename(member))[0]
        path = os.path.join(out_dir, f"{ep}_s{seat}.npz")
        np.savez_compressed(path, **arrays)
        out.append({"episode": ep, "seat": seat, "path": path, "reward": reward, "opp_reward": opp,
                    "steps": len(arrays["glob"]), "rows": len(arrays["u_y"]), **st})
    return out


def main():
    zpath, index_csv, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    min_reward = float(sys.argv[4]) if len(sys.argv) > 4 else 100_000
    os.makedirs(out_dir, exist_ok=True)
    df = pd.read_csv(index_csv)
    df = df[(df.status == "DONE") & (df.reward >= min_reward)]
    if len(sys.argv) > 5 and sys.argv[5] not in ("*", "ALL"):
        df = df[df.name == sys.argv[5]]
    if os.environ.get("BUILD_WINS_ONLY"):
        df = df[df.reward > df.opp_reward]
    jobs = []
    for member, g in df.groupby("member"):
        seats = [(int(r.seat), float(r.reward), float(r.opp_reward)) for r in g.itertuples()]
        jobs.append((zpath, member, seats, out_dir))
    print(f"episodes {len(jobs)}  seats {len(df)}  (reward >= {min_reward:.0f})", flush=True)
    rows = []
    with mp.get_context("spawn").Pool(int(os.environ.get("BUILD_PROCS", max(1, (os.cpu_count() or 2) - 2)))) as pool:
        for i, r in enumerate(pool.imap_unordered(work, jobs, chunksize=1)):
            rows.extend(r)
            if (i + 1) % 50 == 0:
                print(f"{i + 1}/{len(jobs)}", flush=True)
    keys = sorted({k for r in rows for k in r})
    with open(os.path.join(out_dir, "meta.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    tot = {k: sum(r.get(k, 0) for r in rows) for k in ("ok", "illegal", "no_label", "unmodelled")}
    print("done:", len(rows), "trajectories", tot)


if __name__ == "__main__":
    main()
