"""Replay one deterministic game and show what each unit chose on selected days, and where
FEED ranked among its legal candidates. Used to debug late-game animal starvation.

Usage: python scripts/debug_feed.py <weights> <opponent_tape.json> <seed> [days=23,24,25]
"""
import contextlib
import io
import os
import sys
from collections import Counter

import numpy as np

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.agents.bc import BCPolicy, _to_plain  # noqa: E402
from kag.agents.tape import make_tape_agent  # noqa: E402
from kag.features import (K_T, PASS_IDX, SHED_BASE, SHED_OPS, TILE_OPS, TOP, base_masks, full_mask,  # noqa: E402
                          unit_feats, unit_gate_bits, unit_positions)
from kag.replay import obs_step  # noqa: E402


def cname(c):
    if c < SHED_BASE:
        return TILE_OPS[c % K_T]
    return SHED_OPS[c - SHED_BASE] if c < PASS_IDX else "PASS"


def main():
    weights, tape, seed = sys.argv[1], sys.argv[2], int(sys.argv[3])
    days = [int(d) for d in (sys.argv[4] if len(sys.argv) > 4 else "23,24,25").split(",")]
    pol = BCPolicy(weights)
    real_forward = pol.be.forward
    stash = {}

    def forward(*args, **kw):
        out = real_forward(*args, **kw)
        stash["ulog"] = out[1].astype(np.float64)
        return out

    pol.be.forward = forward
    per_day = {d: Counter() for d in days}
    rows = []

    def agent(obs, config=None):
        o = _to_plain(obs)
        o["step"] = obs_step(o)
        act = pol.act(obs)
        day, hour = int(o["day"]), int(o["hour"])
        if day not in days:
            return act
        me = int(o["player"])
        tm, sm = base_masks(o, me)
        pos = unit_positions(o["farms"][me])
        units = [act["farmer"]] + act["hands"]
        ulog = stash["ulog"].copy()
        ulog[:, PASS_IDX] += pol.pass_offset
        feed_legal_units = 0
        for k, p in enumerate(pos):
            _, inv = unit_feats(o, me, k, p)
            gate = unit_gate_bits(inv)
            m = full_mask(tm, sm, gate)
            lg = np.where(m, ulog[k], -1e9)
            feed_idx = [t * K_T + TOP["FEED"] for t in range(100) if m[t * K_T + TOP["FEED"]]]
            top = int(np.argmax(lg))
            op = units[k][0]
            intent = pol.intents.get(k)
            label = cname(intent) + "(walk)" if intent is not None and op in ("NORTH", "SOUTH", "EAST", "WEST") else op
            per_day[day][label] += 1
            if feed_idx:
                feed_legal_units += 1
                best_feed = max(lg[i] for i in feed_idx)
                rank = int((lg > best_feed).sum())
                per_day[day]["_feed_legal_unitsteps"] += 1
                per_day[day]["_feed_rank_sum"] += rank
                if hour in (2, 8, 14) and len(rows) < 60:
                    rows.append(f"d{day} h{hour:2d} u{k:2d} wheat={inv.get('WHEAT', 0)} op={label:<22} "
                                f"top={cname(top):<18} feed_rank={rank:3d} gap={lg[top] - best_feed:6.2f}")
        unfed = sum(1 for row in o["farms"][me]["tiles"] for t in row
                    if isinstance(t, dict) and t.get("animal") and not t.get("fed_today"))
        per_day[day]["_unfed_sum"] += unfed
        return act

    with contextlib.redirect_stdout(io.StringIO()):
        from kaggle_environments import make
    env = make("kaggriculture", configuration={"seed": seed})
    env.run([agent, make_tape_agent(tape)])
    print("final money:", [s.reward for s in env.steps[-1]])
    for d in days:
        c = per_day[d]
        n = c.pop("_feed_legal_unitsteps", 0)
        rs = c.pop("_feed_rank_sum", 0)
        uf = c.pop("_unfed_sum", 0)
        print(f"\nday {d}: unit-steps where FEED was legal: {n}, mean FEED rank {rs / max(1, n):.1f}, "
              f"mean unfed animals per step {uf / 24:.1f}")
        print("  chosen:", c.most_common(12))
    print("\nsamples (hours 2/8/14):")
    print("\n".join(rows))


if __name__ == "__main__":
    main()
