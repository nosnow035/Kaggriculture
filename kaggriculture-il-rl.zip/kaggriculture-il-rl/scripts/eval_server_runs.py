"""Calibrate, export and benchmark checkpoints trained on the IS compute server.

Usage: python scripts/eval_server_runs.py <runs_dir> [--seeds 32] [--seed-start 600000] [--force]
Expects <runs_dir>/<name>/best.pt, where the name starts with "m_" for models trained on
data/bc_majkel and "s_" for data/bc_spataro (that is what server/submit_sweep.sh produces).

For each checkpoint it runs calibrate.py and export_np.py (skipped when final.npz already
exists), then one screen.py pass over every candidate against the agents in opponents/,
so all models are compared on the same seeds in a single worker pool.
"""
import argparse
import glob
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
OPPS = [("sub1_2619", "opponents/user_sub1_2619/main.py"), ("v41_2378", "opponents/user_v41_2378/main.py")]


def data_dir_for(name):
    """Calibration uses the data the checkpoint was (last) trained on."""
    n = os.path.basename(name)
    if "mmpq" in n:
        return "data/bc_mmpq"
    if "gen" in n:
        return "data/bc_top110"
    if n.startswith("s_"):
        return "data/bc_spataro"
    return "data/bc_majkel"


def run(cmd):
    print("$", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs_dir")
    ap.add_argument("--seeds", type=int, default=32)
    ap.add_argument("--seed-start", type=int, default=600_000)
    ap.add_argument("--force", action="store_true", help="re-calibrate and re-export even if final.npz exists")
    ap.add_argument("--kwargs", default='{"theta_scale": 1.0, "feed_topup": false}')
    a = ap.parse_args()

    cands = []
    for ck in sorted(glob.glob(os.path.join(a.runs_dir, "*", "best.pt"))):
        run_dir = os.path.dirname(ck)
        npz = os.path.join(run_dir, "final.npz")
        if a.force or not os.path.exists(npz):
            run([PY, "scripts/calibrate.py", ck, data_dir_for(run_dir)])
            run([PY, "scripts/export_np.py", ck, npz])
        kw = json.loads(a.kwargs)
        cands.append(json.dumps({"kind": "bc", "weights": npz.replace("\\", "/"), "kwargs": kw}))
        with open(os.path.join(run_dir, "val_best.json"), encoding="utf-8") as f:
            print(f"{os.path.basename(run_dir):>12}  val unit_acc {json.load(f)['unit_acc']:.4f}", flush=True)
    if not cands:
        print("no best.pt found under", a.runs_dir)
        return 1

    cmd = [PY, "-u", "scripts/screen.py", "--tapes", "none", "--alternate",
           "--seeds", str(a.seeds), "--seed-start", str(a.seed_start),
           "--save", os.path.join(a.runs_dir, "bench.json")]
    for label, path in OPPS:
        cmd += ["--opp-file", f"{label}={path}"]
    for c in cands:
        cmd += ["--cand", c]
    run(cmd)
    return 0


if __name__ == "__main__":
    sys.exit(main())
