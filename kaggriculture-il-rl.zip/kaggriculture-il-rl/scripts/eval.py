"""Evaluate one candidate against one or more opponents on paired seeds, both seats.

Usage:
  python scripts/eval.py --cand '{"kind":"tape","path":"..."}' --opp starter --seeds 20
"""
import argparse
import json
import os
import sys
import time

# One BLAS thread per worker: 11 parallel games would otherwise oversubscribe the CPU.
for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.agents.registry import spec_name  # noqa: E402
from kag.evaluate import evaluate  # noqa: E402


def parse_spec(s):
    s = s.strip()
    return json.loads(s) if s.startswith("{") else s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cand", required=True)
    ap.add_argument("--opp", required=True, action="append")
    ap.add_argument("--seeds", type=int, default=20)
    ap.add_argument("--seed-start", type=int, default=100_000)
    ap.add_argument("--procs", type=int, default=None)
    a = ap.parse_args()
    cand = parse_spec(a.cand)
    seeds = list(range(a.seed_start, a.seed_start + a.seeds))
    for o in a.opp:
        opp = parse_spec(o)
        t = time.time()
        summ, _ = evaluate(cand, opp, seeds, procs=a.procs)
        lo, hi = summ["ci95"]
        print(f"{spec_name(cand)} vs {spec_name(opp)}: score {summ['score']:.3f} "
              f"[{lo:.3f},{hi:.3f}]  W/L/T {summ['wins']}/{summ['losses']}/{summ['ties']}  "
              f"err {summ['errors']}  money {summ['cand_money']:.0f} vs {summ['opp_money']:.0f}  "
              f"({time.time() - t:.0f}s, n={summ['n']})", flush=True)


if __name__ == "__main__":
    main()
