"""Export a torch checkpoint to the .npz format read by kag.np_model.NPNet.

Usage: python scripts/export_np.py <ckpt.pt> <out.npz>
"""
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    ck = torch.load(sys.argv[1], map_location="cpu", weights_only=False)
    arrays = {k: v.float().numpy() for k, v in ck["state"].items()}
    arrays["__cfg__"] = np.array(json.dumps(ck["cfg"]))
    dec = dict(ck.get("decode", {}))
    sm = ck.get("style_map") or {}
    if len(sys.argv) > 3:
        s = sys.argv[3]
        dec["style"] = int(s) if s.isdigit() else sm[s]
    arrays["__decode__"] = np.array(json.dumps(dec))
    arrays["__styles__"] = np.array(json.dumps(sm))
    np.savez_compressed(sys.argv[2], **arrays)
    print("wrote", sys.argv[2], round(os.path.getsize(sys.argv[2]) / 1e6, 2), "MB")


if __name__ == "__main__":
    main()
