"""Calibrate decoding on the validation episodes and store it in the checkpoint.

- Market heads: act only when P(non-zero) >= theta_h, theta_h chosen to maximise the
  F1 of "does anything happen on this head" (argmax under-fires on rare events,
  forum #738079).
- PASS: a logit offset so the predicted PASS rate matches the demonstrated rate.

Usage: python scripts/calibrate.py <ckpt.pt> <data_dir>
"""
import os
import sys

import numpy as np
import pandas as pd
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from kag.features import PASS_IDX  # noqa: E402
from kag.model import BCNet  # noqa: E402
from train import HEAD_SLICES, Store, forward, is_val, traj_styles, unit_mask  # noqa: E402

PASS_SAMPLE_ROWS = 300_000  # unit rows kept for the PASS-offset search


@torch.no_grad()
def main():
    ck_path, data_dir = sys.argv[1], sys.argv[2]
    dev = "cuda"
    ck = torch.load(ck_path, map_location=dev, weights_only=False)
    model = BCNet(**ck["cfg"]).to(dev)
    model.load_state_dict(ck["state"])
    model.eval()
    meta = pd.read_csv(os.path.join(data_dir, "meta.csv"))
    va_m = meta[meta.episode.map(is_val)]
    style_map = ck.get("style_map") or {}
    styles = traj_styles(va_m, style_map, ck.get("index_csv", "")) if style_map else None
    va = Store(va_m.path.tolist(), [1.0] * len(va_m), styles)
    probs = [[] for _ in HEAD_SLICES]
    tgts = [[] for _ in HEAD_SLICES]
    ulogs, ys = [], []
    steps = np.arange(va.n_steps)
    for i in range(0, len(steps), 192):
        b = va.batch(steps[i:i + 192], dev)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            ulog, pk, mlog, _ = forward(model, b)
        mask = unit_mask(b)
        ul = ulog.float().masked_fill(~mask, -1e9)
        # The PASS offset only needs a sample; keeping every row costs 1707 floats each
        # (a 2M-row validation set would be 13.7 GiB).
        if sum(len(u) for u in ulogs) < PASS_SAMPLE_ROWS:
            ulogs.append(ul.cpu().numpy().astype(np.float32))
            ys.append(b["u_y"].cpu().numpy())
        for h, (name, a, z) in enumerate(HEAD_SLICES):
            probs[h].append(torch.softmax(mlog[:, a:z].float(), -1).cpu().numpy())
            tgts[h].append(b["mkt"][:, h].cpu().numpy())
    theta = {}
    print(f"{'head':>16} {'events':>7} {'argmaxF1':>8} {'theta':>6} {'F1':>6} {'qty_acc':>7}")
    for h, (name, _, _) in enumerate(HEAD_SLICES):
        p = np.concatenate(probs[h])
        t = np.concatenate(tgts[h])
        ev = t != 0
        if ev.sum() == 0:
            theta[name] = 0.99
            continue

        def f1(pred):
            tp = (pred & ev).sum()
            return 2 * tp / max(1, pred.sum() + ev.sum())

        base = f1(p.argmax(-1) != 0)
        pe = 1.0 - p[:, 0]
        grid = np.linspace(0.02, 0.98, 49)
        scores = [f1(pe >= g) for g in grid]
        g = float(grid[int(np.argmax(scores))])
        if max(scores) < 0.2:
            g = max(g, 0.5)  # unreliable head: only act when the model is confident
        theta[name] = g
        fired = (pe >= g) & ev
        qty = (p[fired][:, 1:].argmax(-1) + 1 == t[fired]).mean() if fired.any() else float("nan")
        print(f"{name:>16} {int(ev.sum()):>7} {base:8.3f} {g:6.2f} {max(scores):6.3f} {qty:7.3f}")
    ul = np.concatenate(ulogs)
    y = np.concatenate(ys)
    true_pass = (y == PASS_IDX).mean()
    best = (1e9, 0.0, 0.0)
    for off in np.linspace(-4, 4, 81):
        z = ul.copy()
        z[:, PASS_IDX] += off
        pred = z.argmax(-1)
        gap = abs((pred == PASS_IDX).mean() - true_pass)
        if gap < best[0]:
            best = (gap, float(off), float((pred == y).mean()))
    print(f"PASS rate {true_pass:.3f}: offset {best[1]:+.2f} (acc {best[2]:.4f}, "
          f"raw acc {(ul.argmax(-1) == y).mean():.4f})")
    ck["decode"] = {"theta": theta, "pass_offset": best[1]}
    torch.save(ck, ck_path)
    print("saved decode params into", ck_path)


if __name__ == "__main__":
    main()
