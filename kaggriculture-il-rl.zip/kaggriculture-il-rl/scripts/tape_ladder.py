"""Round-robin among the best tape of each chosen team (plus starter), paired seeds, both seats.

Usage: python scripts/tape_ladder.py "SpaTaro,feel the agi,..." [seeds]
"""
import itertools
import multiprocessing as mp
import os
import sys
import time

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from kag.evaluate import evaluate  # noqa: E402


def main():
    teams = sys.argv[1].split(",")
    n_seeds = int(sys.argv[2]) if len(sys.argv) > 2 else 16
    df = pd.read_csv(os.path.join(ROOT, "data", "d0910", "index.csv"))
    specs, labels = [], []
    for t in teams:
        sub = df[df.name == t].sort_values("reward", ascending=False)
        if sub.empty:
            print("no rows for", t)
            continue
        r = sub.iloc[0]
        specs.append({"kind": "tape", "path": r.tape})
        labels.append(f"{t}[{int(r.reward)}]")
    specs.append("starter")
    labels.append("starter")
    seeds = list(range(200_000, 200_000 + n_seeds))
    n = len(specs)
    score = [[None] * n for _ in range(n)]
    money = [[0.0] * n for _ in range(n)]
    t0 = time.time()
    with mp.get_context("spawn").Pool(max(1, (os.cpu_count() or 2) - 1)) as pool:
        for i, j in itertools.combinations(range(n), 2):
            s, _ = evaluate(specs[i], specs[j], seeds, pool=pool)
            score[i][j], score[j][i] = s["score"], 1 - s["score"]
            money[i][j], money[j][i] = s["cand_money"], s["opp_money"]
            print(f"{labels[i]:>32} vs {labels[j]:<32} {s['score']:.3f}  W/L/T {s['wins']}/{s['losses']}/{s['ties']}"
                  f"  money {s['cand_money']:.0f}/{s['opp_money']:.0f}", flush=True)
    print(f"\n{time.time() - t0:.0f}s, {n_seeds} seeds x 2 seats per pair")
    avg = sorted(((sum(x for x in score[i] if x is not None) / (n - 1),
                   sum(money[i]) / (n - 1), labels[i]) for i in range(n)), reverse=True)
    print("\nmean score (and mean money) across the field:")
    for sc, mo, lab in avg:
        print(f"  {sc:.3f}  {mo:9.0f}  {lab}")


if __name__ == "__main__":
    main()
