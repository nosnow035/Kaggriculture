"""Near-mirror losses: find the turn where two (almost) identical agents first split, and
what each did from there -- which product, sold by whom, at what price.

Both players' private sheds are in the replay, so a shed decrease for a sellable product is
a sale (animals and seeds are separate keys; WHEAT/FERTILIZER can also leave the shed by
PICKUP for feeding/fertilising, so those two are reported but not trusted as sales).

  python scripts/ladder_diverge.py data/v47_ladder [--team kitano0104] [--all]
"""
import argparse
import collections
import json
import os

SELLABLE = ("CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL")
AMBIGUOUS = ("WHEAT", "FERTILIZER")


def state(step, k):
    o = step[k]["observation"]
    return o["farms"][k]["money"], dict(o["private"]["shed"])


def analyse(path, team, show):
    with open(path, encoding="utf-8") as f:
        r = json.load(f)
    names = r["info"]["TeamNames"]
    if names.count(team) != 1:
        return None  # our own two bots playing each other: seat is ambiguous
    me, op = names.index(team), 1 - names.index(team)
    steps = r["steps"]
    final = [float(x or 0) for x in r["rewards"]]

    split = None
    for i, s in enumerate(steps):
        (m0, s0), (m1, s1) = state(s, me), state(s, op)
        if m0 != m1 or s0 != s1:
            split = i
            break

    sold = [collections.Counter(), collections.Counter()]
    revenue = [collections.Counter(), collections.Counter()]
    events = []
    for i in range(max(1, split or 1), len(steps)):
        prices = steps[i - 1][0]["observation"]["market"]["prices"]
        for side, k in ((0, me), (1, op)):
            _, before = state(steps[i - 1], k)
            _, after = state(steps[i], k)
            for item in SELLABLE + AMBIGUOUS:
                d = before.get(item, 0) - after.get(item, 0)
                if d > 0:
                    sold[side][item] += d
                    revenue[side][item] += d * prices[item]
                    if item in SELLABLE and len(events) < 400:
                        events.append((i, side, item, d, prices[item]))

    out = {
        "episode": r["info"]["EpisodeId"], "opp": names[op], "margin": final[me] - final[op],
        "split": split, "sold": sold, "revenue": revenue,
    }
    if show:
        day = f"day {split // 24}.{split % 24:02d}" if split is not None else "never"
        print(f"\n=== {out['episode']} vs {out['opp'][:24]}  margin {out['margin']:+.0f}  "
              f"first split at step {split} ({day}) ===")
        if split is not None:
            (m0, s0), (m1, s1) = state(steps[split], me), state(steps[split], op)
            diff = {k: (s0.get(k, 0), s1.get(k, 0)) for k in set(s0) | set(s1) if s0.get(k, 0) != s1.get(k, 0)}
            print(f"  at the split: money {m0:.0f} vs {m1:.0f}; shed differences (us, them): {diff}")
        print(f"  {'item':11s} {'us sold':>8s} {'them':>6s} {'us $':>8s} {'them $':>8s} {'us avg':>7s} {'them avg':>8s}")
        for item in SELLABLE + AMBIGUOUS:
            a, b = sold[0][item], sold[1][item]
            if a or b:
                ra, rb = revenue[0][item], revenue[1][item]
                tag = "  (may include pickups)" if item in AMBIGUOUS else ""
                print(f"  {item:11s} {a:8d} {b:6d} {ra:8.0f} {rb:8.0f} "
                      f"{(ra / a if a else 0):7.1f} {(rb / b if b else 0):8.1f}{tag}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--team", default="kitano0104")
    ap.add_argument("--all", action="store_true", help="also analyse wins")
    a = ap.parse_args()

    with open(os.path.join(a.folder, "audit.json"), encoding="utf-8") as f:
        audit = json.load(f)
    pick = [x for x in audit if a.all or (not x["win"] and not x["tie"])]
    results = []
    for x in sorted(pick, key=lambda x: x["me"] - x["op"], reverse=True):
        p = os.path.join(a.folder, f"episode-{x['episode']}-replay.json")
        res = analyse(p, a.team, show=True)
        if res:
            results.append(res)

    print("\n\n=== summed over these games: revenue gap by product (us - them) ===")
    gap = collections.Counter()
    for res in results:
        for item in SELLABLE + AMBIGUOUS:
            gap[item] += res["revenue"][0][item] - res["revenue"][1][item]
    for item, g in sorted(gap.items(), key=lambda kv: kv[1]):
        tag = "  (may include pickups)" if item in AMBIGUOUS else ""
        print(f"  {item:11s} {g:+9.0f}{tag}")
    splits = [res["split"] for res in results if res["split"] is not None]
    if splits:
        print(f"\nfirst split: earliest step {min(splits)}, median step {sorted(splits)[len(splits) // 2]}, "
              f"latest step {max(splits)}   (step // 24 = day)")


if __name__ == "__main__":
    main()
