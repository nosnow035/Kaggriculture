"""Play one game and print a compact timeline for both seats, to see where a policy drifts.

Usage: python scripts/diagnose.py --a SPEC --b SPEC --seed N
"""
import argparse
import contextlib
import io
import json
import os
import sys
from collections import Counter

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.agents.registry import build_agent, spec_name  # noqa: E402


def parse_spec(s):
    s = s.strip()
    return json.loads(s) if s.startswith("{") else s


def farm_mix(farm):
    c = Counter()
    for row in farm["tiles"]:
        for t in row:
            if t is None:
                c["empty"] += 1
            elif t == "LOCKED":
                continue
            elif t.get("kind") == "WEED":
                c["weed"] += 1
            elif t.get("kind") == "PLANT":
                c[t["crop"].lower()] += 1
            elif t.get("animal"):
                c[t["animal"].lower()] += 1
            else:
                c["empty_" + t["kind"].lower()] += 1
    return dict(c)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", required=True)
    ap.add_argument("--b", required=True)
    ap.add_argument("--seed", type=int, default=100_000)
    ap.add_argument("--animals", action="store_true", help="per-day feeding timeline for seat 0")
    a = ap.parse_args()
    specs = [parse_spec(a.a), parse_spec(a.b)]
    with contextlib.redirect_stdout(io.StringIO()):
        from kaggle_environments import make
    env = make("kaggriculture", configuration={"seed": a.seed})
    env.run([build_agent(specs[0]), build_agent(specs[1])])
    steps = env.steps
    print(f"seed {a.seed}: " + "  vs  ".join(f"{spec_name(s)} ${steps[-1][i].reward:.0f}" for i, s in enumerate(specs)))
    for seat in (0, 1):
        ops, mk, hands = Counter(), Counter(), {}
        for t in range(1, len(steps)):
            act = steps[t][seat].action or {}
            day = (t - 1) // 24
            hands[day] = max(hands.get(day, 0), len(act.get("hands") or []))
            for u in [act.get("farmer")] + list(act.get("hands") or []):
                if u:
                    ops[u[0]] += 1
            for o in act.get("market") or []:
                if o[0] in ("HIRE", "BUY_LAND"):
                    mk[o[0]] += 1
                elif len(o) >= 3:
                    mk[f"{o[0]}:{o[1]}"] += int(o[2])
        money = [int(steps[d * 24][0].observation.farms[seat]["money"]) for d in range(0, 30, 3)]
        print(f"\n=== seat {seat} {spec_name(specs[seat])}")
        print("  money every 3 days:", money)
        print("  hands per day:", [hands.get(d, 0) for d in range(30)])
        for d in (3, 8, 15, 22, 29):
            f = steps[d * 24 + 12][0].observation.farms[seat]
            print(f"  day {d:2d} quads {len(f['unlocked_quadrants'])}: {farm_mix(f)}")
        print("  unit ops:", ops.most_common(12))
        print("  market:", mk.most_common(16))
    if a.animals:
        print("seat 0 feeding timeline: day | animals@h0 animals@h23 unfed@h23 | shed WHEAT@h23 carried | FEED ops | BUY wheat, SELL wheat")
        for d in range(30):
            s0, s23 = d * 24, min(d * 24 + 23, len(steps) - 1)
            def animals(t):
                f = steps[t][0].observation.farms[0]
                return [x for row in f["tiles"] for x in row if isinstance(x, dict) and x.get("animal")]
            a0, a23 = animals(s0), animals(s23)
            unfed = sum(1 for x in a23 if not x.get("fed_today"))
            pv = steps[s23][0].observation.private
            wheat = pv["shed"].get("WHEAT", 0)
            carried = sum(inv.get("WHEAT", 0) for inv in pv["inventories"])
            feeds = buys = sells = 0
            for t in range(s0 + 1, min(s0 + 25, len(steps))):
                act = steps[t][0].action or {}
                feeds += sum(1 for u in [act.get("farmer")] + list(act.get("hands") or []) if u and u[0] == "FEED")
                for o in act.get("market") or []:
                    if len(o) >= 3 and o[1] == "WHEAT":
                        if o[0] == "BUY_PRODUCT":
                            buys += int(o[2])
                        elif o[0] == "SELL":
                            sells += int(o[2])
            print(f"  d{d:2d} | {len(a0):3d} {len(a23):3d} {unfed:3d} | {wheat:4d} {carried:3d} | {feeds:3d} | {buys:4d} {sells:4d}")


if __name__ == "__main__":
    main()
