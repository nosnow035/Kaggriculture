"""Copy one team's full replay JSONs out of the daily episode zips.

Usage: python scripts/extract_team_replays.py [team_name]   (default: SpaTaro)
Reads data/spataro/<team>_episodes.csv (from spataro_meta.py) and writes
data/spataro/replays/<date>/<episode>.json. Files already present with the right size are skipped.
"""
import os
import shutil
import sys
import zipfile

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "spataro")


def main():
    team = sys.argv[1] if len(sys.argv) > 1 else "SpaTaro"
    df = pd.read_csv(os.path.join(OUT, f"{team}_episodes.csv"))
    done = skipped = 0
    total = len(df)
    for zpath, grp in df.groupby("zip"):
        with zipfile.ZipFile(zpath) as z:
            for _, r in grp.iterrows():
                dst_dir = os.path.join(OUT, "replays", r["date"])
                os.makedirs(dst_dir, exist_ok=True)
                dst = os.path.join(dst_dir, os.path.basename(r["member"]))
                info = z.getinfo(r["member"])
                if os.path.exists(dst) and os.path.getsize(dst) == info.file_size:
                    skipped += 1
                    continue
                tmp = dst + ".part"
                with z.open(info) as src, open(tmp, "wb") as f:
                    shutil.copyfileobj(src, f, 1 << 20)
                os.replace(tmp, dst)
                done += 1
                if (done + skipped) % 50 == 0:
                    print(f"{done + skipped}/{total}", flush=True)
    print(f"extracted {done}, skipped {skipped}, total {total}")


if __name__ == "__main__":
    main()
