"""Collect one team's episodes from extracted daily index.csv files into a single metadata CSV.

Usage: python scripts/spataro_meta.py [team_name]   (default: SpaTaro)
Reads data/d09XX/index.csv (from extract_tapes.py); writes data/spataro/<team>_episodes.csv.
Full replays stay inside data/raw/kaggriculture-episodes-<date>.zip (column zip + member).
"""
import glob
import json
import os
import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")


def main():
    team = sys.argv[1] if len(sys.argv) > 1 else "SpaTaro"
    frames = []
    for idx in sorted(glob.glob(os.path.join(DATA, "d09[0-9][0-9]", "index.csv"))):
        tag = os.path.basename(os.path.dirname(idx))  # d0910
        date = f"2026-{tag[1:3]}-{tag[3:5]}"
        df = pd.read_csv(idx)
        me = df[df["name"] == team]
        opp = df[["episode", "seat", "name"]].rename(columns={"seat": "opp_seat", "name": "opponent"})
        m = me.merge(opp, on="episode")
        m = m[m["opp_seat"] != m["seat"]].copy()
        m["date"] = date
        m["zip"] = os.path.join(DATA, "raw", f"kaggriculture-episodes-{date}.zip")
        frames.append(m)
    out = pd.concat(frames, ignore_index=True)
    out["margin"] = out["reward"] - out["opp_reward"]
    out["result"] = "L"
    out.loc[out["margin"] > 0, "result"] = "W"
    out.loc[out["margin"] == 0, "result"] = "T"
    st = out["stats"].map(json.loads)
    for k in ("BUY_LAND", "HIRE", "max_hands", "BUY_ANIMAL:COW", "BUY_ANIMAL:SHEEP", "BUY_ANIMAL:GOOSE"):
        out[k] = st.map(lambda d: d.get(k, 0))
    cols = ["date", "episode", "seat", "seed", "reward", "opp_reward", "margin", "result", "opponent",
            "status", "BUY_LAND", "HIRE", "max_hands", "BUY_ANIMAL:COW", "BUY_ANIMAL:SHEEP",
            "BUY_ANIMAL:GOOSE", "zip", "member", "tape", "stats"]
    out = out[cols].sort_values(["date", "episode"])
    os.makedirs(os.path.join(DATA, "spataro"), exist_ok=True)
    path = os.path.join(DATA, "spataro", f"{team}_episodes.csv")
    out.to_csv(path, index=False, encoding="utf-8-sig")
    print("wrote", path, len(out), "rows")

    g = out.groupby("date")
    summary = pd.DataFrame({
        "games": g.size(),
        "wins": g["result"].apply(lambda s: (s == "W").sum()),
        "win_rate": g["result"].apply(lambda s: round((s == "W").mean(), 3)),
        "mean_reward": g["reward"].mean().round(0),
        "mean_opp": g["opp_reward"].mean().round(0),
    })
    print(summary.to_string())
    last = out[out["date"] >= "2026-09-12"]
    if len(last):
        vs = last.groupby("opponent")["result"].agg(lambda s: f"{(s == 'W').sum()}-{(s != 'W').sum()}")
        n = last.groupby("opponent").size().sort_values(ascending=False)
        print("\nvs opponents (09-12..): W-L")
        print(vs[n.index].head(15).to_string())


if __name__ == "__main__":
    main()
