"""Bundle a Kaggle submission: main.py at the root, the kag runtime modules, weights.npz,
and a config.json with the decoding options (plus an optional opening-book tape).

Usage:
  python scripts/package.py <weights.npz> <out.tar.gz> [--kwargs JSON]
                            [--opening TAPE.json --opening-steps N]
"""
import argparse
import io
import json
import os
import sys
import tarfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUNTIME = ["kag/__init__.py", "kag/features.py", "kag/replay.py", "kag/np_model.py",
           "kag/agents/__init__.py", "kag/agents/bc.py"]

MAIN = '''"""Kaggriculture behaviour-cloning agent (numpy runtime)."""
import json
import os
import sys
import traceback


def _agent_dir():
    dirs = []
    try:
        dirs.append(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    dirs += ["/kaggle_simulations/agent", os.getcwd()]
    for d in dirs:
        if os.path.exists(os.path.join(d, "weights.npz")):
            return d
    return dirs[0]


_DIR = _agent_dir()
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from kag.agents.bc import BCPolicy  # noqa: E402

_STATE = {"policy": None}


def _make_policy():
    kwargs = {}
    cfg_path = os.path.join(_DIR, "config.json")
    if os.path.exists(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        kwargs = dict(cfg.get("kwargs") or {})
        if cfg.get("opening"):
            kwargs["opening"] = os.path.join(_DIR, cfg["opening"])
            kwargs["opening_steps"] = int(cfg.get("opening_steps", 0))
    return BCPolicy(os.path.join(_DIR, "weights.npz"), **kwargs)


def agent(obs, config=None):
    if _STATE["policy"] is None:
        _STATE["policy"] = _make_policy()
    try:
        return _STATE["policy"].act(obs)
    except Exception:
        traceback.print_exc()
        return {"farmer": ["PASS"], "hands": [], "market": []}
'''


def _add_bytes(tar, name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    tar.addfile(info, io.BytesIO(data))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("weights")
    ap.add_argument("out")
    ap.add_argument("--kwargs", default="{}")
    ap.add_argument("--opening", default=None)
    ap.add_argument("--opening-steps", type=int, default=0)
    a = ap.parse_args()
    cfg = {"kwargs": json.loads(a.kwargs)}
    opening_bytes = None
    if a.opening and a.opening_steps > 0:
        with open(a.opening, "r", encoding="utf-8") as f:
            acts = json.load(f)["actions"][:a.opening_steps]
        opening_bytes = json.dumps({"actions": acts}).encode("utf-8")
        cfg["opening"] = "opening.json"
        cfg["opening_steps"] = a.opening_steps
    with tarfile.open(a.out, "w:gz") as tar:
        _add_bytes(tar, "main.py", MAIN.encode("utf-8"))
        _add_bytes(tar, "config.json", json.dumps(cfg, indent=1).encode("utf-8"))
        if opening_bytes is not None:
            _add_bytes(tar, "opening.json", opening_bytes)
        for rel in RUNTIME:
            tar.add(os.path.join(ROOT, rel), arcname=rel)
        tar.add(a.weights, arcname="weights.npz")
    print("wrote", a.out, round(os.path.getsize(a.out) / 1e6, 2), "MB", "config:", json.dumps(cfg))


if __name__ == "__main__":
    sys.exit(main())
