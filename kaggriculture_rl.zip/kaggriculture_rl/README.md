# Kaggriculture 強化学習（RL）コード

`D:\kaggriculture` から強化学習に関係するファイルだけを**そのままコピー**したものです（コードは無改変）。
**チーム内共有用です。外部に公開しないでください**（Kaggle のルールでチーム外への私的共有は禁止）。

詳しい説明は同梱の [CODE_GUIDE.md](CODE_GUIDE.md) の §3（強化学習）、経緯は [WORKLOG_2026-09-17.md](WORKLOG_2026-09-17.md) の §4 と §12〜14 にあります。
GRPO 型（`rl_train.py`）の詳細は [REPORT.md](REPORT.md) の §8 です。

## 強化学習 3 系統と結果

| 手法 | コード | 出発点 | 結果 |
| --- | --- | --- | --- |
| ① GRPO 型 PPO（価値関数なし） | `scripts/rl_train.py`、`kag/rl_rollout.py` | `runs/bc_spa/best.pt` | 0.506 → 0.405〜0.440（**悪化**、40 反復・960 試合） |
| ② PPO ＋ 価値関数 ＋ GAE | `scripts/rl_ppo.py`、`kag/rl_batch.py` | `runs/v_lr03/best.pt` | 0.677 → 0.693（**横ばい**、121 反復・5,808 試合・約 11 時間） |
| ③ 選別自己模倣 | `scripts/self_imitate.py`、`si_merge.py`、`si_label.py` → `train.py` | `runs/v_lr03/best.pt` | 0.422 → 0.031〜0.133（**大幅悪化**） |

3 系統とも「1 試合 約 7,000 回の判断に対して、手がかりは試合結果 1 つ」という壁に当たりました。
残っている筋は「RL は日単位の計画（約 30 回の判断）だけを決め、実行は決定論的に行う」形です（未実装）。

## 中身

```
kag/                      ランタイム一式（RL が使う BC エージェント・モデル・特徴量・評価を含む）
  rl_rollout.py           ①のロールアウトワーカー（torch 非依存、1 試合ずつ）
  rl_batch.py             ②③のまとめ実行（K 試合を 1 回の GPU 推論で進める。1 試合 約 5〜6 秒）
scripts/
  rl_train.py             ① GRPO 型 PPO
  rl_ppo.py               ② PPO ＋ 価値関数 ＋ GAE（対戦リーグ LEAGUE・評価パネル EVAL_PANEL もここ）
  self_imitate.py         ③ 試合の生成と選別
  si_merge.py             ③ 並列シャードの統合と選別（--stratify で相手ごとに上位）
  si_label.py             ③ 古い all.csv に対戦相手の列を後付け
  train.py                RL スクリプトが import する（損失・forward）。③の微調整と、価値ヘッド付き出発点の学習にも使う
  screen.py, eval_suite.py  評価（同じ seed・同じ相手で候補を並べて比較）
  extract_tapes.py        Kaggle の日次 zip から対戦相手のテープと index.csv を作る
opponents/user_*/main.py  評価用の対戦相手（自作ルールベース 2 つ）
results/                  実行記録（ログ・設定・評価結果のみ。モデルの重みは含まない）
  runs/ppo1/              ②：args.json、ppo.log / log.jsonl（反復ごとの成績・KL・5 反復ごとの評価）
  runs/rl_spa/            ①：args.json、rl.log / log.jsonl、final_eval（最終比較）
  runs/v_lr03/            ②③の出発点（価値ヘッド付き BC）の学習ログ
  runs/si1_*/             ③の微調整 4 種の学習ログ
  runs/si_round1_*.json   ③の評価結果（seed 840000〜、各 128 試合）
  data/si_round1/, data/si_r1_*/  ③の生成試合一覧（all.csv / meta.csv）と選別結果
```

## 動かすのに必要なもの（このフォルダには入っていない）

1. **出発点のチェックポイント**：`runs/v_lr03/best.pt`（②③、24.6MB、価値ヘッド付き）、`runs/bc_spa/best.pt`（①）。
   ②は価値ヘッド（`v_mlp.*`）がないと停止します。自分で作る場合は `train.py --value-weight` で BC を学習
2. **対戦相手のテープ**：`data/d0915`、`data/d0916`（②③のリーグ）、`data/d0910`、`data/d0913`（①）。
   Kaggle の日次データセットから作ります：

   ```bash
   kaggle datasets download kaggle/kaggriculture-episodes-2026-09-16 -p data/raw
   python scripts/extract_tapes.py data/raw/kaggriculture-episodes-2026-09-16.zip data/d0916
   ```

3. **環境**：Python 3.11、PyTorch（CUDA 版）、`numpy pandas psutil jsonschema requests`、
   `pip install kaggle-environments==1.32.7 --no-deps`（依存が重いので --no-deps）

## 実行例

コマンドはこのフォルダのルートから実行します。

```bash
# まとめ実行の速度と、1 試合ずつ実行した場合との行動一致の確認
python -m kag.rl_batch runs/v_lr03/best.pt 8 --check

# ① GRPO 型 PPO
python scripts/rl_train.py --init runs/bc_spa/best.pt --out runs/rl_spa --iters 40 --groups 4 --k 6

# ② PPO ＋ 価値関数 ＋ GAE
python scripts/rl_ppo.py --init runs/v_lr03/best.pt --out runs/ppo1 --iters 50 --games 48

# ③ 選別自己模倣：生成 → 統合・選別 → 微調整
python scripts/self_imitate.py --init runs/v_lr03/best.pt --out data/si_round1/sh0 --games 400 --batch 24 --no-select --seed-start 2000000 --seed 3
python scripts/self_imitate.py --init runs/v_lr03/best.pt --out data/si_round1/sh1 --games 300 --batch 16 --no-select --seed-start 2100000 --seed 4
python scripts/si_merge.py data/si_r1_strat --shards data/si_round1/sh0 data/si_round1/sh1 --stratify --keep 0.25
python scripts/train.py data/si_r1_strat runs/si1_strat --d 256 --layers 6 --heads 4 --bs 256 --epochs 3 --lr 2e-5 --init runs/v_lr03/best.pt

# 評価（JSON を含むので Git Bash から実行）
python scripts/screen.py \
  --cand '{"kind":"bc","weights":"runs/ppo1/it120.pt","kwargs":{"calibrated":false,"feed_topup":false}}' \
  --tapes none \
  --opp-file sub1_2619=opponents/user_sub1_2619/main.py \
  --opp-file v41_2378=opponents/user_v41_2378/main.py \
  --alternate --seeds 64 --seed-start 900000 --save runs/bench.json
```

## 注意点（コードは無改変なので、元の環境依存がそのまま残っています）

- `kag/rl_batch.py` の自己テスト（`--check`）はテープの場所として `D:\kaggriculture\data\d0916\tapes` を直接参照しています。別の場所では `_self_test` のパスを書き換えてください
- `extract_tapes.py` は `index.csv` の `tape` 列に、実行時に渡した出力先を含むパスを書きます。自分の PC で作り直せば、そのまま使えます
- torch と numpy（MKL）の行列計算を 1 プロセスで混ぜない（libiomp5md の重複で落ちる）。`kag/rl_rollout.py` が torch 非依存なのはこのため
- `self_imitate.py` は 1 プロセスで 3〜5GB 使います。メモリ 16GB の PC では 2 並列まで
- 32〜64 試合の比較は接戦を見分けられません。別の seed の組同士の数字は比べないでください
