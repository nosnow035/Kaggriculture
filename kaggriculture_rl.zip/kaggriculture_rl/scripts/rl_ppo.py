"""PPO with a critic and GAE, on batched self-play.

This replaces scripts/rl_train.py, whose two weaknesses are fixed here:

  * credit assignment — the first attempt had no critic, so one win/loss had to explain
    ~7,000 decisions. Here the critic (trained on demonstration outcomes, then kept
    fresh by the PPO value loss) turns that into a per-state advantage via GAE.
  * throughput — rollouts ran one game per process through numpy. kag/rl_batch.py plays
    many games in lock-step through one batched GPU forward, which profiling says is
    where ~97% of a step went.

One iteration: play `--games` games against a league (tapes and/or the policy itself),
compute GAE, then take clipped PPO steps with an exact KL penalty to the frozen starting
policy. Evaluation against a fixed panel runs every `--eval-every` iterations.

Usage:
  python scripts/rl_ppo.py --init runs/v_lr03/best.pt --out runs/ppo1 [--iters 50 --games 48]
"""
import argparse
import json
import os
import shutil
import sys
import time

import numpy as np
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from kag.features import K_T, MARKET_HEADS, PASS_IDX  # noqa: E402
from kag.rl_batch import BatchPolicy, play_batch  # noqa: E402
from kag.model import BCNet  # noqa: E402
from train import HEAD_SLICES, VALUE_SCALE, forward, unit_mask  # noqa: E402

STEP_KEYS = ("tiles", "glob", "tmask", "smask", "claimed", "claimed_shed", "m_cls")
ROW_KEYS = ("u_feat", "u_gate", "u_self", "u_y", "u_blocked", "u_train", "u_pick")
LEAGUE = ("d0916:Majkel1337,d0916:DSM,d0916:Sida Zuo,d0916:SpaTaro,d0916:Orbital Terraformer,"
          "d0916:Excluding,d0915:Unknown Mother-Goose,d0915:ymg_aq")
EVAL_PANEL = "d0916:Majkel1337,d0916:DSM,d0916:SpaTaro,d0915:Unknown Mother-Goose"


def tapes(spec):
    """'d0916:Team,...' -> [(tape spec, label)], each team's best-money tape of that day."""
    import pandas as pd
    out = []
    for item in [s for s in spec.split(",") if s]:
        day, team = item.split(":", 1)
        df = pd.read_csv(os.path.join(ROOT, "data", day, "index.csv"))
        sub = df[(df.name == team) & (df.status == "DONE")].sort_values("reward", ascending=False)
        if sub.empty:
            print("no tape for", item, flush=True)
            continue
        out.append(({"kind": "tape", "path": sub.iloc[0].tape}, f"{team}@{day}"))
    return out


def collate(rec, values, adv, ret):
    """One game's recorded steps -> flat arrays, with per-step advantage and return."""
    out = {k: np.stack([r[k] for r in rec]) for k in STEP_KEYS}
    out["claimed_shed"] = np.array([r["claimed_shed"] for r in rec], np.uint8)
    for k in ROW_KEYS:
        out[k] = np.concatenate([r[k] for r in rec])
    out["u_step"] = np.concatenate([np.full(len(r["u_y"]), i, np.int32) for i, r in enumerate(rec)])
    out["value"] = values
    out["adv"] = adv
    out["ret"] = ret
    return out


def gae(values, terminal_reward, gamma, lam):
    """Only the last step is rewarded, so deltas are gamma*V(next) - V(now) until the end."""
    n = len(values)
    adv = np.zeros(n, np.float32)
    nxt, run = 0.0, 0.0
    for t in range(n - 1, -1, -1):
        r = terminal_reward if t == n - 1 else 0.0
        delta = r + gamma * nxt - values[t]
        run = delta + gamma * lam * run
        adv[t] = run
        nxt = values[t]
    return adv, adv + values


class RLData:
    def __init__(self, games):
        steps = {k: [] for k in STEP_KEYS}
        rows = {k: [] for k in ROW_KEYS}
        u_step, u_adv, m_adv, vtarget, u_roll, m_roll = [], [], [], [], [], []
        off = 0
        for d in games:
            S = len(d["glob"])
            for k in STEP_KEYS:
                steps[k].append(d[k])
            for k in ROW_KEYS:
                rows[k].append(d[k])
            u_step.append(d["u_step"].astype(np.int64) + off)
            u_adv.append(d["adv"][d["u_step"]])
            m_adv.append(d["adv"])
            vtarget.append(d["ret"])
            u_roll.append(d["u_logp"] if "u_logp" in d else np.zeros(len(d["u_y"]), np.float32))
            m_roll.append(d["m_logp"] if "m_logp" in d else np.zeros((S, len(MARKET_HEADS)), np.float32))
            off += S
        for k, v in steps.items():
            setattr(self, k, np.concatenate(v))
        for k, v in rows.items():
            setattr(self, k, np.concatenate(v))
        self.u_step = np.concatenate(u_step)
        self.u_adv = np.concatenate(u_adv)
        self.m_adv = np.concatenate(m_adv)
        self.vtarget = np.concatenate(vtarget)
        self.n = off
        self.row_start = np.searchsorted(self.u_step, np.arange(off), "left")
        self.row_end = np.searchsorted(self.u_step, np.arange(off), "right")
        self.old_u = np.zeros(len(self.u_y), np.float32)
        self.old_p = np.zeros(len(self.u_y), np.float32)
        self.old_m = np.zeros((off, len(MARKET_HEADS)), np.float32)
        # Normalise advantages once, over the whole iteration.
        mu, sd = float(self.m_adv.mean()), float(self.m_adv.std())
        self.u_adv = np.clip((self.u_adv - mu) / (sd + 1e-6), -5, 5).astype(np.float32)
        self.m_adv = np.clip((self.m_adv - mu) / (sd + 1e-6), -5, 5).astype(np.float32)

    def batch(self, steps, dev):
        steps = np.sort(steps)
        r = np.concatenate([np.arange(self.row_start[s], self.row_end[s]) for s in steps])
        local = np.searchsorted(steps, self.u_step[r])
        tm = np.unpackbits(self.tmask[steps], axis=-1)[..., :K_T].astype(bool)

        def t(a):
            return torch.from_numpy(np.ascontiguousarray(a)).to(dev)

        b = {
            "tiles": t(self.tiles[steps]).float().div_(255.0), "glob": t(self.glob[steps].astype(np.float32)),
            "tmask": t(tm), "smask": t(self.smask[steps]), "claimed": t(self.claimed[steps].astype(np.float32)),
            "claimed_shed": t(self.claimed_shed[steps].astype(np.float32)),
            "m_cls": t(self.m_cls[steps].astype(np.int64)), "m_adv": t(self.m_adv[steps]),
            "old_m": t(self.old_m[steps]), "vtarget": t(self.vtarget[steps]),
            "u_step": t(local), "u_feat": t(self.u_feat[r].astype(np.float32)), "u_gate": t(self.u_gate[r]),
            "u_self": t(self.u_self[r].astype(np.int64)), "u_y": t(self.u_y[r].astype(np.int64)),
            "u_blocked": t(self.u_blocked[r].astype(np.int64)), "u_train": t(self.u_train[r]),
            "u_pick": t(self.u_pick[r].astype(np.int64)), "u_adv": t(self.u_adv[r]),
            "old_u": t(self.old_u[r]), "old_p": t(self.old_p[r]),
        }
        return b, steps, r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init", required=True, help="checkpoint with a trained critic (train.py --value-weight)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--iters", type=int, default=50)
    ap.add_argument("--games", type=int, default=48, help="games per iteration, all in flight together")
    ap.add_argument("--tau-u", type=float, default=0.5)
    ap.add_argument("--tau-m", type=float, default=1.0)
    ap.add_argument("--gamma", type=float, default=1.0)
    ap.add_argument("--lam", type=float, default=0.95)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--beta", type=float, default=0.02, help="KL to the starting policy")
    ap.add_argument("--vf", type=float, default=0.5, help="critic loss weight")
    ap.add_argument("--clip", type=float, default=0.2)
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--mb", type=int, default=64, help="steps per minibatch")
    ap.add_argument("--self-play", type=float, default=0.5, help="fraction of games against the policy itself")
    ap.add_argument("--league", default=LEAGUE)
    ap.add_argument("--eval-panel", default=EVAL_PANEL)
    ap.add_argument("--eval-every", type=int, default=5)
    ap.add_argument("--eval-seeds", type=int, default=8)
    ap.add_argument("--kwargs", default='{"calibrated": false, "feed_topup": false}')
    ap.add_argument("--seed", type=int, default=11)
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    dev = "cuda"
    ck = torch.load(a.init, map_location="cpu", weights_only=False)
    model = BCNet(**ck["cfg"]).to(dev)
    if not any(k.startswith("v_mlp.") for k in ck["state"]):
        raise SystemExit(f"{a.init} has no critic. Train one first with "
                         f"scripts/train.py --init {a.init} --value-weight 2.0")
    model.load_state_dict(ck["state"])
    ref = BCNet(**ck["cfg"]).to(dev)
    ref.load_state_dict(ck["state"])
    ref.eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.0)
    pass_off = float((ck.get("decode") or {}).get("pass_offset", 0.0))

    start = 0
    last_path = os.path.join(a.out, "last.pt")
    if os.path.exists(last_path):
        st = torch.load(last_path, map_location="cpu", weights_only=False)
        model.load_state_dict(st["state"])
        opt.load_state_dict(st["opt"])
        start = st["it"] + 1
        print("resumed at iteration", start, flush=True)

    bp = BatchPolicy.__new__(BatchPolicy)  # share the learner's weights; no copy per iteration
    bp.model, bp.device, bp.cfg, bp.decode = model, dev, ck["cfg"], ck.get("decode", {})

    kw_sample = dict(json.loads(a.kwargs), sample=True, tau_u=a.tau_u, tau_m=a.tau_m, record=True)
    kw_eval = dict(json.loads(a.kwargs), sample=True, tau_u=a.tau_u, tau_m=a.tau_m)
    league = tapes(a.league)
    panel = tapes(a.eval_panel)
    rng = np.random.default_rng(a.seed)
    log_path = os.path.join(a.out, "log.jsonl")
    with open(os.path.join(a.out, "args.json"), "w") as f:
        json.dump({**vars(a), "league": [l for _, l in league]}, f, indent=1)

    def unit_logprobs(ulog, b):
        z = ulog.float().clone()
        z[:, PASS_IDX] += pass_off
        mask = unit_mask(b)
        blk = b["u_blocked"]
        valid = blk >= 0
        if valid.any():
            ri = torch.arange(len(blk), device=blk.device)[:, None].expand_as(blk)[valid]
            mask[ri, blk[valid]] = False
        return torch.log_softmax(z.masked_fill(~mask, -1e9) / a.tau_u, -1)

    def market_logprobs(mlog, cls):
        chosen, dists = [], []
        for h, (_, a0, z0) in enumerate(HEAD_SLICES):
            lp = torch.log_softmax(mlog[:, a0:z0].float() / a.tau_m, -1)
            dists.append(lp)
            chosen.append(lp.gather(1, cls[:, h:h + 1])[:, 0])
        return torch.stack(chosen, 1), dists

    @torch.no_grad()
    def fill_old(data):
        model.eval()
        for i in range(0, data.n, 256):
            b, steps, r = data.batch(np.arange(i, min(i + 256, data.n)), dev)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                ulog, pk, mlog, _ = forward(model, b)
            lp = unit_logprobs(ulog, b)
            data.old_u[r] = lp.gather(1, b["u_y"][:, None])[:, 0].cpu().numpy()
            pl = torch.log_softmax(pk.float() / a.tau_u, -1)
            data.old_p[r] = pl.gather(1, (b["u_pick"].clamp(min=1) - 1)[:, None])[:, 0].cpu().numpy()
            data.old_m[steps] = market_logprobs(mlog, b["m_cls"])[0].cpu().numpy()
        model.train()

    def ppo(data):
        acc = {k: 0.0 for k in ("pg_u", "pg_m", "vf", "kl_u", "kl_m", "clip_u")}
        nb = 0
        H = len(HEAD_SLICES)
        rng2 = np.random.default_rng()
        for _ in range(a.epochs):
            perm = rng2.permutation(data.n)
            for i in range(0, data.n, a.mb):
                b, _, _ = data.batch(perm[i:i + a.mb], dev)
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    ulog, pk, mlog, vpred = forward(model, b)
                    with torch.no_grad():
                        rulog, _, rmlog, _ = forward(ref, b)
                lp = unit_logprobs(ulog, b)
                with torch.no_grad():
                    lpr = unit_logprobs(rulog, b)
                tr = b["u_train"].float()
                ntr = tr.sum().clamp(min=1.0)
                A = b["u_adv"]
                ratio = torch.exp(lp.gather(1, b["u_y"][:, None])[:, 0] - b["old_u"])
                obj = torch.min(ratio * A, ratio.clamp(1 - a.clip, 1 + a.clip) * A)
                pg_u = -(obj * tr).sum() / ntr
                kl_u = ((lp.exp() * (lp - lpr)).sum(-1) * tr).sum() / ntr

                mlp, md = market_logprobs(mlog, b["m_cls"])
                with torch.no_grad():
                    _, mdr = market_logprobs(rmlog, b["m_cls"])
                Am = b["m_adv"][:, None]
                ratio_m = torch.exp(mlp - b["old_m"])
                pg_m = -torch.min(ratio_m * Am, ratio_m.clamp(1 - a.clip, 1 + a.clip) * Am).mean()
                kl_m = sum((l.exp() * (l - lr_)).sum(-1).mean() for l, lr_ in zip(md, mdr)) / H

                vf = ((vpred.float() - b["vtarget"]) ** 2).mean()
                loss = pg_u + pg_m + a.vf * vf + a.beta * (kl_u + kl_m)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
                with torch.no_grad():
                    acc["pg_u"] += pg_u.item()
                    acc["pg_m"] += pg_m.item()
                    acc["vf"] += vf.item()
                    acc["kl_u"] += kl_u.item()
                    acc["kl_m"] += kl_m.item()
                    acc["clip_u"] += ((((ratio - 1).abs() > a.clip).float() * tr).sum() / ntr).item()
                nb += 1
        return {k: round(v / max(1, nb), 5) for k, v in acc.items()}

    @torch.no_grad()
    def evaluate(tag):
        model.eval()
        jobs, labels = [], []
        for spec, label in panel:
            for s in range(a.eval_seeds):
                jobs.append({"seed": 950_000 + s, "seat": s % 2, "opp": spec, "sample_seed": 7000 + s})
                labels.append(label)
        res = play_batch(bp, jobs, kw_eval)
        per = {}
        for r, label in zip(res, labels):
            seat = r["job"]["seat"]
            me, op = r["money"][seat], r["money"][1 - seat]
            d = per.setdefault(label, [0, 0, 0.0, 0.0])
            d[0] += int(me > op)
            d[1] += 1
            d[2] += me
            d[3] += op
        model.train()
        out = {k: [v[0], v[1], round(v[2] / v[1]), round(v[3] / v[1])] for k, v in per.items()}
        wins = sum(v[0] for v in per.values())
        n = sum(v[1] for v in per.values())
        return {"score": round(wins / n, 3), "games": n, "money": round(sum(v[2] for v in per.values()) / n),
                "opp_money": round(sum(v[3] for v in per.values()) / n), "per": out, "tag": tag}

    for it in range(start, a.iters):
        t0 = time.time()
        model.eval()
        jobs = []
        for g in range(a.games):
            spec = "self" if rng.random() < a.self_play else league[int(rng.integers(len(league)))][0]
            jobs.append({"seed": int(1_500_000 + it * 1000 + g), "seat": int(rng.integers(2)),
                         "opp": spec, "sample_seed": int(rng.integers(2 ** 31))})
        res = play_batch(bp, jobs, kw_sample, opp_kwargs=kw_eval)
        model.train()
        t_roll = time.time() - t0

        games, mine, theirs, wins = [], [], [], 0
        for r in res:
            seat = r["job"]["seat"]
            me, op = r["money"][seat], r["money"][1 - seat]
            mine.append(me)
            theirs.append(op)
            wins += int(me > op)
            if r["status"][seat] != "DONE" or not r["rec"]:
                continue
            term = float(np.clip((me - op) / VALUE_SCALE, -1.0, 1.0))
            adv, ret = gae(r["values"], term, a.gamma, a.lam)
            games.append(collate(r["rec"], r["values"], adv, ret))

        rec = {"it": it + 1, "games": len(games), "money": round(float(np.mean(mine))),
               "opp_money": round(float(np.mean(theirs))), "win": round(wins / len(res), 3),
               "t_roll": round(t_roll), "sec_per_game": round(t_roll / max(1, len(res)), 2)}
        if games:
            data = RLData(games)
            fill_old(data)
            rec.update({"steps": int(data.n), "rows": int(len(data.u_y)), **ppo(data)})
        rec["t_iter"] = round(time.time() - t0)
        torch.save({"state": model.state_dict(), "opt": opt.state_dict(), "cfg": ck["cfg"],
                    "decode": ck.get("decode", {}), "it": it}, last_path)
        if (it + 1) % a.eval_every == 0 or it + 1 == a.iters:
            tag = os.path.join(a.out, f"it{it + 1:03d}")
            shutil.copyfile(last_path, tag + ".pt")
            rec["eval"] = evaluate(tag)
        print(json.dumps(rec), flush=True)
        with open(log_path, "a") as f:
            f.write(json.dumps(rec) + "\n")


if __name__ == "__main__":
    main()
