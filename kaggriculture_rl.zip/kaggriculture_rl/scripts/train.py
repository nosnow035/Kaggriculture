"""Train the BC policy.

Usage: python scripts/train.py <data_dir> <out_dir> [--epochs N] [--d 128] [--layers 3] [--resume]
Validation is split by *episode* (PTCG 191st: decision-level splits leak).

--resume continues from <out_dir>/last.pt (model, optimiser, schedule, epoch). Slurm `low`
jobs are preempted and requeued from the start, so long runs there must be resumable.
"""
import argparse
import json
import math
import os
import sys
import time
import zlib

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.features import K_S, K_T, MARKET_HEADS, N_CAND, NT, PASS_IDX, SHED_BASE, TILE_OPS, SHED_OPS  # noqa: E402
from kag.model import BCNet, pair_feats, shed_pair_feats  # noqa: E402

HEAD_SLICES = []
_o = 0
for _name, _n in MARKET_HEADS:
    HEAD_SLICES.append((_name, _o, _o + _n))
    _o += _n


def resolve_paths(meta, data_dir):
    """meta.csv stores the paths of the machine that built it; re-root them on data_dir."""
    def fix(p):
        p = str(p)
        if os.path.exists(p):
            return p
        base, parent = os.path.basename(p.replace("\\", "/")), os.path.basename(os.path.dirname(p.replace("\\", "/")))
        for cand in (os.path.join(data_dir, parent, base), os.path.join(data_dir, base)):
            if os.path.exists(cand):
                return cand
        raise FileNotFoundError(f"{p} not found under {data_dir}")

    meta = meta.copy()
    meta["path"] = meta["path"].map(fix)
    return meta


def team_names(meta, index_csv):
    idx = pd.read_csv(index_csv)[["episode", "seat", "name"]]
    idx["episode"] = idx.episode.astype(str)
    m = meta[["episode", "seat"]].copy()
    m["episode"] = m.episode.astype(str)
    return m.merge(idx, on=["episode", "seat"], how="left")["name"].fillna("").tolist()


def build_style_map(meta, index_csv, min_n):
    names = pd.Series(team_names(meta, index_csv))
    counts = names[names != ""].value_counts()
    keep = sorted(counts[counts >= min_n].index)
    return {t: i + 1 for i, t in enumerate(keep)}


def traj_styles(meta, style_map, index_csv):
    if not style_map:
        return [0] * len(meta)
    return [style_map.get(n, 0) for n in team_names(meta, index_csv)]


def is_val(ep):
    return zlib.crc32(str(ep).encode()) % 12 == 0


class Store:
    """All selected trajectories concatenated in RAM."""

    def __init__(self, files, weights, styles=None, values=None):
        per_step = {k: [] for k in ("tiles_q", "occ", "claimed", "claimed_shed", "tmask", "smask", "glob", "mkt")}
        rows = {k: [] for k in ("u_step", "u_feat", "u_gate", "u_y", "u_n", "u_self")}
        step_w, row_w, step_style, step_val = [], [], [], []
        off = 0
        for i, (f, w) in enumerate(zip(files, weights)):
            z = np.load(f)
            S = z["glob"].shape[0]
            for k in per_step:
                per_step[k].append(z[k])
            for k in rows:
                v = z[k].astype(np.int64) + off if k == "u_step" else z[k]
                rows[k].append(v)
            step_w.append(np.full(S, w, np.float32))
            step_style.append(np.full(S, styles[i] if styles is not None else 0, np.int64))
            step_val.append(np.full(S, values[i] if values is not None else 0.0, np.float32))
            row_w.append(np.full(len(z["u_y"]), w, np.float32))
            off += S
        for k, v in per_step.items():
            setattr(self, k, np.concatenate(v))
        for k, v in rows.items():
            setattr(self, k, np.concatenate(v))
        self.step_w = np.concatenate(step_w)
        self.style = np.concatenate(step_style)
        self.vtarget = np.concatenate(step_val)
        self.row_w = np.concatenate(row_w)
        occ4 = np.minimum(self.occ, 4).astype(np.uint16) * 63
        self.tiles_q[..., 42] = occ4.astype(np.uint8)
        self.tiles_q[..., 43] = 0
        order = np.argsort(self.u_step, kind="stable")
        for k in rows:
            setattr(self, k, getattr(self, k)[order])
        self.row_w = self.row_w[order]
        self.n_steps = off
        self.row_start = np.searchsorted(self.u_step, np.arange(off), "left")
        self.row_end = np.searchsorted(self.u_step, np.arange(off), "right")

    def batch(self, steps, dev):
        steps = np.sort(steps)
        r = np.concatenate([np.arange(self.row_start[s], self.row_end[s]) for s in steps])
        local = np.searchsorted(steps, self.u_step[r])
        tm = np.unpackbits(self.tmask[steps], axis=-1)[..., :K_T].astype(bool)
        b = {
            "tiles": torch.from_numpy(self.tiles_q[steps]).to(dev).float().div_(255.0),
            "glob": torch.from_numpy(self.glob[steps].astype(np.float32)).to(dev),
            "mkt": torch.from_numpy(self.mkt[steps].astype(np.int64)).to(dev),
            "step_w": torch.from_numpy(self.step_w[steps]).to(dev),
            "style": torch.from_numpy(self.style[steps]).to(dev),
            "vtarget": torch.from_numpy(self.vtarget[steps]).to(dev),
            "tmask": torch.from_numpy(tm).to(dev),
            "smask": torch.from_numpy(self.smask[steps]).to(dev),
            "claimed": torch.from_numpy(self.claimed[steps].astype(np.float32)).to(dev),
            "claimed_shed": torch.from_numpy(self.claimed_shed[steps].astype(np.float32)).to(dev),
            "u_step": torch.from_numpy(local).to(dev),
            "u_feat": torch.from_numpy(self.u_feat[r].astype(np.float32)).to(dev),
            "u_gate": torch.from_numpy(self.u_gate[r]).to(dev),
            "u_y": torch.from_numpy(self.u_y[r].astype(np.int64)).to(dev),
            "u_n": torch.from_numpy(self.u_n[r].astype(np.int64)).to(dev),
            "u_self": torch.from_numpy(self.u_self[r].astype(np.int64)).to(dev),
            "row_w": torch.from_numpy(self.row_w[r]).to(dev),
        }
        return b


GATE_COLS = [TILE_OPS.index(c) for c in ("FEED", "FERTILIZE", "PLACE_GOOSE", "PLACE_COW", "PLACE_SHEEP")]
DROP_J = SHED_OPS.index("DROP")


def unit_mask(b):
    tm = b["tmask"][b["u_step"]].clone()  # [U,100,K_T]
    g = b["u_gate"]
    for i, col in enumerate(GATE_COLS):
        tm[:, :, col] &= g[:, i:i + 1]
    sm = b["smask"][b["u_step"]].clone()
    sm[:, DROP_J] &= g[:, 5]
    ones = torch.ones(len(g), 1, dtype=torch.bool, device=g.device)
    return torch.cat([tm.reshape(len(g), -1), sm, ones], -1)


def forward(model, b):
    tile_emb, glob_emb = model.encode(b["tiles"], b["glob"], b.get("style"))
    u_xy = torch.round(b["u_feat"][:, :2] * 9.0)
    pair = pair_feats(u_xy, b["claimed"][b["u_step"]], b["u_self"])
    self_shed = (b["u_self"] == -2)
    shed_pair = shed_pair_feats(u_xy, b["claimed_shed"][b["u_step"]], self_shed)
    ulog, pk = model.unit_logits(tile_emb, glob_emb, b["u_step"], b["u_feat"], b["u_gate"].float(), pair, shed_pair)
    mlog = model.market_logits(tile_emb, glob_emb)
    vpred = model.value(tile_emb, glob_emb)
    return ulog, pk, mlog, vpred


VALUE_SCALE = 50_000.0  # (my money - opponent money) / VALUE_SCALE, clipped to [-1, 1]


def losses(b, ulog, pk, mlog, mkt_w):
    mask = unit_mask(b)
    ulog = ulog.float().masked_fill(~mask, -1e9)
    ce = F.cross_entropy(ulog, b["u_y"], reduction="none")
    lu = (ce * b["row_w"]).sum() / b["row_w"].sum()
    is_pick = (b["u_n"] > 0)
    lp = F.cross_entropy(pk.float()[is_pick], b["u_n"][is_pick] - 1) if is_pick.any() else ulog.new_zeros(())
    lm = 0.0
    for h, (name, a, z) in enumerate(HEAD_SLICES):
        l = F.cross_entropy(mlog[:, a:z].float(), b["mkt"][:, h], weight=mkt_w[h], reduction="none")
        lm = lm + (l * b["step_w"]).sum() / b["step_w"].sum()
    return lu, lp, lm / len(HEAD_SLICES), ulog


@torch.no_grad()
def evaluate(model, store, steps, dev, bs=192):
    model.eval()
    n = correct = 0
    pass_base = 0
    by_op = {}
    pk_n = pk_ok = 0
    m_tot = np.zeros(len(HEAD_SLICES))
    m_ok = np.zeros(len(HEAD_SLICES))
    ev_tot = np.zeros(len(HEAD_SLICES))
    ev_hit = np.zeros(len(HEAD_SLICES))
    maj_ok = np.zeros(len(HEAD_SLICES))
    for i in range(0, len(steps), bs):
        b = store.batch(steps[i:i + bs], dev)
        with torch.autocast("cuda", dtype=torch.bfloat16):
            ulog, pk, mlog, _ = forward(model, b)
        mask = unit_mask(b)
        pred = ulog.float().masked_fill(~mask, -1e9).argmax(-1)
        y = b["u_y"]
        correct += (pred == y).sum().item()
        pass_base += (y == PASS_IDX).sum().item()
        n += len(y)
        for yy, pp in zip(y.tolist(), pred.tolist()):
            op = TILE_OPS[yy % K_T] if yy < SHED_BASE else (SHED_OPS[yy - SHED_BASE] if yy < PASS_IDX else "PASS")
            t = by_op.setdefault(op, [0, 0])
            t[0] += 1
            t[1] += int(yy == pp)
        is_pick = b["u_n"] > 0
        if is_pick.any():
            pk_n += is_pick.sum().item()
            pk_ok += (pk.float()[is_pick].argmax(-1) == b["u_n"][is_pick] - 1).sum().item()
        for h, (name, a, z) in enumerate(HEAD_SLICES):
            p = mlog[:, a:z].float().argmax(-1)
            t = b["mkt"][:, h]
            m_tot[h] += len(t)
            m_ok[h] += (p == t).sum().item()
            maj_ok[h] += (t == 0).sum().item()
            ev = t != 0
            ev_tot[h] += ev.sum().item()
            ev_hit[h] += ((p == t) & ev).sum().item()
    model.train()
    return {
        "unit_acc": correct / max(1, n), "pass_baseline": pass_base / max(1, n), "rows": n,
        "by_op": {k: (v[0], v[1] / v[0]) for k, v in sorted(by_op.items(), key=lambda kv: -kv[1][0])},
        "pickup_acc": pk_ok / max(1, pk_n),
        "market": {name: {"acc": m_ok[h] / m_tot[h], "always0": maj_ok[h] / m_tot[h],
                          "event_recall": ev_hit[h] / ev_tot[h] if ev_tot[h] else None, "events": int(ev_tot[h])}
                   for h, (name, _, _) in enumerate(HEAD_SLICES)},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data_dir")
    ap.add_argument("out_dir")
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--bs", type=int, default=128)
    ap.add_argument("--lr", type=float, default=6e-4)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--layers", type=int, default=3)
    ap.add_argument("--heads", type=int, default=4)
    ap.add_argument("--max-traj", type=int, default=0)
    ap.add_argument("--market-weight", type=float, default=1.0)
    ap.add_argument("--value-weight", type=float, default=0.0,
                    help="weight of the critic loss (target: final money margin); 0 disables it")
    ap.add_argument("--resume", action="store_true", help="continue from <out_dir>/last.pt if present")
    ap.add_argument("--init", default=None,
                    help="start from this checkpoint's weights (fresh optimiser): general model -> specialist")
    ap.add_argument("--styles-min", type=int, default=0,
                    help="min trajectories for a team to get its own style id; 0 disables styles")
    ap.add_argument("--style-drop", type=float, default=0.15)
    ap.add_argument("--index", default=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                                  "data", "d0910", "index.csv"))
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    dev = "cuda"
    meta = resolve_paths(pd.read_csv(os.path.join(a.data_dir, "meta.csv")), a.data_dir)
    if a.max_traj:
        meta = meta.sort_values("reward", ascending=False).head(a.max_traj)
    # Outcome-aware weights: better demonstrations count more (PTCG 191st), never zero.
    med = meta.reward.median()
    meta["w"] = np.clip(meta.reward / med, 0.6, 1.6) * np.where(meta.reward > meta.opp_reward, 1.0, 0.7)
    meta["vtarget"] = np.clip((meta.reward - meta.opp_reward) / VALUE_SCALE, -1.0, 1.0)
    style_map = build_style_map(meta, a.index, a.styles_min) if a.styles_min > 0 else {}
    meta["style"] = traj_styles(meta, style_map, a.index)
    if style_map:
        print("styles:", style_map, flush=True)
    val_m = meta[meta.episode.map(is_val)]
    tr_m = meta[~meta.episode.map(is_val)]
    if len(val_m) == 0 and len(meta) >= 2:  # small self-imitation rounds can miss the hash bucket
        val_m, tr_m = meta.iloc[::12], meta.drop(meta.index[::12])
        if len(val_m) == 0:
            val_m, tr_m = meta.iloc[:1], meta.iloc[1:]
    print(f"train traj {len(tr_m)}  val traj {len(val_m)}", flush=True)
    t0 = time.time()
    tr = Store(tr_m.path.tolist(), tr_m.w.tolist(), tr_m["style"].tolist(), tr_m["vtarget"].tolist())
    va = Store(val_m.path.tolist(), [1.0] * len(val_m), val_m["style"].tolist(), val_m["vtarget"].tolist())
    print(f"loaded {tr.n_steps} train steps / {len(tr.u_y)} unit rows, {va.n_steps} val steps "
          f"in {time.time() - t0:.0f}s", flush=True)

    # Market class weights ~ freq^-0.5 (fights the 'always do nothing' majority, forum #738079).
    mkt_w = []
    for h, (name, a0, z0) in enumerate(HEAD_SLICES):
        cnt = np.bincount(tr.mkt[:, h].astype(np.int64), minlength=z0 - a0).astype(np.float64) + 1.0
        w = (cnt / cnt.sum()) ** -0.5
        w = w / (w * cnt / cnt.sum()).sum()
        mkt_w.append(torch.tensor(np.clip(w, 0.05, 30.0), dtype=torch.float32, device=dev))

    n_style = (max(style_map.values()) + 1) if style_map else 0
    model = BCNet(d=a.d, layers=a.layers, heads=a.heads, n_style=n_style).to(dev)
    n_par = sum(p.numel() for p in model.parameters())
    print(f"params {n_par / 1e6:.2f}M", flush=True)
    if a.init:
        ck0 = torch.load(a.init, map_location=dev, weights_only=False)
        # Checkpoints trained before the critic existed have no v_mlp: keep it freshly initialised.
        missing, unexpected = model.load_state_dict(ck0["state"], strict=False)
        if missing or unexpected:
            print(f"  (new: {sorted(missing)}, dropped: {sorted(unexpected)})", flush=True)
        print(f"initialised from {a.init} (val unit_acc {ck0.get('val', {}).get('unit_acc', float('nan')):.4f})",
              flush=True)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.01)
    steps_per_epoch = tr.n_steps // a.bs
    total = steps_per_epoch * a.epochs
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=a.lr, total_steps=total, pct_start=0.05)
    val_steps = np.arange(va.n_steps)
    rng = np.random.default_rng(0)
    best = -1.0
    start_ep = 0
    last_path = os.path.join(a.out_dir, "last.pt")
    if a.resume and os.path.exists(last_path):
        ck = torch.load(last_path, map_location=dev, weights_only=False)
        model.load_state_dict(ck["state"])
        if "opt" in ck:
            opt.load_state_dict(ck["opt"])
            if ck["sched"].get("total_steps") == total:
                sched.load_state_dict(ck["sched"])
            else:
                print(f"schedule length changed ({ck['sched'].get('total_steps')} -> {total}); "
                      "restarting the LR schedule", flush=True)
        start_ep = ck["epoch"] + 1
        best = ck.get("best", -1.0)
        print(f"resumed from {last_path}: epoch {start_ep}, best {best:.4f}", flush=True)
    for ep in range(start_ep, a.epochs):
        perm = rng.permutation(tr.n_steps)
        t_ep = time.time()
        run = np.zeros(4)
        for bi in range(steps_per_epoch):
            b = tr.batch(perm[bi * a.bs:(bi + 1) * a.bs], dev)
            if style_map and a.style_drop > 0:
                drop = torch.rand(b["style"].shape, device=dev) < a.style_drop
                b["style"] = torch.where(drop, torch.zeros_like(b["style"]), b["style"])
            with torch.autocast("cuda", dtype=torch.bfloat16):
                ulog, pk, mlog, vpred = forward(model, b)
            lu, lp, lm, _ = losses(b, ulog, pk, mlog, mkt_w)
            lv = ((vpred.float() - b["vtarget"]) ** 2 * b["step_w"]).sum() / b["step_w"].sum()
            loss = lu + 0.3 * lp + a.market_weight * lm + a.value_weight * lv
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            try:
                sched.step()
            except ValueError:  # a resumed run can outlast its schedule
                pass
            run += np.array([lu.item(), lp.item(), lm.item(), lv.item()])
            if (bi + 1) % 500 == 0:
                print(f"ep {ep} {bi + 1}/{steps_per_epoch}  unit {run[0] / 500:.3f}  pick {run[1] / 500:.3f}  "
                      f"mkt {run[2] / 500:.3f}  value {run[3] / 500:.4f}  {time.time() - t_ep:.0f}s", flush=True)
                run[:] = 0
        ev = evaluate(model, va, val_steps, dev)
        print(f"== epoch {ep}  val unit_acc {ev['unit_acc']:.4f} (always-PASS {ev['pass_baseline']:.4f})  "
              f"pickup {ev['pickup_acc']:.3f}  [{time.time() - t_ep:.0f}s]", flush=True)
        if ev["unit_acc"] > best:
            best = ev["unit_acc"]
            torch.save({"state": model.state_dict(), "cfg": model.cfg, "epoch": ep, "val": ev,
                        "style_map": style_map, "index_csv": a.index, "best": best},
                       os.path.join(a.out_dir, "best.pt"))
            with open(os.path.join(a.out_dir, "val_best.json"), "w") as f:
                json.dump(ev, f, indent=1)
        torch.save({"state": model.state_dict(), "cfg": model.cfg, "epoch": ep, "val": ev,
                    "style_map": style_map, "index_csv": a.index, "best": best,
                    "opt": opt.state_dict(), "sched": sched.state_dict()}, last_path)
    print("best val unit_acc", best)


if __name__ == "__main__":
    main()
