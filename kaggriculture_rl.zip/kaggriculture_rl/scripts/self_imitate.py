"""Filtered self-imitation (expert iteration): play, keep the good games, clone them.

PPO moved the policy (KL 0.06 -> 0.23 over 120 iterations) without improving results, which
is what a terminal-only reward spread over ~7,000 decisions does at a few thousand games.
This takes the same rollouts and uses them differently: play with sampling, keep only the
games whose outcome was good, and train the ordinary BC objective on those decisions. The
learning signal is a *selection* rather than a gradient of the reward, so it degrades
gracefully when games are scarce.

Trajectories are written to disk as each batch finishes and dropped from RAM: holding a
whole run in memory cost ~10 GB by game 192 and pushed the machine into swap. Only
(margin, path) stays resident, so memory is flat in the number of games and several of
these can run side by side -- the loop is CPU-bound on one core with the GPU at ~25%, so
shards are the only way to use the rest of the machine.

Stage 1 (this script) writes a BC dataset in the exact format scripts/build_dataset.py
produces, so stage 2 is just the usual training run:

  python scripts/self_imitate.py --init runs/v_lr03/best.pt --out data/si_round1 --games 800
  python scripts/train.py data/si_round1 runs/si1 --d 256 --layers 6 --bs 256 \
      --epochs 3 --lr 2e-5 --init runs/v_lr03/best.pt

Sharded (see scripts/si_merge.py for the merge, which selects across all shards at once):

  python scripts/self_imitate.py ... --out data/si_round1/sh0 --seed-start 2000000 --no-select
  python scripts/si_merge.py data/si_round1 --shards data/si_round1/sh0 data/si_round1/sh1
"""
import argparse
import csv
import gc
import json
import os
import sys
import time

import numpy as np
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from kag.rl_batch import BatchPolicy, play_batch  # noqa: E402
from rl_ppo import LEAGUE, tapes  # noqa: E402

FIELDS = ["episode", "seat", "path", "reward", "opp_reward", "steps", "rows", "opp"]


def rec_to_arrays(rec):
    """Recorded rollout steps -> the arrays scripts/train.py's Store expects.

    tiles column 42 holds round(min(occ,4)*63)/255 (set when the context was built), so the
    occupancy counts come back out of it rather than being recorded twice."""
    tiles = np.stack([r["tiles"] for r in rec])
    occ = np.rint(tiles[:, :, 42].astype(np.float32) / 63.0).astype(np.uint8)
    return {
        "tiles_q": tiles,
        "occ": occ,
        "claimed": np.stack([r["claimed"] for r in rec]),
        "claimed_shed": np.array([r["claimed_shed"] for r in rec], np.uint8),
        "tmask": np.stack([r["tmask"] for r in rec]),
        "smask": np.stack([r["smask"] for r in rec]),
        "glob": np.stack([r["glob"] for r in rec]),
        "mkt": np.stack([r["m_cls"] for r in rec]).astype(np.int8),
        "u_step": np.concatenate([np.full(len(r["u_y"]), i, np.int16) for i, r in enumerate(rec)]),
        "u_feat": np.concatenate([r["u_feat"] for r in rec]),
        "u_gate": np.concatenate([r["u_gate"] for r in rec]),
        "u_y": np.concatenate([r["u_y"] for r in rec]).astype(np.int16),
        "u_n": np.concatenate([r["u_pick"] for r in rec]).astype(np.int8),
        "u_self": np.concatenate([r["u_self"] for r in rec]).astype(np.int16),
    }


def margin(row):
    return row["reward"] - row["opp_reward"]


def select(rows, keep, min_margin=0.0):
    """rows -> (kept, dropped), best margin first."""
    ranked = sorted(rows, key=margin, reverse=True)
    n_keep = max(1, int(round(len(ranked) * keep)))
    kept = [r for r in ranked[:n_keep] if margin(r) >= min_margin]
    return kept, ranked[len(kept):]


def describe(kept, dropped):
    mean = lambda rs, k: (float(np.mean([r[k] for r in rs])) if rs else float("nan"))  # noqa: E731
    s = (f"keeping {len(kept)} of {len(kept) + len(dropped)} "
         f"(margin >= {margin(kept[-1]):.0f}, "
         f"money {mean(kept, 'reward'):.0f} vs {mean(kept, 'opp_reward'):.0f})")
    if dropped:
        s += f"; dropped set money {mean(dropped, 'reward'):.0f}"
    return s


def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)


def read_csv(path):
    """Existing all.csv -> rows, so a killed run resumes instead of replaying everything."""
    if not os.path.exists(path):
        return []
    cast = {"reward": float, "opp_reward": float, "seat": int, "steps": int, "rows": int}
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k, fn in cast.items():
            r[k] = fn(r[k])
    return rows


def commit_gb():
    """Windows commit charge for this process; RSS hides what has been paged out."""
    try:
        import psutil
        return psutil.Process().memory_info().vms / 2 ** 30
    except Exception:
        return float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init", required=True, help="policy that plays the games")
    ap.add_argument("--out", required=True, help="dataset directory to write")
    ap.add_argument("--games", type=int, default=800)
    ap.add_argument("--batch", type=int, default=48, help="games in flight per batch")
    ap.add_argument("--keep", type=float, default=0.25, help="fraction of games to keep, best first")
    ap.add_argument("--min-margin", type=float, default=0.0, help="also require money - opp_money >= this")
    ap.add_argument("--no-select", action="store_true",
                    help="shard mode: keep every game and let scripts/si_merge.py select globally")
    ap.add_argument("--tau-u", type=float, default=0.5)
    ap.add_argument("--tau-m", type=float, default=1.0)
    ap.add_argument("--self-play", type=float, default=0.5)
    ap.add_argument("--league", default=LEAGUE)
    ap.add_argument("--seed-start", type=int, default=2_000_000)
    ap.add_argument("--kwargs", default='{"calibrated": false, "feed_topup": false}')
    ap.add_argument("--seed", type=int, default=3)
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    bp = BatchPolicy(a.init)
    league = tapes(a.league)
    kw = dict(json.loads(a.kwargs), sample=True, tau_u=a.tau_u, tau_m=a.tau_m, record=True)
    kw_opp = {k: v for k, v in kw.items() if k != "record"}
    rng = np.random.default_rng(a.seed)

    all_csv = os.path.join(a.out, "all.csv")
    rows = read_csv(all_csv)
    done = {(r["episode"], r["seat"]) for r in rows}
    if rows:
        print(f"resuming: {len(rows)} games already in {all_csv}", flush=True)

    # The whole job list is drawn up front so that resuming skips games rather than
    # re-drawing opponents for a shifted sequence.
    plan = []
    for g in range(a.games):
        if rng.random() < a.self_play:
            spec, label = "self", "self"
        else:
            spec, label = league[int(rng.integers(len(league)))]
        plan.append({"seed": int(a.seed_start + g), "seat": int(rng.integers(2)),
                     "opp": spec, "label": label, "sample_seed": int(rng.integers(2 ** 31))})
    plan = [j for j in plan if (f"si{j['seed']}", j["seat"]) not in done]

    t0 = time.time()
    for start in range(0, len(plan), a.batch):
        jobs = plan[start:start + a.batch]
        n = len(jobs)
        res = play_batch(bp, jobs, kw, opp_kwargs=kw_opp)
        for r in res:
            seat = r["job"]["seat"]
            if r["status"][seat] != "DONE" or not r["rec"]:
                continue
            arrays = rec_to_arrays(r["rec"])
            seed = r["job"]["seed"]
            path = os.path.join(a.out, f"si{seed}_s{seat}.npz")
            np.savez_compressed(path, **arrays)
            rows.append({"episode": f"si{seed}", "seat": seat, "path": path,
                         "reward": r["money"][seat], "opp_reward": r["money"][1 - seat],
                         "steps": len(r["rec"]), "rows": int(len(arrays["u_y"])),
                         "opp": r["job"]["label"]})  # selection must be able to control for this
            r["rec"] = None  # on disk now; carrying it is what cost 10 GB
        del res
        gc.collect()
        write_csv(all_csv, rows)  # after every batch, so killing this process loses nothing
        print(f"{start + n}/{len(plan)} games, {time.time() - t0:.0f}s, "
              f"money mean {np.mean([r['reward'] for r in rows]):.0f}, "
              f"commit {commit_gb():.2f} GB", flush=True)

    write_csv(all_csv, rows)
    if a.no_select:
        print(f"wrote {len(rows)} games to {a.out} (selection deferred to si_merge.py)", flush=True)
        return

    # On a resume, all.csv still lists games whose npz a previous selection deleted.
    rows = [r for r in rows if os.path.exists(r["path"])]
    kept, dropped = select(rows, a.keep, a.min_margin)
    print("\n" + describe(kept, dropped), flush=True)
    for r in dropped:
        try:
            os.remove(r["path"])
        except OSError:
            pass
    write_csv(os.path.join(a.out, "meta.csv"), kept)
    print(f"wrote {len(kept)} trajectories to {a.out}", flush=True)


if __name__ == "__main__":
    main()
