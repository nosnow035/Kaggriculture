"""Evaluate one candidate against a fixed opponent suite with a single worker pool.

Usage:
  python scripts/eval_suite.py --cand SPEC [--tape-teams "SpaTaro,feel the agi"] [--opp SPEC ...]
                               [--seeds 12] [--save out.json]
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from kag.agents.registry import spec_name  # noqa: E402
from kag.evaluate import evaluate  # noqa: E402

DEFAULT_TEAMS = "Himanshu Kumar,kanno,Unknown Mother-Goose,ymg_aq,Otter Vibe,binghua"


def parse_spec(s):
    s = s.strip()
    return json.loads(s) if s.startswith("{") else s


def team_tapes(teams):
    import pandas as pd
    df = pd.read_csv(os.path.join(ROOT, "data", "d0910", "index.csv"))
    out = []
    for t in teams:
        sub = df[df.name == t].sort_values("reward", ascending=False)
        if not sub.empty:
            out.append(({"kind": "tape", "path": sub.iloc[0].tape}, f"tape[{t}]"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cand", required=True)
    ap.add_argument("--tape-teams", default=DEFAULT_TEAMS)
    ap.add_argument("--opp", action="append", default=[])
    ap.add_argument("--seeds", type=int, default=12)
    ap.add_argument("--seed-start", type=int, default=300_000)
    ap.add_argument("--procs", type=int, default=None)
    ap.add_argument("--save", default=None)
    a = ap.parse_args()
    cand = parse_spec(a.cand)
    opps = team_tapes([t for t in a.tape_teams.split(",") if t]) if a.tape_teams else []
    opps += [(parse_spec(o), spec_name(parse_spec(o))) for o in a.opp]
    seeds = list(range(a.seed_start, a.seed_start + a.seeds))
    report = {"cand": spec_name(cand), "seeds": seeds, "results": []}
    t0 = time.time()
    tot_w = tot_n = 0.0
    with mp.get_context("spawn").Pool(a.procs or max(1, (os.cpu_count() or 2) - 1)) as pool:
        for spec, label in opps:
            s, _ = evaluate(cand, spec, seeds, pool=pool)
            lo, hi = s["ci95"]
            tot_w += s["score"] * s["n"]
            tot_n += s["n"]
            print(f"{spec_name(cand)} vs {label:<28} score {s['score']:.3f} [{lo:.2f},{hi:.2f}]  "
                  f"W/L/T {s['wins']}/{s['losses']}/{s['ties']}  err {s['errors']}  "
                  f"money {s['cand_money']:.0f} vs {s['opp_money']:.0f}", flush=True)
            report["results"].append({"opp": label, **s})
    print(f"overall score {tot_w / max(1, tot_n):.3f} over {int(tot_n)} games  ({time.time() - t0:.0f}s)")
    if a.save:
        with open(a.save, "w") as f:
            json.dump(report, f, indent=1)


if __name__ == "__main__":
    main()
