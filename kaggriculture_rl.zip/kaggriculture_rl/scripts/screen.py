"""Screen several candidates against the same opponents on the same seeds (one pool).

Usage:
  python scripts/screen.py --cand SPEC --cand SPEC ... [--tape-teams "Himanshu Kumar,kanno"] [--seeds 8]
  python scripts/screen.py --cand SPEC --tapes none --opp-file sub1=opponents/user_sub1_2619/main.py --alternate
Small screens only rank clearly different candidates; confirm winners on fresh seeds
(PTCG 589th: 32-64 game screens mislead on close calls).
"""
import argparse
import json
import multiprocessing as mp
import os
import sys
import time

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from eval_suite import parse_spec, team_tapes  # noqa: E402
from kag.agents.registry import spec_name  # noqa: E402
from kag.evaluate import evaluate  # noqa: E402


def label(spec):
    if isinstance(spec, dict) and spec.get("kind") == "bc":
        kw = spec.get("kwargs") or {}
        extra = ",".join(f"{k}={v}" for k, v in kw.items())
        return spec_name(spec) + (f"[{extra}]" if extra else "")
    return spec_name(spec)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cand", action="append", required=True)
    ap.add_argument("--tape-teams", default="Himanshu Kumar,kanno,Unknown Mother-Goose")
    ap.add_argument("--tapes", default=None, help="'d0910:Team,d0913:Team' (overrides --tape-teams); 'none' = no tapes")
    ap.add_argument("--opp-file", action="append", default=[], help="label=path/to/main.py (submission-style agent)")
    ap.add_argument("--alternate", action="store_true", help="one game per seed, seats alternating")
    ap.add_argument("--seeds", type=int, default=8)
    ap.add_argument("--seed-start", type=int, default=400_000)
    ap.add_argument("--save", default=None)
    a = ap.parse_args()
    cands = [parse_spec(c) for c in a.cand]
    if a.tapes == "none":
        opps = []
    elif a.tapes:
        from rl_train import tapes
        opps = tapes(a.tapes)
    else:
        opps = team_tapes([t for t in a.tape_teams.split(",") if t])
    for item in a.opp_file:
        lab, path = item.split("=", 1)
        opps.append(({"kind": "file", "path": os.path.abspath(path)}, f"file[{lab}]"))
    seeds = list(range(a.seed_start, a.seed_start + a.seeds))
    rows = []
    t0 = time.time()
    with mp.get_context("spawn").Pool(max(1, (os.cpu_count() or 2) - 1)) as pool:
        for c in cands:
            w = n = 0.0
            cm = om = 0.0
            per = []
            for spec, olab in opps:
                s, _ = evaluate(c, spec, seeds, pool=pool, alternate=a.alternate)
                w += s["score"] * s["n"]
                n += s["n"]
                cm += s["cand_money"] * s["n"]
                om += s["opp_money"] * s["n"]
                per.append(f"{olab.split('[')[-1].rstrip(']')[:10]}:{s['score']:.2f}/{s['cand_money'] / 1000:.0f}k"
                           f"-{s['opp_money'] / 1000:.0f}k")
            rows.append((w / n, cm / n, om / n, label(c), per))
            print(f"{label(c):<60} score {w / n:.3f}  money {cm / n:7.0f} vs {om / n:7.0f}  | " + "  ".join(per),
                  flush=True)
    seats = "1 seat" if a.alternate else "2 seats"
    print(f"\n{time.time() - t0:.0f}s, {len(seeds)} seeds x {seats} x {len(opps)} opponents per candidate")
    for sc, cm, om, lab, _ in sorted(rows, reverse=True):
        print(f"  {sc:.3f}  {cm:7.0f} vs {om:7.0f}  {lab}")
    if a.save:
        with open(a.save, "w") as f:
            json.dump([{"cand": r[3], "score": r[0], "money": r[1], "opp_money": r[2]} for r in rows], f, indent=1)


if __name__ == "__main__":
    main()
