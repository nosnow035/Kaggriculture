"""Merge sharded self-imitation runs and select the good games across all of them at once.

Each shard writes every game it played plus an all.csv (scripts/self_imitate.py --no-select).
Selecting per shard would keep a fixed quota of each shard's games regardless of how they
compare to the others; selecting here, over the pooled set, keeps the genuinely best games.

  python scripts/si_merge.py data/si_round1 --shards data/si_round1/sh0 data/si_round1/sh1
"""
import argparse
import csv
import glob
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from self_imitate import FIELDS, describe, select, write_csv  # noqa: E402

NUMERIC = {"reward": float, "opp_reward": float, "seat": int, "steps": int, "rows": int}


def read_all(shard):
    path = os.path.join(shard, "all.csv")
    if not os.path.exists(path):
        return []
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for k, cast in NUMERIC.items():
            r[k] = cast(r[k])
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out", help="directory to write the merged meta.csv into")
    ap.add_argument("--shards", nargs="+", required=True, help="shard directories (globs allowed)")
    ap.add_argument("--keep", type=float, default=0.25)
    ap.add_argument("--min-margin", type=float, default=0.0)
    ap.add_argument("--stratify", action="store_true",
                    help="select the top --keep within each opponent, not across the pool; a raw "
                         "margin ranks opponents more than it ranks our own play")
    ap.add_argument("--only", default=None,
                    help="restrict to games against this opponent label, e.g. 'self'")
    ap.add_argument("--random", type=int, default=None, metavar="SEED",
                    help="control: take a random --keep share instead of the best, to separate "
                         "'selection helped' from 'cloning our own sampled actions hurt'")
    ap.add_argument("--delete-dropped", action="store_true",
                    help="remove the npz files that were not selected (they are ~1.5 MB each)")
    a = ap.parse_args()

    shards = []
    for s in a.shards:
        shards.extend(sorted(glob.glob(s)) or [s])
    rows = []
    for s in shards:
        got = read_all(s)
        print(f"{s}: {len(got)} games")
        rows.extend(got)
    if not rows:
        raise SystemExit("no games found; did the shards finish and write all.csv?")

    if a.only:
        rows = [r for r in rows if r.get("opp") == a.only]
        print(f"restricted to opp == {a.only!r}: {len(rows)} games")
        if not rows:
            raise SystemExit("nothing left; run scripts/si_label.py first if all.csv has no opp column")

    if a.random is not None:
        import random as _random
        rng = _random.Random(a.random)
        shuffled = rows[:]
        rng.shuffle(shuffled)
        n_keep = max(1, int(round(len(rows) * a.keep)))
        kept, dropped = shuffled[:n_keep], shuffled[n_keep:]
        kept.sort(key=lambda r: r["reward"] - r["opp_reward"], reverse=True)
    elif a.stratify:
        groups = {}
        for r in rows:
            groups.setdefault(r.get("opp", "?"), []).append(r)
        kept, dropped = [], []
        for name in sorted(groups):
            k, d = select(groups[name], a.keep, a.min_margin)
            print(f"  {name:28s} {len(groups[name]):4d} games -> keep {len(k):3d}")
            kept.extend(k)
            dropped.extend(d)
        kept.sort(key=lambda r: r["reward"] - r["opp_reward"], reverse=True)
    else:
        kept, dropped = select(rows, a.keep, a.min_margin)
    print(f"\npooled {len(rows)} games from {len(shards)} shards; " + describe(kept, dropped))

    os.makedirs(a.out, exist_ok=True)
    write_csv(os.path.join(a.out, "meta.csv"), kept)
    if a.delete_dropped:
        for r in dropped:
            try:
                os.remove(r["path"])
            except OSError:
                pass
    print(f"wrote {len(kept)} trajectories to {os.path.join(a.out, 'meta.csv')}")


if __name__ == "__main__":
    main()
