"""Extract compact per-seat tapes and an episode index from a daily episodes zip.

Usage: python scripts/extract_tapes.py <episodes.zip> <out_dir>
Writes <out_dir>/tapes/<episode>_s<seat>.json and <out_dir>/index.csv.
"""
import csv
import json
import multiprocessing as mp
import os
import sys
import zipfile
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kag.replay import replay_meta, seat_actions  # noqa: E402


def action_stats(actions):
    c = Counter()
    hands_per_day = {}
    for s, a in enumerate(actions):
        if not isinstance(a, dict):
            c["null_action"] += 1
            continue
        day = s // 24
        hands_per_day[day] = max(hands_per_day.get(day, 0), len(a.get("hands") or []))
        for o in a.get("market") or []:
            if not o:
                continue
            op = o[0]
            if op in ("HIRE", "BUY_LAND"):
                c[op] += 1
            elif len(o) >= 3:
                c[f"{op}:{o[1]}"] += int(o[2]) if str(o[2]).lstrip("-").isdigit() else 0
        for u in [a.get("farmer")] + list(a.get("hands") or []):
            if isinstance(u, list) and u:
                c["unit:" + u[0]] += 1
    c["max_hands"] = max(hands_per_day.values()) if hands_per_day else 0
    return c


def one(args):
    zpath, member, tape_dir = args
    try:
        with zipfile.ZipFile(zpath) as z:
            with z.open(member) as f:
                rep = json.load(f)
    except Exception as e:  # corrupt member: skip, but report
        return [{"member": member, "error": repr(e)}]
    meta = replay_meta(rep)
    ep = meta["episode_id"] or os.path.splitext(os.path.basename(member))[0]
    rows = []
    for seat in (0, 1):
        acts = seat_actions(rep, seat)
        path = os.path.join(tape_dir, f"{ep}_s{seat}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"episode": ep, "seat": seat, "seed": meta["seed"],
                       "reward": meta["rewards"][seat], "opp_reward": meta["rewards"][1 - seat],
                       "name": meta["names"][seat] if len(meta["names"]) > seat else None,
                       "actions": acts}, f)
        st = action_stats(acts)
        rows.append({
            "member": member, "episode": ep, "seat": seat, "seed": meta["seed"],
            "name": meta["names"][seat] if len(meta["names"]) > seat else None,
            "score": meta["scores"][seat] if len(meta["scores"]) > seat else None,
            "reward": meta["rewards"][seat], "opp_reward": meta["rewards"][1 - seat],
            "status": meta["statuses"][seat], "tape": path,
            "stats": json.dumps(dict(st)),
        })
    return rows


def main():
    zpath, out_dir = sys.argv[1], sys.argv[2]
    tape_dir = os.path.join(out_dir, "tapes")
    os.makedirs(tape_dir, exist_ok=True)
    with zipfile.ZipFile(zpath) as z:
        members = [n for n in z.namelist() if n.endswith(".json")]
    print("members:", len(members), flush=True)
    jobs = [(zpath, m, tape_dir) for m in members]
    rows = []
    with mp.get_context("spawn").Pool(max(1, (os.cpu_count() or 2) - 2)) as pool:
        for i, r in enumerate(pool.imap_unordered(one, jobs, chunksize=2)):
            rows.extend(r)
            if (i + 1) % 50 == 0:
                print(f"{i + 1}/{len(jobs)}", flush=True)
    keys = sorted({k for r in rows for k in r})
    with open(os.path.join(out_dir, "index.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print("rows:", len(rows), "errors:", sum(1 for r in rows if "error" in r))


if __name__ == "__main__":
    main()
