"""Backfill the `opp` column into an all.csv written before self_imitate.py recorded it.

Selection has to control for the opponent: ranking 700 games by money margin kept 174 of
175 from tape opponents and 1 of 341 self-play games, because a margin measures how badly
the opponent collapsed at least as much as how well we played. The opponent per seed is
recoverable because the job plan is a deterministic draw from numpy's PCG64 given
(--seed, --self-play, league), made in the same order in both the batched and the
plan-up-front versions of the script.

  python scripts/si_label.py data/si_round1/sh0 --seed-start 2000000 --games 400 --seed 3
"""
import argparse
import csv
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from rl_ppo import LEAGUE, tapes  # noqa: E402
from self_imitate import FIELDS, read_csv, write_csv  # noqa: E402


def replay_plan(seed_start, games, seed, self_play, league):
    """seed -> opponent label, by making the same draws in the same order."""
    rng = np.random.default_rng(seed)
    out = {}
    for g in range(games):
        label = "self" if rng.random() < self_play else league[int(rng.integers(len(league)))][1]
        rng.integers(2)          # seat
        rng.integers(2 ** 31)    # sample_seed
        out[seed_start + g] = label
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("shard", help="directory holding all.csv")
    ap.add_argument("--seed-start", type=int, required=True)
    ap.add_argument("--games", type=int, required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--self-play", type=float, default=0.5)
    ap.add_argument("--league", default=LEAGUE)
    a = ap.parse_args()

    labels = replay_plan(a.seed_start, a.games, a.seed, a.self_play, tapes(a.league))
    path = os.path.join(a.shard, "all.csv")
    rows = read_csv(path)
    if not rows:
        raise SystemExit(f"no rows in {path}")
    missing = 0
    for r in rows:
        label = labels.get(int(r["episode"][2:]))
        if label is None:
            missing += 1
            label = "?"
        r["opp"] = label
    write_csv(path, rows)

    counts = {}
    for r in rows:
        counts[r["opp"]] = counts.get(r["opp"], 0) + 1
    share = counts.get("self", 0) / len(rows)
    print(f"{path}: labelled {len(rows)} games, {missing} unmatched")
    for k in sorted(counts):
        print(f"  {k:28s} {counts[k]:4d}")
    print(f"self-play share {share:.1%} (asked for {a.self_play:.0%}) "
          f"-- a big gap here would mean the replayed draw does not match the run")


if __name__ == "__main__":
    main()
