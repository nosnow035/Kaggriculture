"""RL fine-tuning of the BC policy: group-relative PPO anchored to the BC policy by a KL penalty.

Each iteration plays G groups of K games. A group fixes (seed, opponent, seat), so its K games
differ only in what the stochastic policy sampled; a game's advantage is its outcome relative
to its group (GRPO-style baseline, no value network) and applies to every decision the policy
sampled in that game. The learner first re-evaluates log-probs with the pre-update weights,
then takes PPO clipped steps plus an exact KL(pi || pi_BC) penalty over each decision's legal
distribution, so the policy improves on the game outcome without drifting far from SpaTaro.

Usage:
  python scripts/rl_train.py --init runs/bc_spa/best.pt --out runs/rl_spa [--iters 60 --groups 4 --k 6]
"""
import argparse
import json
import multiprocessing as mp
import os
import shutil
import sys
import time

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_v, "1")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import numpy as np  # noqa: E402

from kag.features import K_T, MARKET_HEADS, PASS_IDX  # noqa: E402
from kag.rl_rollout import rollout_job  # noqa: E402

# torch is imported inside main() only: spawn workers re-import this module and must stay torch-free.

STEP_KEYS = ("tiles", "glob", "tmask", "smask", "claimed", "claimed_shed", "m_cls")
ROW_KEYS = ("u_feat", "u_gate", "u_self", "u_y", "u_blocked", "u_train", "u_pick")
TRAIN_OPPS = ("d0910:Himanshu Kumar,d0910:kanno,d0910:Unknown Mother-Goose,d0910:ymg_aq,d0910:Otter Vibe,"
              "d0913:Majkel1337,d0913:ymg_aq,d0913:feel the agi")
EVAL_OPPS = "d0910:Himanshu Kumar,d0910:kanno,d0910:Unknown Mother-Goose,d0913:Majkel1337"


def tapes(spec):
    """'d0910:Team,d0913:Team' -> [(tape spec, label)], each team's best-money tape of that day."""
    import pandas as pd
    out = []
    for item in [s for s in spec.split(",") if s]:
        day, team = item.split(":", 1)
        df = pd.read_csv(os.path.join(ROOT, "data", day, "index.csv"))
        sub = df[(df.name == team) & (df.status == "DONE")].sort_values("reward", ascending=False)
        if sub.empty:
            print("no tape for", item, flush=True)
            continue
        out.append(({"kind": "tape", "path": sub.iloc[0].tape}, f"{team}@{day}"))
    return out


def game_score(money, seat):
    me, op = money[seat], money[1 - seat]
    return (me - op) / 10000.0 + (1.0 if me > op else 0.5 if me == op else 0.0)


def group_advantages(results):
    groups = {}
    for i, r in enumerate(results):
        seat = r["job"]["seat"]
        if r["status"][seat] == "DONE" and r["data"] is not None:
            groups.setdefault(r["job"]["group"], []).append(i)
    adv = {}
    for idx in groups.values():
        if len(idx) < 2:
            continue
        s = np.array([game_score(results[i]["money"], results[i]["job"]["seat"]) for i in idx])
        a = np.clip((s - s.mean()) / (s.std() + 0.25), -3.0, 3.0)
        for i, v in zip(idx, a):
            adv[i] = float(v)
    return adv


class RLData:
    def __init__(self, games):
        steps = {k: [] for k in STEP_KEYS}
        rows = {k: [] for k in ROW_KEYS}
        u_step, u_adv, m_adv, u_roll, m_roll = [], [], [], [], []
        off = 0
        for d, adv in games:
            S = len(d["glob"])
            for k in STEP_KEYS:
                steps[k].append(d[k])
            for k in ROW_KEYS:
                rows[k].append(d[k])
            u_step.append(d["u_step"].astype(np.int64) + off)
            u_adv.append(np.full(len(d["u_y"]), adv, np.float32))
            m_adv.append(np.full(S, adv, np.float32))
            u_roll.append(d["u_logp"])
            m_roll.append(d["m_logp"])
            off += S
        for k, v in steps.items():
            setattr(self, k, np.concatenate(v))
        for k, v in rows.items():
            setattr(self, k, np.concatenate(v))
        self.u_step = np.concatenate(u_step)
        self.u_adv = np.concatenate(u_adv)
        self.m_adv = np.concatenate(m_adv)
        self.u_roll = np.concatenate(u_roll)
        self.m_roll = np.concatenate(m_roll)
        self.n = off
        self.row_start = np.searchsorted(self.u_step, np.arange(off), "left")
        self.row_end = np.searchsorted(self.u_step, np.arange(off), "right")
        self.old_u = np.zeros(len(self.u_y), np.float32)
        self.old_p = np.zeros(len(self.u_y), np.float32)
        self.old_m = np.zeros((off, len(MARKET_HEADS)), np.float32)

    def batch(self, steps, dev, torch):
        steps = np.sort(steps)
        r = np.concatenate([np.arange(self.row_start[s], self.row_end[s]) for s in steps])
        local = np.searchsorted(steps, self.u_step[r])
        tm = np.unpackbits(self.tmask[steps], axis=-1)[..., :K_T].astype(bool)

        def t(a):
            return torch.from_numpy(np.ascontiguousarray(a)).to(dev)

        b = {
            "tiles": t(self.tiles[steps]).float().div_(255.0), "glob": t(self.glob[steps].astype(np.float32)),
            "tmask": t(tm), "smask": t(self.smask[steps]), "claimed": t(self.claimed[steps].astype(np.float32)),
            "claimed_shed": t(self.claimed_shed[steps].astype(np.float32)),
            "m_cls": t(self.m_cls[steps].astype(np.int64)), "m_adv": t(self.m_adv[steps]), "old_m": t(self.old_m[steps]),
            "u_step": t(local), "u_feat": t(self.u_feat[r].astype(np.float32)), "u_gate": t(self.u_gate[r]),
            "u_self": t(self.u_self[r].astype(np.int64)), "u_y": t(self.u_y[r].astype(np.int64)),
            "u_blocked": t(self.u_blocked[r].astype(np.int64)), "u_train": t(self.u_train[r]),
            "u_pick": t(self.u_pick[r].astype(np.int64)), "u_adv": t(self.u_adv[r]),
            "old_u": t(self.old_u[r]), "old_p": t(self.old_p[r]),
        }
        return b, steps, r


def export_npz(model, cfg, decode, path):
    arrays = {k: v.detach().float().cpu().numpy() for k, v in model.state_dict().items()}
    arrays["__cfg__"] = np.array(json.dumps(cfg))
    arrays["__decode__"] = np.array(json.dumps(decode))
    arrays["__styles__"] = np.array(json.dumps({}))
    tmp = path[:-4] + ".tmp.npz"
    np.savez(tmp, **arrays)
    os.replace(tmp, path)


def run_eval(pool, weights, kw, opps, seeds, modes):
    from kag.evaluate import evaluate
    out = {}
    for mode in modes:
        kwm = dict(kw, sample=True, seed=20260914) if mode == "sample" else \
            {k: v for k, v in kw.items() if k not in ("tau_u", "tau_m")}
        spec = {"kind": "bc", "weights": weights, "kwargs": kwm}
        w = n = cm = om = 0.0
        per = {}
        for ospec, label in opps:
            s, _ = evaluate(spec, ospec, seeds, pool=pool)
            w += s["score"] * s["n"]
            n += s["n"]
            cm += s["cand_money"] * s["n"]
            om += s["opp_money"] * s["n"]
            per[label] = [round(s["score"], 3), round(s["cand_money"]), round(s["opp_money"])]
        out[mode] = {"score": w / n, "money": cm / n, "opp_money": om / n, "games": int(n), "per": per}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--iters", type=int, default=60)
    ap.add_argument("--groups", type=int, default=4)
    ap.add_argument("--k", type=int, default=6)
    ap.add_argument("--procs", type=int, default=8)
    ap.add_argument("--tau-u", type=float, default=1.0)
    ap.add_argument("--tau-m", type=float, default=1.0)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--beta", type=float, default=0.02)
    ap.add_argument("--clip", type=float, default=0.2)
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--mb", type=int, default=64)
    ap.add_argument("--mkt-w", type=float, default=1.0)
    ap.add_argument("--kwargs", default='{"feed_topup": false}')
    ap.add_argument("--opening", default=None)
    ap.add_argument("--opening-steps", type=int, default=0)
    ap.add_argument("--train-opps", default=TRAIN_OPPS)
    ap.add_argument("--eval-opps", default=EVAL_OPPS)
    ap.add_argument("--eval-every", type=int, default=5)
    ap.add_argument("--eval-seeds", type=int, default=6)
    ap.add_argument("--eval-modes", default="sample")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()

    import torch
    from kag.model import BCNet
    from train import HEAD_SLICES, forward, unit_mask

    os.makedirs(a.out, exist_ok=True)
    dev = "cuda"
    ck = torch.load(a.init, map_location="cpu", weights_only=False)
    decode = ck.get("decode", {})
    pass_off = float(decode.get("pass_offset", 0.0))
    model = BCNet(**ck["cfg"]).to(dev)
    model.load_state_dict(ck["state"])
    ref = BCNet(**ck["cfg"]).to(dev)
    ref.load_state_dict(ck["state"])
    ref.eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.0)
    start = 0
    last_path = os.path.join(a.out, "last.pt")
    if os.path.exists(last_path):
        st = torch.load(last_path, map_location="cpu", weights_only=False)
        model.load_state_dict(st["state"])
        opt.load_state_dict(st["opt"])
        start = st["it"] + 1
        print("resumed at iteration", start, flush=True)

    kw = json.loads(a.kwargs)
    kw.update({"tau_u": a.tau_u, "tau_m": a.tau_m})
    if a.opening and a.opening_steps > 0:
        kw.update({"opening": os.path.abspath(a.opening), "opening_steps": a.opening_steps})
    train_opps = tapes(a.train_opps)
    eval_opps = tapes(a.eval_opps)
    eval_seeds = list(range(400_000, 400_000 + a.eval_seeds))
    modes = [m for m in a.eval_modes.split(",") if m]
    with open(os.path.join(a.out, "args.json"), "w") as f:
        json.dump({**vars(a), "kw": kw, "train_opps": [l for _, l in train_opps],
                   "eval_opps": [l for _, l in eval_opps]}, f, indent=1)
    cur = os.path.join(a.out, "cur.npz")
    log_path = os.path.join(a.out, "log.jsonl")

    def unit_logprobs(ulog, b):
        z = ulog.float().clone()
        z[:, PASS_IDX] += pass_off
        mask = unit_mask(b)
        blk = b["u_blocked"]
        valid = blk >= 0
        if valid.any():
            ri = torch.arange(len(blk), device=blk.device)[:, None].expand_as(blk)[valid]
            mask[ri, blk[valid]] = False
        return torch.log_softmax(z.masked_fill(~mask, -1e9) / a.tau_u, -1)

    def market_logprobs(mlog, cls):
        chosen, dists = [], []
        for h, (_, a0, z0) in enumerate(HEAD_SLICES):
            lp = torch.log_softmax(mlog[:, a0:z0].float() / a.tau_m, -1)
            dists.append(lp)
            chosen.append(lp.gather(1, cls[:, h:h + 1])[:, 0])
        return torch.stack(chosen, 1), dists

    @torch.no_grad()
    def fill_old(data):
        model.eval()
        for i in range(0, data.n, 256):
            b, steps, r = data.batch(np.arange(i, min(i + 256, data.n)), dev, torch)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                ulog, pk, mlog, _ = forward(model, b)
            lp = unit_logprobs(ulog, b)
            data.old_u[r] = lp.gather(1, b["u_y"][:, None])[:, 0].cpu().numpy()
            pl = torch.log_softmax(pk.float() / a.tau_u, -1)
            data.old_p[r] = pl.gather(1, (b["u_pick"].clamp(min=1) - 1)[:, None])[:, 0].cpu().numpy()
            data.old_m[steps] = market_logprobs(mlog, b["m_cls"])[0].cpu().numpy()
        model.train()
        tr = data.u_train
        return float(np.abs(data.old_u[tr] - data.u_roll[tr]).mean()), float(np.abs(data.old_m - data.m_roll).mean())

    def ppo(data):
        rng = np.random.default_rng()
        acc = {k: 0.0 for k in ("pg_u", "pg_p", "pg_m", "kl_u", "kl_m", "clip_u", "clip_m")}
        nb = 0
        H = len(HEAD_SLICES)
        for _ in range(a.epochs):
            perm = rng.permutation(data.n)
            for i in range(0, data.n, a.mb):
                b, _, _ = data.batch(perm[i:i + a.mb], dev, torch)
                with torch.autocast("cuda", dtype=torch.bfloat16):
                    ulog, pk, mlog, _ = forward(model, b)
                    with torch.no_grad():
                        rulog, rpk, rmlog, _ = forward(ref, b)
                lp = unit_logprobs(ulog, b)
                with torch.no_grad():
                    lpr = unit_logprobs(rulog, b)
                tr = b["u_train"].float()
                ntr = tr.sum().clamp(min=1.0)
                A = b["u_adv"]
                ratio = torch.exp(lp.gather(1, b["u_y"][:, None])[:, 0] - b["old_u"])
                obj = torch.min(ratio * A, ratio.clamp(1 - a.clip, 1 + a.clip) * A)
                pg_u = -(obj * tr).sum() / ntr
                kl_u = ((lp.exp() * (lp - lpr)).sum(-1) * tr).sum() / ntr

                pm = (b["u_pick"] > 0).float() * tr
                pl = torch.log_softmax(pk.float() / a.tau_u, -1)
                with torch.no_grad():
                    plr = torch.log_softmax(rpk.float() / a.tau_u, -1)
                ratio_p = torch.exp(pl.gather(1, (b["u_pick"].clamp(min=1) - 1)[:, None])[:, 0] - b["old_p"])
                obj_p = torch.min(ratio_p * A, ratio_p.clamp(1 - a.clip, 1 + a.clip) * A)
                npk = pm.sum().clamp(min=1.0)
                pg_p = -(obj_p * pm).sum() / npk
                kl_p = ((pl.exp() * (pl - plr)).sum(-1) * pm).sum() / npk

                mlp, md = market_logprobs(mlog, b["m_cls"])
                with torch.no_grad():
                    _, mdr = market_logprobs(rmlog, b["m_cls"])
                Am = b["m_adv"][:, None]
                ratio_m = torch.exp(mlp - b["old_m"])
                pg_m = -torch.min(ratio_m * Am, ratio_m.clamp(1 - a.clip, 1 + a.clip) * Am).mean()
                kl_m = sum((l.exp() * (l - lr_)).sum(-1).mean() for l, lr_ in zip(md, mdr)) / H

                loss = pg_u + 0.3 * pg_p + a.mkt_w * pg_m + a.beta * (kl_u + 0.3 * kl_p + kl_m)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
                with torch.no_grad():
                    acc["pg_u"] += pg_u.item()
                    acc["pg_p"] += pg_p.item()
                    acc["pg_m"] += pg_m.item()
                    acc["kl_u"] += kl_u.item()
                    acc["kl_m"] += kl_m.item()
                    acc["clip_u"] += ((((ratio - 1).abs() > a.clip).float() * tr).sum() / ntr).item()
                    acc["clip_m"] += ((ratio_m - 1).abs() > a.clip).float().mean().item()
                nb += 1
        return {k: v / max(1, nb) for k, v in acc.items()}

    with mp.get_context("spawn").Pool(a.procs) as pool:
        if start == 0:
            export_npz(ref, ck["cfg"], decode, os.path.join(a.out, "it000.npz"))
            ev = run_eval(pool, os.path.join(a.out, "it000.npz"), kw, eval_opps, eval_seeds, modes)
            print("eval it 0", json.dumps(ev), flush=True)
            with open(log_path, "a") as f:
                f.write(json.dumps({"it": 0, "eval": ev}) + "\n")
        for it in range(start, a.iters):
            t0 = time.time()
            export_npz(model, ck["cfg"], decode, cur)
            rng = np.random.default_rng(a.seed * 100_003 + it)
            jobs = []
            for g in range(a.groups):
                oi = int(rng.integers(len(train_opps)))
                seat = int(rng.integers(2))
                seed = 1_000_000 + it * 100 + g
                for _ in range(a.k):
                    jobs.append({"weights": cur, "kwargs": kw, "opp": train_opps[oi][0], "opp_label": train_opps[oi][1],
                                 "seed": seed, "seat": seat, "sample_seed": int(rng.integers(2 ** 31)), "group": g})
            results = pool.map(rollout_job, jobs, chunksize=1)
            t_roll = time.time() - t0
            adv = group_advantages(results)
            games = [(results[i]["data"], v) for i, v in adv.items()]
            mine = [r["money"][r["job"]["seat"]] for r in results]
            theirs = [r["money"][1 - r["job"]["seat"]] for r in results]
            wins = float(np.mean([m > o for m, o in zip(mine, theirs)]))
            errors = sum(r["status"][r["job"]["seat"]] != "DONE" for r in results)
            rec = {"it": it + 1, "money": float(np.mean(mine)), "opp_money": float(np.mean(theirs)), "win": wins,
                   "errors": errors, "games_used": len(games), "t_roll": round(t_roll)}
            if games:
                data = RLData(games)
                du, dm = fill_old(data)
                stats = ppo(data)
                rec.update({"steps": data.n, "rows": int(len(data.u_y)), "logp_gap_u": du, "logp_gap_m": dm, **stats})
            rec["t_iter"] = round(time.time() - t0)
            torch.save({"state": model.state_dict(), "opt": opt.state_dict(), "cfg": ck["cfg"], "decode": decode,
                        "it": it}, last_path)
            if (it + 1) % a.eval_every == 0 or it + 1 == a.iters:
                tag = os.path.join(a.out, f"it{it + 1:03d}")
                shutil.copyfile(last_path, tag + ".pt")
                export_npz(model, ck["cfg"], decode, tag + ".npz")
                rec["eval"] = run_eval(pool, tag + ".npz", kw, eval_opps, eval_seeds, modes)
            print(json.dumps(rec), flush=True)
            with open(log_path, "a") as f:
                f.write(json.dumps(rec) + "\n")


if __name__ == "__main__":
    main()
