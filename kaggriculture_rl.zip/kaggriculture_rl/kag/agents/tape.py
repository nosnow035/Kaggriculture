"""Tape agent: replay one seat's recorded 720-turn action history verbatim.

This is the "tape" strategy from forum #739273. It is the baseline any learned
policy has to beat under paired-seed evaluation.
"""
import copy
import json
from functools import lru_cache

from kag.replay import obs_step

PASS = {"farmer": ["PASS"], "hands": [], "market": []}


@lru_cache(maxsize=256)
def load_tape(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["actions"]


def make_tape_agent(path):
    tape = load_tape(path)

    def agent(obs, config=None):
        s = obs_step(obs)
        if 0 <= s < len(tape) and tape[s]:
            return copy.deepcopy(tape[s])
        return copy.deepcopy(PASS)

    return agent
