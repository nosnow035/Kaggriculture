"""Closed-loop BC agent.

Each step the policy ranks the legal (tile, op) intents for every unit and an executor
walks the unit one tile toward its intent, performing the op on arrival. Market orders
are decoded from the per-product heads in a fixed order: sell, land, hire, animals,
seeds, products. Decoding uses the thresholds stored by scripts/calibrate.py.

act() is split into build_ctx() (observation -> network inputs) and decide() (network
outputs -> action), so the batched self-play runner in kag/rl_batch.py can hoist the
forward pass out of the loop and run many games through one batched forward without a
second copy of the executor. Profiling says the forward is ~97% of a step (110 ms vs
1.2 ms of feature building), so batching it is what makes RL-scale self-play possible.

With sample=True the unit intents, pickup counts and market classes are drawn from the
tempered softmax instead (the stochastic policy RL fine-tunes), and record=True logs the
exact network inputs and sampled choices so the learner can recompute log-probabilities.

endgame=True adds season-end rules the demonstrations cannot teach reliably; daily_work=True
keeps the daily chores from being dropped in the evening.

Weights may be a torch checkpoint (.pt, for local evaluation) or an exported .npz
(pure numpy, for the Kaggle runtime).
"""
import math

import numpy as np

from kag.features import (
    ANIMAL_LIST, ANIMALS, BOARD, CROP_LIST, CROPS, K_T, MARKET_HEADS, NT, PASS_IDX, PRODUCTS, QTY, SELL_FRAC,
    SHED_BASE, SHED_OPS, SHED_SET, SHED_TILES, SOP, TF, TILE_OPS, TOP,
    base_masks, cand_target, full_mask, global_feats, tile_static, unit_feats, unit_gate_bits, unit_positions,
)
from kag.replay import obs_step

HEAD = {}
_o = 0
for _name, _n in MARKET_HEADS:
    HEAD[_name] = (_o, _o + _n)
    _o += _n

BLOCK_W = 32  # recorded width of the per-unit "already taken by a higher-confidence unit" list
LAST_DAY = 29
LAND_CUTOFF_DAY = 22
LIQUIDATE_HOUR = 18


class NumpyBackend:
    def __init__(self, path):
        from kag.np_model import NPNet, np_pair_feats, np_shed_pair
        self.net = NPNet(path)
        self.decode = self.net.decode
        self.style_map = self.net.styles
        self._pair, self._spair = np_pair_feats, np_shed_pair

    def forward(self, tiles, glob, u_feat, u_gate, claimed, claimed_shed, self_tile, style=0):
        te, ge = self.net.encode(tiles, glob, style)
        mlog = self.net.market_logits(te, ge)
        u_xy = np.round(u_feat[:, :2] * 9.0)
        pair = self._pair(u_xy, claimed, self_tile)
        spair = self._spair(u_xy, claimed_shed, self_tile == -2)
        ulog, pk = self.net.unit_logits(te, ge, u_feat, u_gate, pair, spair)
        return mlog, ulog, pk


class TorchBackend:
    def __init__(self, path):
        import torch
        from kag.model import BCNet, pair_feats, shed_pair_feats
        torch.set_num_threads(1)
        ck = torch.load(path, map_location="cpu", weights_only=False)
        self.m = BCNet(**ck["cfg"])
        # Checkpoints trained before the critic was added have no v_mlp.*; the value head is
        # not used for acting, so those load fine -- but anything else missing is a real error.
        missing, unexpected = self.m.load_state_dict(ck["state"], strict=False)
        stale = [k for k in missing if not k.startswith("v_mlp.")]
        if stale or unexpected:
            raise RuntimeError(f"{path}: missing {stale}, unexpected {list(unexpected)}")
        self.m.eval()
        self.decode = ck.get("decode", {})
        self.style_map = ck.get("style_map") or {}
        self.torch, self._pair, self._spair = torch, pair_feats, shed_pair_feats

    def forward(self, tiles, glob, u_feat, u_gate, claimed, claimed_shed, self_tile, style=0):
        torch = self.torch
        with torch.no_grad():
            st_id = torch.tensor([int(style)]) if getattr(self.m, "style", None) is not None else None
            te, ge = self.m.encode(torch.from_numpy(tiles)[None], torch.from_numpy(glob)[None], st_id)
            mlog = self.m.market_logits(te, ge)[0].numpy()
            uf = torch.from_numpy(u_feat)
            u_xy = torch.round(uf[:, :2] * 9.0)
            st = torch.from_numpy(self_tile)
            U = len(u_feat)
            pair = self._pair(u_xy, torch.from_numpy(claimed)[None].expand(U, NT), st)
            spair = self._spair(u_xy, torch.full((U,), float(claimed_shed)), st == -2)
            ulog, pk = self.m.unit_logits(te, ge, torch.zeros(U, dtype=torch.long), uf,
                                          torch.from_numpy(u_gate), pair, spair)
        return mlog, ulog.numpy(), pk.numpy()


def _to_plain(o):
    if isinstance(o, dict):
        return {k: _to_plain(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_to_plain(v) for v in o]
    return o


def step_toward(pos, tgt):
    dx, dy = tgt[0] - pos[0], tgt[1] - pos[1]
    if dx == 0 and dy == 0:
        return None
    if abs(dx) >= abs(dy):
        return "EAST" if dx > 0 else "WEST"
    return "SOUTH" if dy > 0 else "NORTH"


def _softmax(x):
    x = x - x.max()
    e = np.exp(x)
    return e / e.sum()


class BCPolicy:
    def __init__(self, weights, keep_margin=0.0, calibrated=True, pass_offset=None, theta_scale=1.0,
                 style=None, feed_guard=True, care_guard=True, feed_topup=True, reserve_mode="2x",
                 opening=None, opening_steps=0, sample=False, tau_u=1.0, tau_m=1.0, seed=None, record=False,
                 endgame=False, guard_last_day=27, daily_work=False, daily_hour=14, daily_bonus=5.0,
                 backend="auto"):
        # Opening book: the first days start from the same state in every game, so a robust
        # demonstrator's opening is replayed verbatim and the policy takes over on-distribution.
        self.opening = None
        if opening and opening_steps > 0:
            import json
            with open(opening, "r", encoding="utf-8") as f:
                self.opening = json.load(f)["actions"]
        self.opening_steps = opening_steps
        self.feed_guard = feed_guard
        self.care_guard = care_guard
        self.feed_topup = feed_topup
        self.reserve_mode = reserve_mode
        self.endgame = bool(endgame)
        self.guard_last_day = int(guard_last_day)
        self.daily_work = bool(daily_work)
        self.daily_hour = int(daily_hour)
        self.daily_bonus = float(daily_bonus)
        if backend == "none":  # inputs only; the caller runs the network (kag/rl_batch.py)
            self.be = None
            dec = {}
        else:
            self.be = NumpyBackend(weights) if str(weights).endswith(".npz") else TorchBackend(weights)
            dec = self.be.decode if calibrated else {}
        self.theta = {k: min(0.99, v * theta_scale) for k, v in (dec.get("theta") or {}).items()}
        self.pass_offset = dec.get("pass_offset", 0.0) if pass_offset is None else pass_offset
        self.keep_margin = keep_margin
        if style is None:
            style = (self.be.decode.get("style", 0) if self.be is not None else 0)
        if isinstance(style, str):
            style = self.be.style_map.get(style, 0)
        self.style = int(style)
        self.sample = bool(sample)
        self.tau_u = float(tau_u)
        self.tau_m = float(tau_m)
        self.rng = np.random.default_rng(seed)
        self.rec = [] if record else None
        self._mk = {}
        self.intents = {}
        self.day = -1

    def _draw(self, logits, tau):
        p = _softmax(np.asarray(logits, dtype=np.float64) / tau)
        i = min(int(np.searchsorted(np.cumsum(p), self.rng.random())), len(p) - 1)
        if p[i] <= 0.0:
            i = int(np.argmax(p))
        return i, float(np.log(max(p[i], 1e-300)))

    def build_ctx(self, obs):
        """Observation -> everything the network and the executor need for this step.

        Returns a dict; when the opening book covers this step the dict only holds
        {"opening_action": ...} and no network call is needed."""
        obs = _to_plain(obs)
        step = obs_step(obs)
        obs["step"] = step
        me = int(obs["player"])
        day = int(obs["day"])
        hour = int(obs["hour"])
        farm = obs["farms"][me]
        priv = obs.get("private") or {}
        if day != self.day:
            self.intents, self.day = {}, day
        if self.opening is not None and step < self.opening_steps and step < len(self.opening) \
                and isinstance(self.opening[step], dict):
            self.intents = {}
            a = self.opening[step]
            return {"opening_action": {"farmer": list(a.get("farmer") or ["PASS"]),
                                       "hands": [list(h) for h in (a.get("hands") or [])],
                                       "market": [list(o) for o in (a.get("market") or [])]}}
        pos = unit_positions(farm)
        U = len(pos)

        tiles = np.zeros((NT, TF), dtype=np.float32)
        for y in range(BOARD):
            for x in range(BOARD):
                tiles[y * BOARD + x] = tile_static(farm["tiles"][y][x], x, y, step, day)
        occ = np.zeros(NT)
        for (x, y) in pos:
            occ[y * BOARD + x] += 1
        tiles[:, 42] = np.round(np.minimum(occ, 4) * 63) / 255.0
        tiles[:, 43] = 0.0
        tiles = np.round(tiles * 255.0) / 255.0  # match the uint8 quantisation used in training
        glob = np.asarray(global_feats(obs, me), dtype=np.float32).astype(np.float16).astype(np.float32)
        tm, sm = base_masks(obs, me)

        claimed = np.zeros(NT, dtype=np.float32)
        claimed_shed = 0.0
        self_tile = np.full(U, -1, dtype=np.int64)
        for k, c in self.intents.items():
            if k >= U:
                continue
            if c < SHED_BASE:
                claimed[c // K_T] += 1
                self_tile[k] = c // K_T
            elif c < PASS_IDX:
                claimed_shed += 1
                self_tile[k] = -2

        uf, gates = [], []
        for k, p in enumerate(pos):
            f, inv = unit_feats(obs, me, k, p)
            uf.append(f)
            gates.append(unit_gate_bits(inv))
        u_feat = np.asarray(uf, dtype=np.float32).astype(np.float16).astype(np.float32)
        u_gate = np.asarray(gates, dtype=np.float32)
        return {"step": step, "day": day, "hour": hour, "farm": farm, "priv": priv, "pos": pos,
                "tiles": tiles, "glob": glob, "tmask": tm, "smask": sm, "claimed": claimed,
                "claimed_shed": claimed_shed, "self_tile": self_tile, "u_feat": u_feat,
                "u_gate": u_gate, "gates": gates}

    def decide(self, ctx, mlog, ulog, pk):
        """Network outputs -> the action dict (and one recorded row when record=True)."""
        day, hour, farm, priv, pos = ctx["day"], ctx["hour"], ctx["farm"], ctx["priv"], ctx["pos"]
        tm, sm, gates = ctx["tmask"], ctx["smask"], ctx["gates"]
        U = len(pos)
        ulog = np.asarray(ulog, dtype=np.float64)
        ulog[:, PASS_IDX] += self.pass_offset

        masked = [np.where(full_mask(tm, sm, gates[k]), ulog[k], -1e9) for k in range(U)]
        guarded = set()
        if self.daily_work and hour >= self.daily_hour:
            guarded |= self._guard_daily(masked, farm, priv, pos, gates)
        if self.care_guard and day <= self.guard_last_day:
            guarded |= self._guard_care(masked, farm, priv, pos, gates, hour)
        conf = [float(np.max(lg)) for lg in masked]
        taken = set()
        choice = {}
        u_blocked = np.full((U, BLOCK_W), -1, dtype=np.int16)
        u_logp = np.zeros(U, dtype=np.float32)
        u_train = np.array([k not in guarded for k in range(U)], dtype=bool)
        for k in sorted(range(U), key=lambda i: -conf[i]):
            lg = masked[k].copy()
            blocked = [c for c in taken if lg[c] > -1e8]
            for c in taken:
                lg[c] = -1e9
            if len(blocked) > BLOCK_W:
                u_train[k] = False
            u_blocked[k, :min(len(blocked), BLOCK_W)] = blocked[:BLOCK_W]
            if self.sample:
                best, u_logp[k] = self._draw(lg, self.tau_u)
            else:
                best = int(np.argmax(lg))
                prev = self.intents.get(k)
                if prev is not None and self.keep_margin > 0 and lg[prev] > -1e8 \
                        and lg[prev] >= lg[best] - self.keep_margin:
                    best = prev
            choice[k] = best
            if best < SHED_BASE:
                taken.add(best)

        seeds_left = dict(priv.get("seeds") or {})
        acts, new_intents = [], {}
        u_pick = np.zeros(U, dtype=np.int8)
        for k in range(U):
            c = choice[k]
            p = pos[k]
            if c == PASS_IDX:
                acts.append(["PASS"])
                continue
            tgt = cand_target(c, p)
            at = (SHED_BASE <= c < PASS_IDX and tuple(p) in SHED_SET) or tuple(p) == tuple(tgt)
            if not at:
                acts.append([step_toward(p, tgt)])
                new_intents[k] = c
                continue
            if c < SHED_BASE:
                op = TILE_OPS[c % K_T]
                if op.startswith("PLANT_"):
                    crop = op[6:]
                    if seeds_left.get(crop, 0) <= 0:
                        acts.append(["PASS"])
                        new_intents[k] = c
                        continue
                    seeds_left[crop] -= 1
                    acts.append(["PLANT", crop])
                elif op.startswith("PLACE_"):
                    acts.append(["PLACE", op[6:]])
                else:
                    acts.append([op])
            else:
                sop = SHED_OPS[c - SHED_BASE]
                if sop == "DROP":
                    acts.append(["DROP"])
                else:
                    if self.sample:
                        n = self._draw(pk[k], self.tau_u)[0] + 1
                    else:
                        n = int(np.argmax(pk[k])) + 1
                    u_pick[k] = n
                    acts.append(["PICKUP", sop[7:], n])
        self.intents = new_intents
        self._mk = {}
        market = self.market_orders(mlog, priv, farm, day, hour)
        if self.rec is not None:
            self.rec.append({
                "step": ctx["step"], "tiles": np.round(ctx["tiles"] * 255.0).astype(np.uint8),
                "glob": ctx["glob"].astype(np.float16), "tmask": np.packbits(tm, axis=-1), "smask": sm,
                "claimed": ctx["claimed"].astype(np.uint8), "claimed_shed": ctx["claimed_shed"],
                "u_feat": ctx["u_feat"].astype(np.float16), "u_gate": ctx["u_gate"].astype(bool),
                "u_self": ctx["self_tile"].astype(np.int16),
                "u_y": np.array([choice[k] for k in range(U)], np.int16),
                "u_blocked": u_blocked, "u_logp": u_logp, "u_train": u_train, "u_pick": u_pick,
                "m_cls": np.array([self._mk.get(n, (0, 0.0))[0] for n, _ in MARKET_HEADS], np.int8),
                "m_logp": np.array([self._mk.get(n, (0, 0.0))[1] for n, _ in MARKET_HEADS], np.float32),
            })
        return {"farmer": acts[0], "hands": acts[1:], "market": market}

    def act(self, obs):
        ctx = self.build_ctx(obs)
        if "opening_action" in ctx:
            return ctx["opening_action"]
        mlog, ulog, pk = self.be.forward(ctx["tiles"], ctx["glob"], ctx["u_feat"], ctx["u_gate"],
                                         ctx["claimed"], ctx["claimed_shed"], ctx["self_tile"], self.style)
        return self.decide(ctx, mlog, ulog, pk)

    def _cls(self, mlog, name):
        a, z = HEAD[name]
        if self.sample:
            c, lp = self._draw(mlog[a:z], self.tau_m)
            self._mk[name] = (c, lp)
            return c
        p = _softmax(np.asarray(mlog[a:z], dtype=np.float64))
        th = self.theta.get(name)
        if th is None:
            return int(np.argmax(p))
        if 1.0 - p[0] < th:
            return 0
        return int(np.argmax(p[1:])) + 1

    GUARD_BONUS = 30.0

    def _guard_care(self, masked, farm, priv, pos, gates, hour):
        """An animal unfed two days running escapes for good. When one already missed
        yesterday's feed, push FEED for it (units carrying wheat) and a wheat pickup for the
        nearest empty-handed units. Only fires for at-risk animals; otherwise the policy's
        ranking is untouched. Returns the units whose logits were changed."""
        touched = set()
        if hour < 2:
            return touched
        risk = []
        for y in range(BOARD):
            for x in range(BOARD):
                t = farm["tiles"][y][x]
                if isinstance(t, dict) and t.get("animal") and not t.get("fed_today") \
                        and t.get("consecutive_unfed", 0) >= 1:
                    risk.append(y * BOARD + x)
        if not risk:
            return touched
        feed_cols = [t * K_T + TOP["FEED"] for t in risk]
        carriers = [k for k in range(len(pos)) if gates[k][0]]
        for k in carriers:
            for c in feed_cols:
                if masked[k][c] > -1e8:
                    masked[k][c] += self.GUARD_BONUS
                    touched.add(k)
        deficit = len(risk) - len(carriers)
        if deficit > 0 and int((priv.get("shed") or {}).get("WHEAT", 0)) > 0:
            pick = SHED_BASE + SOP["PICKUP_WHEAT"]
            empty = [k for k in range(len(pos)) if not gates[k][0] and masked[k][pick] > -1e8]
            empty.sort(key=lambda k: min(abs(pos[k][0] - sx) + abs(pos[k][1] - sy) for sx, sy in SHED_TILES))
            for k in empty[:deficit]:
                masked[k][pick] += self.GUARD_BONUS
                touched.add(k)
        return touched

    def _guard_daily(self, masked, farm, priv, pos, gates):
        """Chores still owed today (FEED, CARE, WATER) get a moderate bonus so units do them
        instead of idling late in the day; a missed CARE or FEED day forfeits the animal's
        banked production bonus. Returns the units whose logits were changed."""
        touched = set()
        unfed, uncared, dry = [], [], []
        for y in range(BOARD):
            for x in range(BOARD):
                t = farm["tiles"][y][x]
                if not isinstance(t, dict):
                    continue
                i = y * BOARD + x
                if t.get("animal"):
                    if not t.get("fed_today"):
                        unfed.append(i)
                    if not t.get("cared_today"):
                        uncared.append(i)
                elif t.get("kind") == "PLANT" and not t.get("watered_today"):
                    dry.append(i)
        if not (unfed or uncared or dry):
            return touched
        b = self.daily_bonus
        care_cols = [i * K_T + TOP["CARE"] for i in uncared] + [i * K_T + TOP["WATER"] for i in dry]
        feed_cols = [i * K_T + TOP["FEED"] for i in unfed]
        carriers = [k for k in range(len(pos)) if gates[k][0]]
        for k in range(len(pos)):
            row = masked[k]
            for c in care_cols + (feed_cols if gates[k][0] else []):
                if row[c] > -1e8:
                    row[c] += b
                    touched.add(k)
        deficit = len(unfed) - len(carriers)
        if deficit > 0 and int((priv.get("shed") or {}).get("WHEAT", 0)) > 0:
            pick = SHED_BASE + SOP["PICKUP_WHEAT"]
            empty = [k for k in range(len(pos)) if not gates[k][0] and masked[k][pick] > -1e8]
            empty.sort(key=lambda k: min(abs(pos[k][0] - sx) + abs(pos[k][1] - sy) for sx, sy in SHED_TILES))
            for k in empty[:deficit]:
                masked[k][pick] += b
                touched.add(k)
        return touched

    def feed_reserve(self, priv, farm, day):
        """Wheat to keep on hand so the herd can be fed today and tomorrow. Selling the feed
        of your own animals is never a strategy, only a way to lose them (two unfed days and
        they escape). Not needed after guard_last_day: an escape then lands after the season ends."""
        if not self.feed_guard or farm is None or day > self.guard_last_day:
            return 0, 0
        shed = priv.get("shed") or {}
        placed = [t for row in farm["tiles"] for t in row if isinstance(t, dict) and t.get("animal")]
        herd = len(placed) + sum(int(shed.get(a, 0)) for a in ANIMAL_LIST)
        carried = sum(int(inv.get("WHEAT", 0)) for inv in (priv.get("inventories") or []))
        if self.reserve_mode == "need":
            # Only what is still owed today plus one feed per head tomorrow.
            return sum(1 for t in placed if not t.get("fed_today")) + herd, carried
        return 2 * herd, carried

    def market_orders(self, mlog, priv, farm=None, day=0, hour=0):
        shed = priv.get("shed") or {}
        reserve, carried = self.feed_reserve(priv, farm, day)
        need = max(0, reserve - carried)
        liquidate = self.endgame and day >= LAST_DAY and hour >= LIQUIDATE_HOUR
        sells, buys = [], []
        for p in PRODUCTS:
            c = self._cls(mlog, "sell_" + p)
            if liquidate:
                c = 4
            stock = int(shed.get(p, 0))
            if p == "WHEAT":
                stock = max(0, stock - need)
            if c > 0 and stock > 0:
                n = stock if c == 4 else max(1, math.ceil(SELL_FRAC[c] * stock))
                sells.append(["SELL", p, n])
        land = [["BUY_LAND"]] if self._cls(mlog, "land") == 1 else []
        if self.endgame and day >= LAND_CUTOFF_DAY:
            land = []
        hires = [["HIRE"] for _ in range(self._cls(mlog, "hire"))]
        for a in ANIMAL_LIST:
            q = QTY[self._cls(mlog, "animal_" + a)]
            if self.endgame and day + ANIMALS[a]["first"] + 1 >= LAST_DAY:
                q = 0
            if q > 0:
                buys.append(["BUY_ANIMAL", a, q])
        for c in CROP_LIST:
            q = QTY[self._cls(mlog, "seed_" + c)]
            if self.endgame and day + CROPS[c]["first"] >= LAST_DAY:
                q = 0
            if q > 0:
                buys.append(["BUY_SEED", c, q])
        top_up = max(0, need - int(shed.get("WHEAT", 0))) if self.feed_topup else 0
        for it in ("WHEAT", "FERTILIZER"):
            q = QTY[self._cls(mlog, "buy_" + it)]
            if it == "WHEAT":
                q = max(q, top_up)
            if q > 0:
                buys.append(["BUY_PRODUCT", it, q])
        if top_up > 0:
            # Feed first: put the wheat order ahead of other buys so the 10-order cap
            # and a thin wallet cannot crowd it out.
            wheat = [b for b in buys if b[0] == "BUY_PRODUCT" and b[1] == "WHEAT"]
            buys = wheat + [b for b in buys if not (b[0] == "BUY_PRODUCT" and b[1] == "WHEAT")]
            return (sells + wheat + land + hires + [b for b in buys if b not in wheat])[:10]
        return (sells + land + hires + buys)[:10]


def make_bc_agent(weights, **kw):
    pol = BCPolicy(weights, **kw)

    def agent(obs, config=None):
        return pol.act(obs)

    return agent
