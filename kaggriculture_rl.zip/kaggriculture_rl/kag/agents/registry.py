"""Build agent callables from picklable specs, so multiprocessing workers can construct them."""


def build_agent(spec):
    kind = spec["kind"] if isinstance(spec, dict) else spec
    if kind in ("starter", "random", "pass"):
        from kaggle_environments.envs.kaggriculture.kaggriculture import agents
        return agents[kind]
    if kind == "tape":
        from kag.agents.tape import make_tape_agent
        return make_tape_agent(spec["path"])
    if kind == "bc":
        from kag.agents.bc import make_bc_agent
        return make_bc_agent(spec["weights"], **spec.get("kwargs", {}))
    if kind == "file":
        # A submission-style main.py; kaggle_environments loads the path itself.
        return spec["path"]
    raise ValueError(f"unknown agent spec: {spec!r}")


def spec_name(spec):
    if isinstance(spec, str):
        return spec
    if spec["kind"] == "tape":
        return "tape:" + spec["path"].replace("\\", "/").rsplit("/", 1)[-1].removesuffix(".json")
    if spec["kind"] == "bc":
        return "bc:" + spec["weights"].replace("\\", "/").rsplit("/", 1)[-1]
    if spec["kind"] == "file":
        return "file:" + spec["path"].replace("\\", "/").rsplit("/", 2)[-2]
    return spec["kind"]
