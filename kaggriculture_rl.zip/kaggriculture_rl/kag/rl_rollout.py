"""Rollout worker for RL fine-tuning.

Torch-free on purpose: it runs in spawn workers that do numpy/MKL matmuls, and loading
torch next to them crashes on the duplicate OpenMP runtime.
"""
import contextlib
import io

import numpy as np

STEP_KEYS = ("tiles", "glob", "tmask", "smask", "claimed", "m_cls", "m_logp")
ROW_KEYS = ("u_feat", "u_gate", "u_self", "u_y", "u_blocked", "u_logp", "u_train", "u_pick")


def collate(rec):
    out = {k: np.stack([r[k] for r in rec]) for k in STEP_KEYS}
    out["step"] = np.array([r["step"] for r in rec], np.int16)
    out["claimed_shed"] = np.array([r["claimed_shed"] for r in rec], np.uint8)
    for k in ROW_KEYS:
        out[k] = np.concatenate([r[k] for r in rec])
    out["u_step"] = np.concatenate([np.full(len(r["u_y"]), i, np.int32) for i, r in enumerate(rec)])
    return out


def rollout_job(job):
    """Play one game with the stochastic policy in job['seat'] against job['opp']."""
    from kag.agents.bc import BCPolicy
    from kag.agents.registry import build_agent
    with contextlib.redirect_stdout(io.StringIO()):
        from kaggle_environments import make
    env = make("kaggriculture", configuration={"seed": int(job["seed"])})
    pol = BCPolicy(job["weights"], sample=True, record=True, seed=job["sample_seed"], **job["kwargs"])

    def me(obs, config=None):
        return pol.act(obs)

    opp = build_agent(job["opp"])
    seat = int(job["seat"])
    env.run([me, opp] if seat == 0 else [opp, me])
    last = env.steps[-1]
    money = [float(last[0].reward or 0.0), float(last[1].reward or 0.0)]
    status = [last[0].status, last[1].status]
    data = collate(pol.rec) if pol.rec else None
    return {"job": {k: v for k, v in job.items() if k not in ("weights", "kwargs")},
            "money": money, "status": status, "data": data}
