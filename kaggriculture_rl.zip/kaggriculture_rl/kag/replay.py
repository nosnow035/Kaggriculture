"""Load Kaggriculture replays and pull out per-seat trajectories.

Replay layout (env.toJSON()): steps[t][seat] holds the observation *after* step t-1
resolved and the action the seat submitted in response to steps[t-1]'s observation.
So the decision made at step s is (steps[s][seat].observation, steps[s+1][seat].action).
"""
import json
import zipfile

TURNS_PER_DAY = 24
SHARED_KEYS = ("farms", "market", "town", "day", "hour")


def load_replay(path, member=None):
    if member is None:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    with zipfile.ZipFile(path) as z:
        with z.open(member) as f:
            return json.load(f)


def obs_step(obs):
    """Seat 1 observations have no 'step' (forum #737545), so rebuild it from day/hour."""
    s = obs.get("step") if hasattr(obs, "get") else None
    if s is not None:
        return int(s)
    return int(obs.get("day", 0)) * TURNS_PER_DAY + int(obs.get("hour", 0))


def replay_meta(rep):
    info = rep.get("info") or {}
    agents = info.get("Agents") or []
    names = [a.get("Name") for a in agents] if agents else (info.get("TeamNames") or [None, None])
    scores = [a.get("InitialScore") for a in agents] if agents else [None, None]
    seed = info.get("seed")
    if seed is None:
        seed = (rep.get("configuration") or {}).get("seed")
    last = rep["steps"][-1]
    return {
        "episode_id": info.get("EpisodeId") or rep.get("id"),
        "seed": seed,
        "rewards": [last[0].get("reward"), last[1].get("reward")],
        "statuses": [last[0].get("status"), last[1].get("status")],
        "names": names,
        "scores": scores,
        "n_steps": len(rep["steps"]),
    }


def seat_actions(rep, seat):
    """tape[s] = the action this seat submitted after seeing the observation at step s."""
    steps = rep["steps"]
    return [steps[t][seat].get("action") for t in range(1, len(steps))]


def seat_decisions(rep, seat):
    """Yield (step, observation, action) for one seat, filling shared fields from seat 0."""
    steps = rep["steps"]
    for t in range(1, len(steps)):
        obs = dict(steps[t - 1][seat]["observation"])
        src = steps[t - 1][0]["observation"]
        for k in SHARED_KEYS:
            if obs.get(k) in (None, {}, []):
                obs[k] = src.get(k)
        obs["step"] = obs_step(obs)
        yield obs["step"], obs, steps[t][seat].get("action")
