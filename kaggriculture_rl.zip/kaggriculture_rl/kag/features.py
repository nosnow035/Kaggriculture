"""Observation -> tensors and demonstration -> labels for the BC policy.

Unit decisions are modelled as *intents*: the next non-move op a unit performs and
the tile it performs it on. The model ranks legal (tile, op) candidates and an
executor walks the unit there (forum #738079: predict object-level options and let
an executor own movement/legality; PTCG 191st: rank the legal set, don't classify a
fixed vocabulary).

Candidate index space (N_CAND = 1707):
  tile * 17 + k   for k in TILE_OPS, tile = y * 10 + x
  1700 + j        for j in SHED_OPS (performed on the nearest shed-access tile)
  1706            PASS (idle where you stand)
"""
import math

import numpy as np

BOARD = 10
NT = BOARD * BOARD
TPD = 24
N_STEPS = 720
SHED_TILES = [(4, 4), (5, 4), (4, 5), (5, 5)]
SHED_SET = set(SHED_TILES)

# Mirrors kaggle_environments/envs/kaggriculture/kaggriculture.py (v1.32.7).
CROPS = {
    "WHEAT":      {"seed": 10, "first": 2, "maxd": 4, "interval": 0, "maxy": 6, "ongoing": False},
    "CARROT":     {"seed": 20, "first": 2, "maxd": 3, "interval": 0, "maxy": 4, "ongoing": False},
    "TOMATO":     {"seed": 50, "first": 8, "maxd": 8, "interval": 1, "maxy": 4, "ongoing": True},
    "STRAWBERRY": {"seed": 100, "first": 10, "maxd": 10, "interval": 2, "maxy": 4, "ongoing": True},
    "MELON":      {"seed": 80, "first": 10, "maxd": 12, "interval": 0, "maxy": 6, "ongoing": False},
}
ANIMALS = {
    "GOOSE": {"cost": 300, "structure": "COOP", "first": 4, "interval": 1, "held": 4, "product": "EGG"},
    "COW":   {"cost": 400, "structure": "PASTURE", "first": 8, "interval": 2, "held": 6, "product": "MILK"},
    "SHEEP": {"cost": 500, "structure": "PASTURE", "first": 6, "interval": 3, "held": 6, "product": "WOOL"},
}
CROP_LIST = list(CROPS)
ANIMAL_LIST = list(ANIMALS)
PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
SHED_ITEMS = PRODUCTS + ANIMAL_LIST
MARKET_BASE_T = {
    "WHEAT": (25, 400), "CARROT": (35, 450), "TOMATO": (60, 200), "STRAWBERRY": (120, 100),
    "MELON": (250, 300), "EGG": (50, 332), "MILK": (160, 122), "WOOL": (200, 105), "FERTILIZER": (100, 200),
}
MARKET_I0 = 10000
SHOPS = sorted(["BAKERY", "PIZZA_SHOP", "BRUNCH_SPOT", "YARN_STORE", "ICE_CREAM_SHOP",
                "PET_CAFE", "SMOOTHIE_SHOP", "FARMERS_MARKET"])
QUADS = ["NW", "NE", "SW", "SE"]
LAND_PRICES = [1000, 2000, 4000]

TILE_OPS = ["WATER", "HARVEST", "FERTILIZE", "DIG", "FEED", "CARE", "COLLECT_FERTILIZER",
            "BUILD_COOP", "BUILD_PASTURE",
            "PLANT_WHEAT", "PLANT_CARROT", "PLANT_TOMATO", "PLANT_STRAWBERRY", "PLANT_MELON",
            "PLACE_GOOSE", "PLACE_COW", "PLACE_SHEEP"]
SHED_OPS = ["PICKUP_WHEAT", "PICKUP_FERTILIZER", "PICKUP_GOOSE", "PICKUP_COW", "PICKUP_SHEEP", "DROP"]
K_T = len(TILE_OPS)
K_S = len(SHED_OPS)
SHED_BASE = NT * K_T
PASS_IDX = SHED_BASE + K_S
N_CAND = PASS_IDX + 1
TOP = {op: i for i, op in enumerate(TILE_OPS)}
SOP = {op: i for i, op in enumerate(SHED_OPS)}
MOVES = {"NORTH", "SOUTH", "EAST", "WEST"}
PICKUP_MAX = 12  # pickup-count classes 1..12 (index n-1)

# Market quantity buckets (class c decodes to QTY[c]).
QTY = [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 64]
SELL_FRAC = [0.0, 0.25, 0.5, 0.75, 1.0]  # class 0 = hold, 4 = sell everything
MAX_HIRE_CLS = 11  # 0..10 HIRE orders in one step

TF = 44  # static tile features
GF = 112  # global features (zero-padded)
UF = 16  # unit features


def qty_class(n):
    n = max(0, int(n))
    c = 0
    for i, q in enumerate(QTY):
        if q <= n:
            c = i
    return c


def sell_class(n, stock):
    if stock <= 0 or n <= 0:
        return 0
    f = min(1.0, n / stock)
    if f > 0.75:
        return 4
    if f > 0.5:
        return 3
    if f > 0.25:
        return 2
    return 1


def quadrant(x, y):
    return ("N" if y < BOARD // 2 else "S") + ("W" if x < BOARD // 2 else "E")


def _log(v, scale):
    return min(1.0, math.log1p(max(0.0, float(v))) / scale)


def _clip01(v):
    return 0.0 if v < 0 else (1.0 if v > 1 else float(v))


def _price_dev(item, inv):
    base, T = MARKET_BASE_T[item]
    return _clip01(0.5 + (MARKET_I0 - inv) / (6.0 * T))  # 0.5 = at I0; +-3T -> 1/0


def tile_static(tile, x, y, step, day):
    f = [0.0] * TF
    if tile is None:
        f[0] = 1
    elif tile == "LOCKED":
        f[1] = 1
    elif isinstance(tile, dict):
        kind = tile.get("kind")
        if kind == "WEED":
            f[2] = 1
        elif kind == "PLANT":
            f[3] = 1
            crop = tile["crop"]
            cd = CROPS[crop]
            f[6 + CROP_LIST.index(crop)] = 1
            age = day - tile["planted_day"]
            f[14] = _clip01(age / 16.0)
            f[15] = 1.0 if tile.get("watered_today") else 0.0
            f[16] = _clip01(tile.get("consecutive_unwatered", 0) / 2.0)
            f[17] = _clip01(tile.get("yield_units", 0) / 6.0)
            f[18] = 1.0 if tile.get("fertilized_until_day", -1) >= day else 0.0
            f[19] = 1.0 if age >= cd["first"] else 0.0
            if not cd["ongoing"]:
                ws = (cd["maxd"] + 1) // 2
                f[20] = 1.0 if ws <= age <= cd["maxd"] else 0.0
            mls = tile.get("max_lifespan_step", -1)
            if mls >= 0:
                f[21] = 1.0 if step >= mls else 0.0
                f[22] = _clip01((mls - step) / 72.0)
            else:
                f[22] = 1.0
            if cd["ongoing"]:
                since = age - cd["first"]
                done = 0 if since < 0 else since // cd["interval"] + 1
                f[23] = _clip01((cd["maxy"] - done) / 4.0)
        elif kind in ("COOP", "PASTURE"):
            f[4 if kind == "COOP" else 5] = 1
            animal = tile.get("animal")
            if animal:
                a = ANIMALS[animal]
                f[11 + ANIMAL_LIST.index(animal)] = 1
                age = day - tile.get("placed_day", day)
                f[24] = _clip01(age / 10.0)
                y_units = tile.get("yield_units", 0)
                f[25] = _clip01(y_units / 6.0)
                f[26] = 1.0 if y_units >= a["held"] else 0.0
                f[27] = 1.0 if tile.get("fed_today") else 0.0
                f[28] = 1.0 if tile.get("cared_today") else 0.0
                f[29] = _clip01(tile.get("consecutive_unfed", 0) / 2.0)
                f[30] = 1.0 if tile.get("fertilizer_available") else 0.0
                f[31] = _clip01(tile.get("pending_care_bonus", 0) / 5.0)
                since = age + 1 - a["first"]
                if since < 0:
                    f[32] = _clip01(-since / 8.0)
                else:
                    f[32] = _clip01(((a["interval"] - since % a["interval"]) % a["interval"]) / 3.0)
            else:
                f[33] = 1
    q = quadrant(x, y)
    f[34 + QUADS.index(q)] = 1
    f[38] = 1.0 if (x, y) in SHED_SET else 0.0
    f[39] = x / 9.0
    f[40] = y / 9.0
    f[41] = min(abs(x - sx) + abs(y - sy) for sx, sy in SHED_TILES) / 10.0
    # 42, 43: reserved (unit occupancy / claimed are added per step by the dataset/agent)
    return f


def farm_summary(farm, step, day):
    crops = [0] * 5
    animals = [0] * 3
    empty_struct = weeds = empty = locked = 0
    ready = [0.0] * 8
    unwatered = unfed = 0
    for row in farm["tiles"]:
        for t in row:
            if t is None:
                empty += 1
            elif t == "LOCKED":
                locked += 1
            elif t.get("kind") == "WEED":
                weeds += 1
            elif t.get("kind") == "PLANT":
                crops[CROP_LIST.index(t["crop"])] += 1
                if not t.get("watered_today"):
                    unwatered += 1
                if t.get("yield_units", 0) > 0 and day - t["planted_day"] >= CROPS[t["crop"]]["first"]:
                    ready[PRODUCTS.index(t["crop"])] += t["yield_units"]
            elif t.get("animal"):
                animals[ANIMAL_LIST.index(t["animal"])] += 1
                if not t.get("fed_today"):
                    unfed += 1
                ready[PRODUCTS.index(ANIMALS[t["animal"]]["product"])] += t.get("yield_units", 0)
            else:
                empty_struct += 1
    return crops, animals, empty_struct, weeds, empty, locked, ready, unwatered, unfed


def global_feats(obs, me):
    step = int(obs["step"])
    day = int(obs["day"])
    hour = int(obs["hour"])
    farms = obs["farms"]
    f_me, f_op = farms[me], farms[1 - me]
    priv = obs.get("private") or {}
    seeds = priv.get("seeds") or {}
    shed = priv.get("shed") or {}
    market = obs.get("market") or {}
    prices = market.get("prices") or {}
    minv = market.get("inventory") or {}
    shops = (obs.get("town") or {}).get("unlocked_shops") or []
    g = []
    g += [step / N_STEPS, day / 30.0, hour / 23.0, (30 - day) / 30.0,
          math.sin(2 * math.pi * hour / TPD) * 0.5 + 0.5, math.cos(2 * math.pi * hour / TPD) * 0.5 + 0.5]
    m, om = float(f_me["money"]), float(f_op["money"])
    g += [_log(m, 12.5), _log(om, 12.5), _clip01(0.5 + (m - om) / 2e5)]
    g += [_log(seeds.get(c, 0), 4.0) for c in CROP_LIST]
    g += [_log(shed.get(i, 0), 4.7) for i in SHED_ITEMS]
    g += [_clip01(sum(shed.values()) / 100.0)]
    for it in PRODUCTS:
        base, _ = MARKET_BASE_T[it]
        g += [_clip01(prices.get(it, base) / (3.0 * base)), _price_dev(it, minv.get(it, MARKET_I0))]
    g += [_clip01(shops.count(s) / 3.0) for s in SHOPS]
    g += [len(shops) / 8.0, _clip01(((3 - (day % 3)) % 3 or 3) / 3.0) if len(shops) < 8 else 0.0]
    uq = f_me.get("unlocked_quadrants") or ["NW"]
    g += [1.0 if q in uq else 0.0 for q in QUADS]
    n_land = len(uq) - 1
    nxt = LAND_PRICES[n_land] if n_land < 3 else 0
    g += [_clip01((3 - n_land) / 3.0), _clip01(m / nxt / 2.0) if nxt else 1.0]
    g += [_clip01(f_me.get("hires_today", 0) / 16.0), _clip01(len(f_me.get("hands") or []) / 16.0),
          _clip01(len(f_op.get("hands") or []) / 16.0)]
    crops, animals, es, weeds, empty, locked, ready, unw, unf = farm_summary(f_me, step, day)
    g += [c / 40.0 for c in crops] + [a / 40.0 for a in animals]
    g += [es / 25.0, weeds / 25.0, empty / 100.0, locked / 100.0, unw / 40.0, unf / 40.0]
    g += [_log(r, 5.0) for r in ready]
    ocrops, oanimals, oes, oweeds, oempty, olocked, oready, _, _ = farm_summary(f_op, step, day)
    g += [c / 40.0 for c in ocrops] + [a / 40.0 for a in oanimals]
    g += [oweeds / 25.0, olocked / 100.0]
    g += [_log(r, 5.0) for r in oready]
    inv_units = priv.get("inventories") or [{}]
    carried = {}
    for inv in inv_units:
        for k, v in inv.items():
            carried[k] = carried.get(k, 0) + v
    g += [_log(carried.get("WHEAT", 0), 4.0), _log(carried.get("FERTILIZER", 0), 4.0),
          _log(sum(v for k, v in carried.items() if k not in ("WHEAT", "FERTILIZER")), 4.0)]
    g += [0.0] * (GF - len(g))
    assert len(g) == GF, len(g)
    return g


def unit_positions(farm):
    return [tuple(farm["farmer"])] + [tuple(h) for h in (farm.get("hands") or [])]


def unit_feats(obs, me, k, pos):
    inv = ((obs.get("private") or {}).get("inventories") or [{}])
    inv = inv[k] if k < len(inv) else {}
    x, y = pos
    u = [x / 9.0, y / 9.0, 1.0 if k == 0 else 0.0, _clip01(k / 15.0),
         _log(inv.get("WHEAT", 0), 3.0), _log(inv.get("FERTILIZER", 0), 3.0),
         _clip01(inv.get("GOOSE", 0)), _clip01(inv.get("COW", 0)), _clip01(inv.get("SHEEP", 0)),
         _log(sum(v for kk, v in inv.items() if kk not in ("WHEAT", "FERTILIZER") + tuple(ANIMAL_LIST)), 3.0),
         1.0 if (x, y) in SHED_SET else 0.0,
         min(abs(x - sx) + abs(y - sy) for sx, sy in SHED_TILES) / 10.0,
         1.0 if sum(inv.values()) > 0 else 0.0, 0.0, 0.0, 0.0]
    return u, inv


def base_masks(obs, me):
    """Legality independent of which unit acts: (100, K_T) tile-op mask and (K_S,) shed mask.
    Unit-dependent ops (FEED needs wheat, FERTILIZE needs fertilizer, PLACE needs the animal,
    DROP needs a non-empty inventory) are gated per unit with unit_gate()."""
    farm = obs["farms"][me]
    day = int(obs["day"])
    priv = obs.get("private") or {}
    seeds = priv.get("seeds") or {}
    shed = priv.get("shed") or {}
    money = float(farm["money"])
    tm = np.zeros((NT, K_T), dtype=bool)
    for y in range(BOARD):
        for x in range(BOARD):
            t = farm["tiles"][y][x]
            i = y * BOARD + x
            if t == "LOCKED":
                continue
            if t is None:
                tm[i, TOP["BUILD_COOP"]] = True
                tm[i, TOP["BUILD_PASTURE"]] = True
                for c in CROP_LIST:
                    if seeds.get(c, 0) > 0 or money >= CROPS[c]["seed"]:
                        tm[i, TOP["PLANT_" + c]] = True
                continue
            kind = t.get("kind")
            if kind == "WEED":
                tm[i, TOP["DIG"]] = True
            elif kind == "PLANT":
                tm[i, TOP["DIG"]] = True
                tm[i, TOP["FERTILIZE"]] = True
                if not t.get("watered_today"):
                    tm[i, TOP["WATER"]] = True
                if t.get("yield_units", 0) > 0 and day - t["planted_day"] >= CROPS[t["crop"]]["first"]:
                    tm[i, TOP["HARVEST"]] = True
            elif t.get("animal"):
                if not t.get("fed_today"):
                    tm[i, TOP["FEED"]] = True
                if not t.get("cared_today"):
                    tm[i, TOP["CARE"]] = True
                if t.get("fertilizer_available"):
                    tm[i, TOP["COLLECT_FERTILIZER"]] = True
                if t.get("yield_units", 0) > 0:
                    tm[i, TOP["HARVEST"]] = True
            else:
                tm[i, TOP["DIG"]] = True
                if kind == "COOP":
                    tm[i, TOP["PLACE_GOOSE"]] = True
                else:
                    tm[i, TOP["PLACE_COW"]] = True
                    tm[i, TOP["PLACE_SHEEP"]] = True
    sm = np.zeros(K_S, dtype=bool)
    for j, item in enumerate(["WHEAT", "FERTILIZER", "GOOSE", "COW", "SHEEP"]):
        sm[j] = shed.get(item, 0) > 0
    sm[SOP["DROP"]] = True
    return tm, sm


# Columns gated by what the acting unit carries: (op, inventory item).
UNIT_GATES = [(TOP["FEED"], "WHEAT"), (TOP["FERTILIZE"], "FERTILIZER"),
              (TOP["PLACE_GOOSE"], "GOOSE"), (TOP["PLACE_COW"], "COW"), (TOP["PLACE_SHEEP"], "SHEEP")]


def unit_gate_bits(inv):
    """6 bits: carries WHEAT, FERTILIZER, GOOSE, COW, SHEEP, anything."""
    return [inv.get("WHEAT", 0) > 0, inv.get("FERTILIZER", 0) > 0, inv.get("GOOSE", 0) > 0,
            inv.get("COW", 0) > 0, inv.get("SHEEP", 0) > 0, sum(inv.values()) > 0]


def full_mask(tm, sm, gate):
    m = np.zeros(N_CAND, dtype=bool)
    t = tm.copy()
    for (col, _), ok in zip(UNIT_GATES, gate[:5]):
        if not ok:
            t[:, col] = False
    m[:SHED_BASE] = t.reshape(-1)
    s = sm.copy()
    if not gate[5]:
        s[SOP["DROP"]] = False
    m[SHED_BASE:PASS_IDX] = s
    m[PASS_IDX] = True
    return m


def op_to_cand(op, pos, tile):
    """Map a non-move unit action at `pos` to (cand_index, pickup_n) or (None, 0) if unmodelled."""
    name = op[0]
    x, y = pos
    ti = y * BOARD + x
    if name == "PASS":
        return PASS_IDX, 0
    if name in ("WATER", "HARVEST", "FERTILIZE", "DIG", "FEED", "CARE", "COLLECT_FERTILIZER",
                "BUILD_COOP", "BUILD_PASTURE"):
        return ti * K_T + TOP[name], 0
    if name == "PLANT" and len(op) >= 2 and op[1] in CROPS:
        return ti * K_T + TOP["PLANT_" + op[1]], 0
    if name == "PLACE" and len(op) >= 2:
        item = op[1]
        if item in ANIMALS and isinstance(tile, dict) and tile.get("kind") == ANIMALS[item]["structure"] \
                and not tile.get("animal"):
            return ti * K_T + TOP["PLACE_" + item], 0
        if (x, y) in SHED_SET:
            return SHED_BASE + SOP["DROP"], 0
        return None, 0
    if name == "DROP":
        return SHED_BASE + SOP["DROP"], 0
    if name == "PICKUP" and len(op) >= 2 and op[1] in ("WHEAT", "FERTILIZER", "GOOSE", "COW", "SHEEP"):
        try:
            n = int(op[2]) if len(op) >= 3 else 1
        except (TypeError, ValueError):
            n = 1
        return SHED_BASE + SOP["PICKUP_" + op[1]], max(1, min(PICKUP_MAX, n))
    return None, 0


def cand_target(c, pos):
    """Tile a candidate is executed on; shed ops go to the nearest shed-access tile."""
    if c < SHED_BASE:
        t = c // K_T
        return (t % BOARD, t // BOARD)
    if c < PASS_IDX:
        return min(SHED_TILES, key=lambda s: (abs(s[0] - pos[0]) + abs(s[1] - pos[1]), SHED_TILES.index(s)))
    return tuple(pos)


def market_labels(obs, me, action, max_orders=10):
    """Canonical per-step market decision, with no-op orders stripped."""
    priv = obs.get("private") or {}
    shed = priv.get("shed") or {}
    orders = (action or {}).get("market") or []
    orders = orders[:max_orders] if isinstance(orders, list) else []
    hire = land = 0
    seed = {c: 0 for c in CROP_LIST}
    animal = {a: 0 for a in ANIMAL_LIST}
    prod = {"WHEAT": 0, "FERTILIZER": 0}
    sell = {p: 0 for p in PRODUCTS}
    for o in orders:
        if not isinstance(o, list) or not o:
            continue
        op = o[0]
        if op == "HIRE":
            hire += 1
            continue
        if op == "BUY_LAND":
            land = 1
            continue
        if len(o) < 3:
            continue
        try:
            n = int(o[2])
        except (TypeError, ValueError):
            continue
        if n <= 0:
            continue
        item = o[1]
        if op == "BUY_SEED" and item in seed:
            seed[item] += n
        elif op == "BUY_ANIMAL" and item in animal:
            animal[item] += n
        elif op == "BUY_PRODUCT" and item in prod:
            prod[item] += n
        elif op == "SELL" and item in sell:
            sell[item] += n
    y = [min(hire, MAX_HIRE_CLS - 1), land]
    y += [qty_class(seed[c]) for c in CROP_LIST]
    y += [qty_class(animal[a]) for a in ANIMAL_LIST]
    y += [qty_class(prod["WHEAT"]), qty_class(prod["FERTILIZER"])]
    y += [sell_class(sell[p], shed.get(p, 0)) for p in PRODUCTS]
    return y


# Head layout for market_labels(): (name, n_classes)
MARKET_HEADS = ([("hire", MAX_HIRE_CLS), ("land", 2)]
                + [("seed_" + c, len(QTY)) for c in CROP_LIST]
                + [("animal_" + a, len(QTY)) for a in ANIMAL_LIST]
                + [("buy_WHEAT", len(QTY)), ("buy_FERTILIZER", len(QTY))]
                + [("sell_" + p, len(SELL_FRAC)) for p in PRODUCTS])
