"""Paired-seed, both-seat evaluation.

Every seed is played twice with the seats swapped, and only W/L/T counts - the
same quantity the ladder and the final Bradley-Terry pass use (forum #736219).
"""
import contextlib
import io
import math
import multiprocessing as mp
import os


def _make_env(seed):
    with contextlib.redirect_stdout(io.StringIO()):
        from kaggle_environments import make
    return make("kaggriculture", configuration={"seed": int(seed)})


def play_one(job):
    spec0, spec1, seed = job
    from kag.agents.registry import build_agent
    env = _make_env(seed)
    env.run([build_agent(spec0), build_agent(spec1)])
    last = env.steps[-1]
    return {
        "seed": seed,
        "money": [float(last[0].reward or 0.0), float(last[1].reward or 0.0)],
        "status": [last[0].status, last[1].status],
    }


def wilson(p, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (centre - half, centre + half)


def summarize(results, cand_seats):
    w = l = t = err = 0
    cm = om = 0.0
    for r, seat in zip(results, cand_seats):
        me, op = r["money"][seat], r["money"][1 - seat]
        if r["status"][seat] != "DONE":
            err += 1
        cm += me
        om += op
        if me > op:
            w += 1
        elif me < op:
            l += 1
        else:
            t += 1
    n = len(results)
    score = (w + 0.5 * t) / n if n else 0.0
    lo, hi = wilson(score, n)
    return {
        "n": n, "wins": w, "losses": l, "ties": t, "errors": err,
        "score": score, "ci95": (lo, hi),
        "cand_money": cm / n if n else 0.0, "opp_money": om / n if n else 0.0,
    }


def evaluate(cand, opp, seeds, procs=None, pool=None, alternate=False):
    """alternate=True plays each seed once, seats alternating: two deterministic agents get
    identical results in both seats, so the swapped replay adds no information."""
    jobs, cand_seats = [], []
    for i, s in enumerate(seeds):
        for seat in ([i % 2] if alternate else [0, 1]):
            jobs.append((cand, opp, s) if seat == 0 else (opp, cand, s))
            cand_seats.append(seat)
    if pool is not None:
        results = pool.map(play_one, jobs, chunksize=1)
    else:
        procs = procs or max(1, (os.cpu_count() or 2) - 1)
        with mp.get_context("spawn").Pool(procs) as p:
            results = p.map(play_one, jobs, chunksize=1)
    return summarize(results, cand_seats), results
