"""Turn one seat of a replay into BC training arrays.

Per step: quantized tile features, unit occupancy, claimed-target counts, legality
masks, global features and market labels. Per unit-step row: unit features, the
unit's inventory gate bits and its intent label (next non-move op + tile).
"""
import numpy as np

from kag.features import (
    BOARD, GF, K_S, K_T, MOVES, NT, PASS_IDX, SHED_BASE, TF, UF,
    base_masks, full_mask, global_feats, market_labels, op_to_cand, tile_static,
    unit_feats, unit_gate_bits, unit_positions, MARKET_HEADS,
)
from kag.replay import seat_decisions


def unit_action(act, k):
    if not isinstance(act, dict):
        return ["PASS"]
    if k == 0:
        a = act.get("farmer")
    else:
        hands = act.get("hands") or []
        a = hands[k - 1] if k - 1 < len(hands) else None
    return a if isinstance(a, list) and a else ["PASS"]


def build_seat(rep, seat, stats=None):
    stats = stats if stats is not None else {}
    decisions = list(seat_decisions(rep, seat))
    S = len(decisions)
    tiles_q = np.zeros((S, NT, TF), dtype=np.uint8)
    occ = np.zeros((S, NT), dtype=np.uint8)
    claimed = np.zeros((S, NT), dtype=np.uint8)
    claimed_shed = np.zeros(S, dtype=np.uint8)
    tmask = np.zeros((S, NT, K_T), dtype=bool)
    smask = np.zeros((S, K_S), dtype=bool)
    glob = np.zeros((S, GF), dtype=np.float16)
    mkt = np.zeros((S, len(MARKET_HEADS)), dtype=np.int8)

    positions, actions, tiles_at, invs = [], [], [], []
    for s, (step, obs, act) in enumerate(decisions):
        farm = obs["farms"][seat]
        day = int(obs["day"])
        for y in range(BOARD):
            for x in range(BOARD):
                f = tile_static(farm["tiles"][y][x], x, y, step, day)
                tiles_q[s, y * BOARD + x] = np.clip(np.round(np.asarray(f) * 255), 0, 255)
        pos = unit_positions(farm)
        for (x, y) in pos:
            occ[s, y * BOARD + x] += 1
        tm, sm = base_masks(obs, seat)
        tmask[s], smask[s] = tm, sm
        glob[s] = global_feats(obs, seat)
        mkt[s] = market_labels(obs, seat, act)
        positions.append(pos)
        actions.append([unit_action(act, k) for k in range(len(pos))])
        tiles_at.append([farm["tiles"][y][x] for (x, y) in pos])
        u_rows = []
        for k, p in enumerate(pos):
            uf, inv = unit_feats(obs, seat, k, p)
            u_rows.append((uf, unit_gate_bits(inv)))
        invs.append(u_rows)

    # Intent labels: walk each day backwards; a unit's label at s is its next non-move op.
    labels = [[None] * len(positions[s]) for s in range(S)]
    for d0 in range(0, S, 24):
        d1 = min(S, d0 + 24)
        nxt = {}
        for s in range(d1 - 1, d0 - 1, -1):
            for k, p in enumerate(positions[s]):
                a = actions[s][k]
                if a[0] in MOVES:
                    labels[s][k] = nxt.get(k)
                else:
                    c, n = op_to_cand(a, p, tiles_at[s][k])
                    lab = (c, n) if c is not None else None
                    if lab is None:
                        stats["unmodelled"] = stats.get("unmodelled", 0) + 1
                    labels[s][k] = lab
                    nxt[k] = lab

    rows_step, rows_k, rows_uf, rows_gate, rows_y, rows_n, rows_self = [], [], [], [], [], [], []
    for s in range(S):
        for k, lab in enumerate(labels[s]):
            if lab is None:
                continue
            c = lab[0]
            if c < SHED_BASE:
                claimed[s, c // K_T] += 1
            elif c < PASS_IDX:
                claimed_shed[s] += 1
        for k, lab in enumerate(labels[s]):
            if lab is None:
                stats["no_label"] = stats.get("no_label", 0) + 1
                continue
            c, n = lab
            uf, gate = invs[s][k]
            m = full_mask(tmask[s], smask[s], gate)
            if not m[c]:
                stats["illegal"] = stats.get("illegal", 0) + 1
                continue
            stats["ok"] = stats.get("ok", 0) + 1
            rows_step.append(s)
            rows_k.append(k)
            rows_uf.append(uf)
            rows_gate.append(gate)
            rows_y.append(c)
            rows_n.append(n)
            rows_self.append(c // K_T if c < SHED_BASE else (-2 if c < PASS_IDX else -1))

    return {
        "tiles_q": tiles_q, "occ": occ, "claimed": claimed, "claimed_shed": claimed_shed,
        "tmask": np.packbits(tmask, axis=-1), "smask": smask, "glob": glob, "mkt": mkt,
        "u_step": np.asarray(rows_step, dtype=np.int16), "u_k": np.asarray(rows_k, dtype=np.int8),
        "u_feat": np.asarray(rows_uf, dtype=np.float16).reshape(-1, UF),
        "u_gate": np.asarray(rows_gate, dtype=bool).reshape(-1, 6),
        "u_y": np.asarray(rows_y, dtype=np.int16), "u_n": np.asarray(rows_n, dtype=np.int8),
        "u_self": np.asarray(rows_self, dtype=np.int16),
    }
