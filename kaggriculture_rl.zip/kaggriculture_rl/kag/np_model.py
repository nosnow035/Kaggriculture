"""Pure-numpy forward pass of BCNet, so the submission does not depend on torch."""
import json
import math

import numpy as np

from kag.features import BOARD, NT, SHED_TILES

_TX = np.array([i % BOARD for i in range(NT)], dtype=np.float32)
_TY = np.array([i // BOARD for i in range(NT)], dtype=np.float32)


def _ln(x, w, b, eps=1e-5):
    mu = x.mean(-1, keepdims=True)
    var = ((x - mu) ** 2).mean(-1, keepdims=True)
    return (x - mu) / np.sqrt(var + eps) * w + b


def _erf(x):
    # Abramowitz & Stegun 7.1.26 (max abs error 1.5e-7).
    s = np.sign(x)
    a = np.abs(x)
    t = 1.0 / (1.0 + 0.3275911 * a)
    y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t
               + 0.254829592) * t * np.exp(-a * a)
    return s * y


def _gelu(x):
    return 0.5 * x * (1.0 + _erf(x * 0.7071067811865476))


def _softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


def np_pair_feats(u_xy, claimed, self_tile):
    dx = _TX[None] - u_xy[:, :1]
    dy = _TY[None] - u_xy[:, 1:2]
    dist = np.abs(dx) + np.abs(dy)
    c = np.repeat(claimed[None].astype(np.float32), len(u_xy), 0)
    for i, t in enumerate(self_tile):
        if t >= 0:
            c[i, t] -= 1
    here = (dist == 0).astype(np.float32)
    return np.stack([dist / 18.0, dx / 9.0, dy / 9.0, np.maximum(c, 0) / 3.0, here], -1)


def np_shed_pair(u_xy, claimed_shed, self_is_shed):
    d = np.stack([np.abs(u_xy[:, 0] - sx) + np.abs(u_xy[:, 1] - sy) for sx, sy in SHED_TILES], -1)
    other = np.maximum(claimed_shed - self_is_shed.astype(np.float32), 0)
    return np.stack([d.min(-1) / 10.0, other / 3.0], -1).astype(np.float32)


class NPNet:
    def __init__(self, path):
        z = np.load(path, allow_pickle=False)
        self.w = {k: z[k].astype(np.float32) for k in z.files if not k.startswith("__")}
        self.cfg = json.loads(str(z["__cfg__"]))
        self.decode = json.loads(str(z["__decode__"])) if "__decode__" in z.files else {}
        self.styles = json.loads(str(z["__styles__"])) if "__styles__" in z.files else {}
        self.heads = self.cfg["heads"]
        self.layers = self.cfg["layers"]

    def _lin(self, x, name, bias=True):
        y = x @ self.w[name + ".weight"].T
        if bias and (name + ".bias") in self.w:
            y = y + self.w[name + ".bias"]
        return y

    def _mha(self, x, p):
        T, d = x.shape
        H = self.heads
        dh = d // H
        qkv = x @ self.w[p + "in_proj_weight"].T + self.w[p + "in_proj_bias"]
        q, k, v = qkv[:, :d], qkv[:, d:2 * d], qkv[:, 2 * d:]
        q = q.reshape(T, H, dh).transpose(1, 0, 2)
        k = k.reshape(T, H, dh).transpose(1, 0, 2)
        v = v.reshape(T, H, dh).transpose(1, 0, 2)
        att = _softmax(q @ k.transpose(0, 2, 1) * (1.0 / math.sqrt(dh)))  # python float keeps float32
        o = (att @ v).transpose(1, 0, 2).reshape(T, d)
        return self._lin(o, p + "out_proj")

    def encode(self, tiles, glob, style=None):
        w = self.w
        x = self._lin(tiles, "tile_in") + w["pos.weight"]
        g = self._lin(glob[None], "glob_in")
        if "style.weight" in w:
            g = g + w["style.weight"][int(style or 0)][None]
        h = np.concatenate([g, x], 0)
        for l in range(self.layers):
            p = f"encoder.layers.{l}."
            y = _ln(h, w[p + "norm1.weight"], w[p + "norm1.bias"])
            h = h + self._mha(y, p + "self_attn.")
            y = _ln(h, w[p + "norm2.weight"], w[p + "norm2.bias"])
            h = h + self._lin(_gelu(self._lin(y, p + "linear1")), p + "linear2")
        h = _ln(h, w["norm.weight"], w["norm.bias"])
        return h[1:], h[0]

    def market_logits(self, tile_emb, glob_emb):
        z = np.concatenate([glob_emb, tile_emb.mean(0)])[None]
        z = _gelu(self._lin(_gelu(self._lin(z, "m_trunk.0")), "m_trunk.2"))
        return self._lin(z, "m_out")[0]

    def unit_logits(self, tile_emb, glob_emb, u_feat, u_gate, pair, shed_pair):
        U = u_feat.shape[0]
        ue = self._lin(_gelu(self._lin(np.concatenate([u_feat, u_gate], -1), "unit_in.0")), "unit_in.2")
        z = (tile_emb @ self.w["h_tile.weight"].T)[None] + self._lin(ue, "h_unit")[:, None] \
            + pair @ self.w["h_pair.weight"].T
        tl = self._lin(_gelu(self._lin(_gelu(z), "h_out.1")), "h_out.3").reshape(U, -1)
        ge = np.repeat(glob_emb[None], U, 0)
        sl = self._lin(_gelu(self._lin(np.concatenate([ge, ue, shed_pair], -1), "s_mlp.0")), "s_mlp.2")
        pk = self._lin(_gelu(self._lin(np.concatenate([ge, ue], -1), "p_mlp.0")), "p_mlp.2")
        return np.concatenate([tl, sl], -1), pk
