"""BC policy network.

A transformer encodes the 100 farm tiles plus one global token. Each unit then scores
every legal (tile, op) candidate with a factorised head (tile embedding + unit
embedding + unit-tile pair features), plus the shed ops and PASS. Market decisions
are per-product classification heads on the global embedding.

Optional style conditioning (n_style > 0): a learned embedding of *which team is being
imitated* is added to the global token, so mixed demonstrations don't average into a
strategy nobody plays. Style 0 means "unknown" and is also used for style dropout.
"""
import torch
import torch.nn as nn

from kag.features import BOARD, GF, K_S, K_T, MARKET_HEADS, NT, PICKUP_MAX, SHED_TILES, TF, UF

N_PAIR = 5
N_SHED_PAIR = 2
N_MKT = sum(n for _, n in MARKET_HEADS)

_TX = torch.tensor([i % BOARD for i in range(NT)], dtype=torch.float32)
_TY = torch.tensor([i // BOARD for i in range(NT)], dtype=torch.float32)


def pair_feats(u_xy, claimed_rows, self_tile):
    """u_xy [U,2] float grid coords; claimed_rows [U,100] counts of units targeting each tile
    (including this unit); self_tile [U] long, this unit's own claimed tile or <0."""
    tx, ty = _TX.to(u_xy.device)[None], _TY.to(u_xy.device)[None]
    dx = tx - u_xy[:, :1]
    dy = ty - u_xy[:, 1:2]
    dist = dx.abs() + dy.abs()
    c = claimed_rows.clone()
    own = self_tile >= 0
    if own.any():
        r = torch.nonzero(own, as_tuple=True)[0]
        c[r, self_tile[r]] -= 1
    here = (dist == 0).float()
    return torch.stack([dist / 18.0, dx / 9.0, dy / 9.0, c.clamp(min=0) / 3.0, here], -1)


def shed_pair_feats(u_xy, claimed_shed, self_is_shed):
    d = torch.stack([(u_xy[:, 0] - sx).abs() + (u_xy[:, 1] - sy).abs() for sx, sy in SHED_TILES], -1)
    other = (claimed_shed - self_is_shed.float()).clamp(min=0)
    return torch.stack([d.min(-1).values / 10.0, other / 3.0], -1)


class BCNet(nn.Module):
    def __init__(self, d=128, layers=3, heads=4, ff=4, n_style=0):
        super().__init__()
        self.cfg = {"d": d, "layers": layers, "heads": heads, "ff": ff, "n_style": n_style}
        self.tile_in = nn.Linear(TF, d)
        self.pos = nn.Embedding(NT, d)
        self.glob_in = nn.Linear(GF, d)
        self.style = nn.Embedding(n_style, d) if n_style > 0 else None
        enc = nn.TransformerEncoderLayer(d, heads, ff * d, dropout=0.0, batch_first=True,
                                         norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(enc, layers, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(d)
        self.unit_in = nn.Sequential(nn.Linear(UF + 6, d), nn.GELU(), nn.Linear(d, d))
        self.h_tile = nn.Linear(d, d, bias=False)
        self.h_unit = nn.Linear(d, d)
        self.h_pair = nn.Linear(N_PAIR, d, bias=False)
        self.h_out = nn.Sequential(nn.GELU(), nn.Linear(d, d), nn.GELU(), nn.Linear(d, K_T))
        self.s_mlp = nn.Sequential(nn.Linear(2 * d + N_SHED_PAIR, d), nn.GELU(), nn.Linear(d, K_S + 1))
        self.p_mlp = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, PICKUP_MAX))
        self.m_trunk = nn.Sequential(nn.Linear(2 * d, 2 * d), nn.GELU(), nn.Linear(2 * d, 2 * d), nn.GELU())
        self.m_out = nn.Linear(2 * d, N_MKT)
        # Critic for PPO/GAE: expected (my money - opponent money) / VALUE_SCALE, in [-1, 1].
        # A terminal-only reward spread over ~7,000 decisions per game is what sank the first
        # RL attempt; this head is what turns it into a per-state signal.
        self.v_mlp = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1))

    def encode(self, tiles, glob, style=None):
        x = self.tile_in(tiles) + self.pos.weight[None]
        g = self.glob_in(glob)
        if self.style is not None:
            if style is None:
                style = torch.zeros(glob.shape[0], dtype=torch.long, device=glob.device)
            g = g + self.style(style)
        h = self.norm(self.encoder(torch.cat([g[:, None], x], 1)))
        return h[:, 1:], h[:, 0]

    def market_logits(self, tile_emb, glob_emb):
        return self.m_out(self.m_trunk(torch.cat([glob_emb, tile_emb.mean(1)], -1)))

    def value(self, tile_emb, glob_emb):
        return torch.tanh(self.v_mlp(torch.cat([glob_emb, tile_emb.mean(1)], -1)).squeeze(-1))

    def unit_logits(self, tile_emb, glob_emb, u_step, u_feat, u_gate, pair, shed_pair):
        ue = self.unit_in(torch.cat([u_feat, u_gate], -1))
        z = self.h_tile(tile_emb)[u_step] + self.h_unit(ue)[:, None] + self.h_pair(pair)
        tl = self.h_out(z).reshape(u_step.shape[0], NT * K_T)
        ge = glob_emb[u_step]
        sl = self.s_mlp(torch.cat([ge, ue, shed_pair], -1))
        pk = self.p_mlp(torch.cat([ge, ue], -1))
        return torch.cat([tl, sl], -1), pk
