"""Loader: the agent itself lives in agent_base.py next to this file.

Kaggle compiles main.py on the first turn; keeping main.py tiny and shipping agent_base's
precompiled bytecode (__pycache__, hash-based) removes that compile when the interpreter
matches, and changes nothing otherwise. Standard library only.
"""
import os
import sys

_dir = os.path.dirname(os.path.abspath(
    globals().get("__file__") or sys._getframe().f_code.co_filename))
if _dir not in sys.path:
    sys.path.insert(0, _dir)

import agent_base  # noqa: E402

_ENTRY = getattr(agent_base, "_enh_agent")
_REPORTED = False


def _enh_agent(observation, configuration=None):
    global _REPORTED
    if not _REPORTED:
        _REPORTED = True
        cached = getattr(agent_base, "__cached__", "") or ""
        print("loader: python %s, bytecode %s" % (
            sys.version.split()[0], "cached" if cached and os.path.exists(cached) else "compiled"))
    return _ENTRY(observation, configuration)
